//
//  half.hpp
//  half
//
//  Created by Kali on 2019/4/21.
//  Copyright © 2019 Kali. All rights reserved.
//  Made in Taiwan.

#ifndef half_hpp
#define half_hpp

short    FloatToHalf (int i);
float    overflow ();
unsigned int HalfToFloat (unsigned short y);

#endif /* half_hpp */
