DEVROOT="$HOME/Developer/CommandLineTools/IOSDEVROOT"
IOSSDKROOT=$(xcrun --sdk iphoneos6.1 --show-sdk-path)
export SDKROOT=$IOSSDKROOT
export CC="$(xcrun -f clang) -arch armv7"
export CXX="$(xcrun -f clang++) -arch armv7"
export LD=$DEVROOT/usr/bin/ld
export AR=$DEVROOT/usr/bin/ar
export AS=$DEVROOT/usr/bin/as
export NM=$DEVROOT/usr/bin/nm
export RANLIB=$DEVROOT/usr/bin/ranlib
export CFLAGS="-I$SDKROOT/usr/include/ -I$HOME/Headers/"
export LDFLAGS="-L$SDKROOT/usr/lib/ -L$HOME/LIBS/"
export CPPFLAGS=$CFLAGS
export CXXFLAGS=$CFLAGS

mkdir -p $HOME/Headers
mkdir -p $HOME/LIBS

mkdir -p pkg/bin
mkdir -p pkg/sbin
mkdir -p pkg/usr/bin
mkdir -p pkg/usr/sbin


# libutil1.0.dylib
cd libutil
ALLC="ExtentManager.cpp getmntopts.c humanize_number.c pidfile.c trimdomain.c tzlink.c wipefs.cpp"
TARGET="libutil1.0.dylib"
# $CC $CFLAGS $LDFLAGS -dynamiclib -o $TARGET $ALLC
$CC $CFLAGS $LDFLAGS -shared -undefined dynamic_lookup -o $TARGET $ALLC
cp libutil1.0.dylib $HOME/LIBS/
cp libutil.h mntopts.h tzlink.h wipefs.h $HOME/Headers/
ln -s $HOME/LIBS/libutil1.0.dylib $HOME/LIBS/libutil.dylib
cd ..

# libalias.A.dylib
cd alias
ALLC=$(ls | grep '.c' | sed /.h/d | sed /.[0-9]/d | tr "\n" " ")
TARGET="libalias.A.dylib"
$CC $CFLAGS $LDFLAGS -dynamiclib -o $TARGET $ALLC
cp libalias.A.dylib $HOME/LIBS/
ln -s $HOME/LIBS/libalias.A.dylib $HOME/LIBS/libalias.dylib
cp alias_local.h alias.h $HOME/Headers/
cd ..

# arp
cd arp.tproj
$CC $CFLAGS $LDFLAGS -o arp arp.c
mv arp ../pkg/usr/sbin/arp
cd ..

# dnctl
cd dnctl
$CC $CFLAGS $LDFLAGS -o dnctl dnctl.c
mv dnctl ../pkg/usr/sbin/dnctl
cd ..

# ifconfig
cd ifconfig.tproj
ALLC=$(ls | grep '.c' | sed /.h/d | sed /.[0-9]/d | tr "\n" " ")
TARGET="ifconfig"
$CC $CFLAGS $LDFLAGS -o $TARGET $ALLC
mv ifconfig ../pkg/sbin/ifconfig
cd ..

# ip6addrctl
cd ip6addrctl.tproj
$CC $CFLAGS $LDFLAGS -o ip6addrctl ip6addrctl.c
mv ip6addrctl ../pkg/sbin/ip6addrctl
cd ..

# ip6fw
cd ip6fw.tproj
$CC $CFLAGS $LDFLAGS -o ip6fw ip6fw.c
mv ip6fw ../pkg/sbin/ip6fw
cd ..

# ipfw
cd ipfw.tproj
$CC $CFLAGS $LDFLAGS -o ipfw ipfw2.c
mv ipfw ../pkg/sbin/ipfw
cd ..

# kdumpd
cd kdumpd.tproj
ALLC=$(ls | grep '.c' | sed /.h/d | sed /.[0-9]/d | tr "\n" " ")
TARGET="kdumpd"
$CC $CFLAGS $LDFLAGS -o $TARGET $ALLC
mv kdumpd ../pkg/usr/sbin/kdumpd
cd ..

# mnc
cd mnc.tproj
ALLC=$(ls | grep '.c' | sed /.h/d | sed /.[0-9]/d | tr "\n" " ")
TARGET="mnc"
$CC $CFLAGS $LDFLAGS -o $TARGET $ALLC
mv mnc ../pkg/usr/sbin/mnc
cd ..

# mtest
cd mtest.tproj
$CC $CFLAGS $LDFLAGS -o mtest mtest.c
mv mtest ../pkg/usr/sbin/mtest
cd ..

# natd *
cd natd.tproj
LDFLAGS=-L$HOME/LIBS
$CC $CFLAGS $LDFLAGS -o natd icmp.c natd.c
mv natd ../pkg/usr/sbin/natd
cd ..

# ndp
cd ndp.tproj
$CC $CFLAGS $LDFLAGS -o ndp ndp.c
mv ndp ../pkg/usr/sbin/ndp
cd ..

# netstat
cd netstat.tproj
ALLC=$(ls | grep '.c' | sed /.h/d | sed /.[0-9]/d | tr "\n" " ")
TARGET="netstat"
$CC $CFLAGS $LDFLAGS -o $TARGET $ALLC
mv netstat ../pkg/sbin/netstat
cd ..

# ping
cd ping.tproj
$CC $CFLAGS $LDFLAGS -o ping ping.c
mv ping ../pkg/bin/ping
cd ..

# ping6
cd ping6.tproj
$CC $CFLAGS $LDFLAGS -o ping6 md5.c ping6.c
mv ping6 ../pkg/sbin/ping6
cd ..

# pktapctl
cd pktapctl
$CC $CFLAGS $LDFLAGS -o pktapctl pktapctl.c
mv pktapctl ../pkg/usr/sbin/pktapctl
cd ..

# rarpd
cd rarpd.tproj
$CC $CFLAGS $LDFLAGS -o rarpd rarpd.c
mv rarpd ../pkg/usr/sbin/rarpd
cd ..

# route
cd route.tproj
$CC $CFLAGS $LDFLAGS -o route route.c
mv route ../pkg/sbin/route
cd ..

# rtadvd *
cd rtadvd.tproj
ALLC=$(ls | grep '.c' | sed /.h/d | sed /.[0-9]/d | sed /.conf/d | tr "\n" " ")
TARGET="rtadvd"
$CC $CFLAGS $LDFLAGS -o $TARGET $ALLC
mv rtadvd ../pkg/usr/sbin/rtadvd
cd ..

# rtsol
cd rtsol.tproj
ALLC=$(ls | grep '.c' | sed /.h/d | sed /.[0-9]/d | tr "\n" " ")
TARGET="rtsol"
$CC $CFLAGS $LDFLAGS -o $TARGET $ALLC
mv rtsol ../pkg/sbin/rtsol
cd ..

# spray *
cd spray.tproj
$CC $CFLAGS $LDFLAGS -o spray spray.c
mv spray ../pkg/usr/sbin/spray
cd ..

# traceroute
cd traceroute.tproj
ALLC=$(ls | grep '.c' | sed /.h/d | sed /.[0-9]/d | tr "\n" " ")
TARGET="traceroute"
$CC $CFLAGS $LDFLAGS -o $TARGET $ALLC
mv traceroute ../pkg/usr/sbin/traceroute
cd ..

# traceroute6
cd traceroute6.tproj
$CC $CFLAGS $LDFLAGS -o traceroute6 traceroute6.c
mv traceroute6 ../pkg/usr/sbin/traceroute6
cd ..

# make ios arm deb
# dpkg-deb --build --uniform-compression -Zgzip pkg network-cmds_443-1_iphoneos-arm.deb
