#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/opt/lib"
XSLT_LIBS="-lxslt  -lxml2  "
XSLT_INCLUDEDIR="-I/opt/include"
MODULE_VERSION="xslt-1.1.29"
