
DEVROOT=$(xcrun --sdk iphoneos --show-sdk-platform-path)
IOSSDKROOT=$(xcrun --sdk iphoneos --show-sdk-path)
export SDKROOT=$IOSSDKROOT
export CC="$(xcrun -f clang) -arch armv7 -arch armv7s"
export CXX="$(xcrun -f clang++) -arch armv7 -arch armv7s"
export LD=$DEVROOT/usr/bin/ld
export AR=$DEVROOT/usr/bin/ar
export AS=$DEVROOT/usr/bin/as
export NM=$DEVROOT/usr/bin/nm
export RANLIB=$DEVROOT/usr/bin/ranlib
export CFLAGS="-I$SDKROOT/usr/include/"
export LDFLAGS="-L$SDKROOT/usr/lib/"
export CPPFLAGS=$CFLAGS
export CXXFLAGS=$CFLAGS
FRAMEWORKS="-framework Foundation"
SIGN_FLAGS="codesign -s - --entitlements ent.xml"
# SIGN_FLAGS="ldid -Sent.xml"

TARGER="main"
SRC="main.m"

$CC $CFLAGS $LDFLAGS $FRAMEWORKS $SRC -o $TARGER
$SIGN_FLAGS $TARGER
