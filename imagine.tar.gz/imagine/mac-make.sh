export CC="gcc"
export CXX="g++"
export CFLAGS="-I/usr/include/ -I/usr/local/include/ -I."
export LDFLAGS="-L/usr/lib/ -L/usr/local/lib/"

# ALLC="imagine.c"
# TARGET="imagine"
# $CC $CFLAGS $LDFLAGS $ALLC -o $TARGET

$CC $CFLAGS -c imagine.c -o imagine.o

LIBS=""
ALLO="imagine.o"
TARGET="imagine"
$CC $LDFLAGS $LIBS $ALLO -o $TARGET
rm *.o
