################################
### INSTALL
################################
# cpoy VerbStub.kext to EFI/CLOVER/kexts/

sudo mkdir -p $HOME/EFI
sudo mount -t msdos /dev/disk0s1 $HOME/EFI
sudo cp -r VerbStub.kext $HOME/EFI/EFI/CLOVER/kexts/
# Umount EFI
diskutil umount $HOME/EFI

# or VerbStub.kext copy to /System/Library/Extensions/
sudo cp -r VerbStub.kext /System/Library/Extensions/
sudo chown -R 0:0 /System/Library/Extensions/VerbStub.kext

# cppy hda-verb to /usr/bin/
sudo rm -rf /usr/bin/hda-verb
sudo cp hda-verb /usr/bin/
sudo chmod 755 /usr/bin/hda-verb

# Rebuild Kernel Caches
sudo rm -rf /System/Library/Caches/*
sudo rm -rf /System/Library/PrelinkedKernels/prelinkedkernel
# sudo touch /System/Library/Extensions/
sudo kextcache -u /
