This is a fork of KNNSpeed's VerbStub.kext.

More information here: https://www.tonymacx86.com/threads/guide-dell-xps-15-9560-4k-touch-1tb-ssd-32gb-ram-100-adobergb.224486/page-9#post-1539760 .