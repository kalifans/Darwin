################################
### INSTALL
################################
# cpoy CodecCommander.kext to EFI/CLOVER/kexts/ or /System/Library/Extensions/
sudo cp -r CodecCommander.kext /System/Library/Extensions/
sudo chown -R 0:0 /System/Library/Extensions/CodecCommander.kext

# cppy hda-verb to /usr/bin/
sudo cp hda-verb /usr/bin/
sudo chmod 755 /usr/bin/hda-verb

# Rebuild Kernel Caches
sudo rm -rf /System/Library/Caches/com.apple.kext.caches/Startup/kernelcache
sudo rm -rf /System/Library/PrelinkedKernels/prelinkedkernel
sudo touch /System/Library/Extensions/ && sudo kextcache -u /
