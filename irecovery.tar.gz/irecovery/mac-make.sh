# Mac OS X Make
CC=gcc
CFLAGS="-I/usr/include/ -I/usr/local/include/"
LDFLAGS="-L/usr/lib/ -L/usr/local/lib/"

LIBS="-lusb-1.0 -lobjc -lreadline"
FRAMEEORK="-framework CoreFoundation -framework IOKit"
$CC $CFLAGS $LDFLAGS $LIBS $FRAMEEORK irecovery.c -o irecovery
