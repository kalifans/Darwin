# Linux Make
# sudo apt-get install libusb-1.0-0-dev
make linux
