#!/bin/bash

/bin/mkdir pkg
cd pkg
../build-libssl.sh --archs=armv7 --version=1.0.2l --verbose
