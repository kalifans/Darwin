
cd pkg
mkdir -p deb/usr/bin
mkdir -p deb/usr/include/openssl
mkdir -p deb/usr/lib/engines
mkdir -p deb/usr/lib/pkgconfig
mkdir -p deb/usr/lib/ssl/misc
mkdir -p deb/etc/ssl/certs
mkdir -p deb/etc/ssl/private

cp src/iPhoneOS-armv7/openssl-1.0.2l/tools/c_rehash deb/usr/bin/
cp src/iPhoneOS-armv7/openssl-1.0.2l/apps/openssl deb/usr/bin/
chmod 755 deb/usr/bin/*

cp src/iPhoneOS-armv7/openssl-1.0.2l/include/openssl/* deb/usr/include/openssl/
chmod 644 deb/usr/include/openssl/*

/usr/lib 755
cp src/iPhoneOS-armv7/openssl-1.0.2l/libcrypto.1.0.0.dylib deb/usr/lib/
cp src/iPhoneOS-armv7/openssl-1.0.2l/libssl.1.0.0.dylib deb/usr/lib/
chmod 755 deb/usr/lib/*.dylib

cp src/iPhoneOS-armv7/openssl-1.0.2l/openssl.pc deb/usr/lib/pkgconfig/
cp src/iPhoneOS-armv7/openssl-1.0.2l/libssl.pc deb/usr/lib/pkgconfig/
cp src/iPhoneOS-armv7/openssl-1.0.2l/libcrypto.pc deb/usr/lib/pkgconfig/
chmod 644 deb/usr/lib/pkgconfig/*

cp src/iPhoneOS-armv7/openssl-1.0.2l/engines/*.dylib deb/usr/lib/engines/
chmod 755 deb/usr/lib/engines/*

cp src/iPhoneOS-armv7/openssl-1.0.2l/apps/openssl.cnf deb/etc/ssl/ 
chmod 644 deb/etc/ssl/openssl.cnf

cp src/iPhoneOS-armv7/openssl-1.0.2l/tools/c_hash deb/usr/lib/ssl/misc/
cp src/iPhoneOS-armv7/openssl-1.0.2l/tools/c_info deb/usr/lib/ssl/misc/
cp src/iPhoneOS-armv7/openssl-1.0.2l/tools/c_issuer deb/usr/lib/ssl/misc/
cp src/iPhoneOS-armv7/openssl-1.0.2l/tools/c_name deb/usr/lib/ssl/misc/
cp src/iPhoneOS-armv7/openssl-1.0.2l/apps/CA.pl deb/usr/lib/ssl/misc/
cp src/iPhoneOS-armv7/openssl-1.0.2l/apps/CA.sh deb/usr/lib/ssl/misc/
cp src/iPhoneOS-armv7/openssl-1.0.2l/apps/tsget deb/usr/lib/ssl/misc/
chmod 755 deb/usr/lib/ssl/misc/*

cd deb/usr/lib/ssl
ln -s ../../../etc/ssl/openssl.cnf openssl.cnf
ln -s ../../../etc/ssl/certs certs
ln -s ../../../etc/ssl/private private
cd ..
ln -s libcrypto.1.0.0.dylib libcrypto.dylib
ln -s libssl.1.0.0.dylib libssl.dylib

# Patch:
cd ../bin
sed -e s'/dir = "\/usr"/ dir = "\/usr\/lib\/ssl"/g' c_rehash > c_rehash2
mv c_rehash2 c_rehash
chmod 755 c_rehash
cd ../../../

# make deb
mkdir -p deb/DEBIAN

cat << EOF > deb/DEBIAN/control
Package: openssl
Priority: standard
Section: Security
Installed-Size: 6164
Maintainer: Jay Freeman (saurik) <saurik@saurik.com>
Architecture: iphoneos-arm
Version: 1.0.2l
Pre-Depends: dpkg (>= 1.14.25-8)
Description: SSL library and cryptographic tools
Name: OpenSSL
EOF

dpkg-deb --build --uniform-compression -Zgzip deb openssl_1.0.2l_iphoneos-arm.deb
