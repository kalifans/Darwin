#!/bin/bash


ARMV7="-arch armv7"
ARMV7S="-arch armv7s"
ARM64="-arch arm64"
X86_64="-arch x86_64"


if [ "$1" == "x86_64" ]; then
    ARCH="$X86_64"
    PLATFORM="macosx"
	# VER="10.9"
else
	# ARCH="$ARMV7 $ARMV7S $ARM64"
	ARCH="$ARMV7 $ARMV7S"
	PLATFORM="iphoneos"
	VER="6.1"
fi

# DEVROOT="$HOME/Developer/CommandLineTools/IOSDEVROOT"
export SDKROOT=$(xcrun --sdk $PLATFORM$VER --show-sdk-path)
export CC="$(xcrun -f clang) $ARCH"
export CXX="$(xcrun -f clang++) $ARCH"
# export LD=$DEVROOT/usr/bin/ld
# export AR=$DEVROOT/usr/bin/ar
# export AS=$DEVROOT/usr/bin/as
# export NM=$DEVROOT/usr/bin/nm
# export RANLIB=$DEVROOT/usr/bin/ranlib
export CFLAGS="-I$SDKROOT/usr/include/ -I$HOME/Headers/"
export LDFLAGS="-L$SDKROOT/usr/lib/ -L$HOME/LIBS/"
export CPPFLAGS=$CFLAGS
export CXXFLAGS=$CFLAGS

cp -r Headers $HOME/
mkdir -p $HOME/LIBS

mkdir -p Build/pkg/bin
mkdir -p Build/pkg/sbin
mkdir -p Build/pkg/usr/sbin
mkdir -p Build/pkg/DEBIAN

cat << EOF > Build/pkg/DEBIAN/control
Package: network-cmds
Priority: important
Section: Networking
Installed-Size: 1439
Maintainer: Jay Freeman (saurik) <saurik@saurik.com>
Architecture: iphoneos-arm
Version: 433-1
Pre-Depends: dpkg (>= 1.14.25-8)
Description: arp, ifconfig, netstat, route, traceroute
Name: Network Commands
EOF

###################################
### C Build
###################################
make_fun(){
find * -name "*.c" | sed /\\//d > /tmp/ccc
find * -name "*.cpp" | sed /\\//d >> /tmp/ccc
ALLC=$(cat /tmp/ccc | tr "\n" " ")

if [ "$DYLIB" == "y" ]; then
	if [ "$DKUP" == "y" ]; then
		$CC $CFLAGS $LDFLAGS -shared -undefined dynamic_lookup $ALLC -o $TARGET
		DKUP="n"
		DYLIB="n"
	else
		$CC -dynamiclib $CFLAGS $LDFLAGS $ALLC -o $TARGET
		DYLIB="n"
	fi
else
	$CC $CFLAGS $LDFLAGS $XLINK $ALLC -o $TARGET
fi
}

###################################
### C++ DYLIB Build
###################################
make_o_fun(){
find * -name "*.c" | sed /\\//d > /tmp/ccc
FILE=$(cat /tmp/ccc | sed "s/\.cpp//g" | sed "s/\.c//g")
for i in $FILE; do
    $CC $CFLAGS -c $i.c -o $i.o
done

if [ "$ENABLE_CXX" == "y" ]; then
    find * -name "*.cpp" | sed /\\//d > /tmp/cpp
    FILE=$(cat /tmp/cpp | sed "s/\.cpp//g" | sed "s/\.c//g")
    for i in $FILE; do
        $CC -x c++ $CFLAGS -c $i.cpp -o $i.o
    done
fi

}

link_o_fun(){
find * -name "*.o" | sed /\\//d > /tmp/ooo
ALLO=$(cat /tmp/ooo | tr "\n" " ")
if [ "$ENABLE_CXX" == "y" ]; then
    $CXX -dynamiclib $LDFLAGS $ALLO -o $TARGET
else
    $CC -dynamiclib $LDFLAGS $ALLO -o $TARGET
fi

rm *.o

}

###################################
# libutil1.0.dylib
cd libutil
TARGET="libutil1.0.dylib"
# DYLIB="y"
# DKUP="y"
ENABLE_CXX="y"
make_o_fun
link_o_fun
mv libutil1.0.dylib $HOME/LIBS/libutil1.0.dylib
cp *.h $HOME/Headers/
ln -s $HOME/LIBS/libutil1.0.dylib $HOME/LIBS/libutil.dylib
cd ..

# libalias.A.dylib
cd alias
TARGET="libalias.A.dylib"
DYLIB="y"
make_fun
mv libalias.A.dylib $HOME/LIBS/libalias.A.dylib
cp *.h $HOME/Headers/
cd ..

# arp
cd arp.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv arp ../Build/pkg/usr/sbin/arp
cd ..

# dnctl
cd dnctl
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv dnctl ../Build/pkg/usr/sbin/dnctl
cd ..

# ifconfig
cd ifconfig.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv ifconfig ../Build/pkg/sbin/ifconfig
cd ..

# ip6addrctl
cd ip6addrctl.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv ip6addrctl ../Build/pkg/sbin/ip6addrctl
cd ..

# ip6fw
cd ip6fw.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv ip6fw ../Build/pkg/sbin/ip6fw
cd ..

# ipfw
cd ipfw.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv ipfw ../Build/pkg/sbin/ipfw
cd ..

# kdumpd
cd kdumpd.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv kdumpd ../Build/pkg/usr/sbin/kdumpd
cd ..

# mnc
cd mnc.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv mnc ../Build/pkg/usr/sbin/mnc
cd ..

# mtest
cd mtest.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv mtest ../Build/pkg/usr/sbin/mtest
cd ..

# natd
cd natd.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
XLINK="-lalias.A"
make_fun
mv natd ../Build/pkg/usr/sbin/natd
cd ..

# ndp
cd ndp.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv ndp ../Build/pkg/usr/sbin/ndp
cd ..

# netstat
cd netstat.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv netstat ../Build/pkg/sbin/netstat
cd ..

# ping
cd ping.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv ping ../Build/pkg/bin/ping
cd ..

# ping6
cd ping6.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv ping6 ../Build/pkg/sbin/ping6
cd ..

# pktapctl
cd pktapctl
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv pktapctl ../Build/pkg/usr/sbin/pktapctl
cd ..

# rarpd
cd rarpd.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv rarpd ../Build/pkg/usr/sbin/rarpd
cd ..

# route
cd route.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv route ../Build/pkg/sbin/route
cd ..

# rtadvd *
cd rtadvd.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
XLINK="-lutil"
make_fun
mv rtadvd ../Build/pkg/usr/sbin/rtadvd
cd ..

# rtsol
cd rtsol.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv rtsol ../Build/pkg/sbin/rtsol
cd ..

# spray *
cd spray.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv spray ../Build/pkg/usr/sbin/spray
cd ..

# traceroute
cd traceroute.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv traceroute ../Build/pkg/usr/sbin/traceroute
cd ..

# traceroute6
cd traceroute6.tproj
TARGET="$(basename $(pwd) | sed 's/.tproj//')"
make_fun
mv traceroute6 ../Build/pkg/usr/sbin/traceroute6
cd ..

# make ios arm deb
# cd Build
# dpkg-deb --build --uniform-compression -Zgzip pkg network-cmds_443-1_iphoneos-arm.deb

# rm -r Build
rm -r $HOME/Headers
rm -r $HOME/LIBS

