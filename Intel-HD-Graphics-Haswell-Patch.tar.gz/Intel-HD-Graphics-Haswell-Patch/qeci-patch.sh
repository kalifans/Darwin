#!/bin/bash

################################################
### Intel HD Graphics Haswell-UTL GT1 Patch
################################################
PRODUCT_VER=$(sw_vers -productVersion)
OSVER=$(echo ${PRODUCT_VER%.*})
VER_NUM=$(echo $OSVER | awk -F'.' '{print $2}')

################################################
qeci108_fun(){
### AppleIntelHD5000GraphicsVADriver Patch
sudo perl -pi -e 's|\x0F\x8F\x31\x01\x00\x00|\xE9\x76\x01\x00\x00\x90|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo chown 0:0 /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo chmod 755 /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver

### AppleIntelHD5000Graphics Patch
sudo perl -pi -e 's|\x83\xF8\x02\x75\x0D|\x83\xF8\x02\x90\x90|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo perl -pi -e 's|\x0F\x8F\xE7\x00\x00\x00|\xE9\xF8\x00\x00\x00\x90|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo sed -i "" 's/0x0a268086/0x0a068086/g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/Info.plist
sudo chown 0:0 /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo chmod 755 /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics

}

################################################
qeci109_fun(){
### libCLVMIGILPlugin.dylib Patch
sudo perl -pi -e 's|\x81\xFF\x85\x80\x26\x0A|\x81\xFF\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xFF\x86\x80\x26\x0A|\x81\xFF\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xF9\x85\x80\x26\x0A|\x81\xF9\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xF9\x86\x80\x26\x0A|\x81\xF9\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x3D\x85\x80\x26\x0A|\x3D\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x3D\x86\x80\x26\x0A|\x3D\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo chown 0:0 /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo chmod 755 /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib

### AppleIntelHD5000GraphicsVADriver Patch
sudo perl -pi -e 's|\x0F\x85\x55\x01\x00\x00\x8B\x4D\xF0|\xE9\x8D\x01\x00\x00\x90\x8B\x4D\xF0|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo perl -pi -e 's|\x0F\x85\x55\x01\x00\x00\x8B\x4D\xF8|\xE9\x8C\x01\x00\x00\x90\x8B\x4D\xF8|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo chown 0:0 /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo chmod 755 /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver

### AppleIntelHD5000Graphics Patch
sudo perl -pi -e 's|\x83\xF8\x02\x0F\x85\xD3\x00\x00\x00|\x83\xF8\x02\x90\x90\x90\x90\x90\x90|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo perl -pi -e 's|\x41\x8B\x87\xBC\x0C\x00\x00|\xE9\x5F\x01\x00\x00\x90\x90|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo sed -i "" 's/0x0a268086/0x0a068086/g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/Info.plist
sudo chown 0:0 /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo chmod 755 /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics

}

################################################
qeci1010_fun(){
### libCLVMIGILPlugin.dylib Patch
sudo perl -pi -e 's|\x81\xFF\x85\x80\x26\x0A|\x81\xFF\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xFF\x86\x80\x26\x0A|\x81\xFF\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x41\x81\xFD\x85\x80\x26\x0A|\x41\x81\xFD\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x41\x81\xFD\x86\x80\x26\x0A|\x41\x81\xFD\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x3D\x85\x80\x12\x04|\x3D\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x3D\x85\x80\x01\x09|\x3D\x85\x80\x01\x0B|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x3D\x86\x80\x12\x04|\x3D\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xF9\x85\x80\x26\x0A|\x81\xF9\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xF9\x86\x80\x26\x0A|\x81\xF9\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xFB\x85\x80\x26\x0A|\x81\xFB\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xFB\x86\x80\x26\x0A|\x81\xFB\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo chown 0:0 /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo chmod 755 /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib

### AppleIntelHD5000GraphicsVADriver Patch
sudo perl -pi -e 's|\x81\xF9\x86\x80\x12\x04|\x81\xF9\x86\x80\x06\x0A|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo perl -pi -e 's|\xC7\x83\x54\x99\x00\x00\x01\x00\x00\x00|\xC7\x83\x54\x99\x00\x00\x00\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo perl -pi -e 's|\xC7\x83\x5C\x99\x00\x00\x8C\x00\x00\x00|\xC7\x83\x5C\x99\x00\x00\x46\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo perl -pi -e 's|\xC7\x86\xE4\x4D\x00\x00\x01\x00\x00\x00|\xC7\x86\xE4\x4D\x00\x00\x00\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo perl -pi -e 's|\xC7\x86\xEC\x4D\x00\x00\x8C\x00\x00\x00|\xC7\x86\xEC\x4D\x00\x00\x46\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo chown 0:0 /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo chmod 755 /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver

### AppleIntelHD5000Graphics Patch
sudo perl -pi -e 's|\x83\xF8\x02\x75\x3D|\x83\xF8\x02\x90\x90|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo perl -pi -e 's|\x3D\x86\x80\x12\x04|\x3D\x86\x80\x06\x0A|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo perl -pi -e 's|\x41\xC7\x86\x44\x0F\x00\x00\x01\x00\x00\x00|\x41\xC7\x86\x44\x0F\x00\x00\x00\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo sed -i "" 's/0x0a268086/0x0a068086/g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/Info.plist
sudo chown 0:0 /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo chmod 755 /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics

}

################################################
qeci1011_fun(){
### libCLVMIGILPlugin.dylib Patch
sudo perl -pi -e 's|\x81\xFF\x85\x80\x26\x0A|\x81\xFF\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xFF\x86\x80\x26\x0A|\x81\xFF\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x41\x81\xFD\x85\x80\x26\x0A|\x41\x81\xFD\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x41\x81\xFD\x86\x80\x26\x0A|\x41\x81\xFD\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x3D\x85\x80\x26\x0A|\x3D\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x3D\x86\x80\x26\x0A|\x3D\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xF9\x85\x80\x26\x0A|\x81\xF9\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xF9\x86\x80\x26\x0A|\x81\xF9\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xFB\x85\x80\x26\x0A|\x81\xFB\x85\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo perl -pi -e 's|\x81\xFB\x86\x80\x26\x0A|\x81\xFB\x86\x80\x06\x0A|g' /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo chown 0:0 /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib
sudo chmod 755 /System/Library/Frameworks/OpenCL.framework/Versions/A/Libraries/libCLVMIGILPlugin.dylib

### AppleIntelHD5000GraphicsVADriver Patch
sudo perl -pi -e 's|\x81\xF9\x86\x80\x12\x04|\x81\xF9\x86\x80\x06\x0A|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo perl -pi -e 's|\xC7\x83\x54\x98\x00\x00\x01\x00\x00\x00|\xC7\x83\x54\x98\x00\x00\x00\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo perl -pi -e 's|\xC7\x83\x5C\x98\x00\x00\x8C\x00\x00\x00|\xC7\x83\x5C\x98\x00\x00\x46\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo perl -pi -e 's|\xC7\x86\x60\x4D\x00\x00\x01\x00\x00\x00|\xC7\x86\x60\x4D\x00\x00\x00\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo perl -pi -e 's|\xC7\x86\x68\x4D\x00\x00\x8C\x00\x00\x00|\xC7\x86\x68\x4D\x00\x00\x46\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo chown 0:0 /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver
sudo chmod 755 /System/Library/Extensions/AppleIntelHD5000GraphicsVADriver.bundle/Contents/MacOS/AppleIntelHD5000GraphicsVADriver

### AppleIntelHD5000Graphics Patch
sudo perl -pi -e 's|\x83\xF8\x02\x75\x4D|\x83\xF8\x02\x90\x90|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo perl -pi -e 's|\x3D\x86\x80\x12\x04|\x3D\x86\x80\x06\x0A|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo perl -pi -e 's|\x41\xC7\x86\x44\x10\x00\x00\x01\x00\x00\x00\xB8\x01\x00\x00\x00|\x41\xC7\x86\x44\x10\x00\x00\x00\x00\x00\x00\xB8\x00\x00\x00\x00|g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo sed -i "" 's/0x0a268086/0x0a068086/g' /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/Info.plist
sudo chown 0:0 /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics
sudo chmod 755 /System/Library/Extensions/AppleIntelHD5000Graphics.kext/Contents/MacOS/AppleIntelHD5000Graphics

}

#############################################
### AppleIntelFramebufferAzul Patch
#############################################
framebuffer_fun(){
sudo perl -pi -e 's|\x00\x00\x16\x0a|\x00\x00\x06\x0a|g' /System/Library/Extensions/AppleIntelFramebufferAzul.kext/Contents/MacOS/AppleIntelFramebufferAzul
sudo perl -pi -e 's|\x05\x00\x26\x0A|\x03\x00\x06\x0a|g' /System/Library/Extensions/AppleIntelFramebufferAzul.kext/Contents/MacOS/AppleIntelFramebufferAzul

# 0x0a060003 VRAM 1024MB Patch
sudo perl -pi -e 's|\x00\x00\x50\x00\x00\x00\x00\x60|\x00\x00\x50\x00\x00\x00\x00\x40|g' /System/Library/Extensions/AppleIntelFramebufferAzul.kext/Contents/MacOS/AppleIntelFramebufferAzul

sudo sed -i "" 's/0x0a268086/0x0a068086/g' /System/Library/Extensions/AppleIntelFramebufferAzul.kext/Contents/Info.plist

sudo chown -R root:wheel /System/Library/Extensions/AppleIntelFramebufferAzul.kext 
sudo chmod 755 /System/Library/Extensions/AppleIntelFramebufferAzul.kext/Contents/MacOS/AppleIntelFramebufferAzul

}

#############################################
### Rebuild Kernel Caches
#############################################
rekern_caches_fun(){
sudo rm -r /System/Library/Caches/*
sudo rm -rf /System/Library/PrelinkedKernels/prelinkedkernel
sudo touch /System/Library/Extensions/
sudo kextcache -a x86_64 -e

}

################################################
# Binary Patch
################################################
if [ "$VER_NUM" == "8" ]; then
    # macos 10.8.5
    qeci108_fun
elif [ "$VER_NUM" == "9" ]; then
    # macos 10.9.5
    qeci109_fun

elif [ "$VER_NUM" == "10" ]; then
    # macos 10.10.5
    qeci1010_fun

elif [ "$VER_NUM" == "11" ]; then
    # macos 10.11.6
    qeci1011_fun
fi

framebuffer_fun
rekern_caches_fun
