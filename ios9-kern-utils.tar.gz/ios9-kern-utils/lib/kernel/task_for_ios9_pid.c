#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <mach/mach_init.h>
#include <mach/mach_types.h>
#include <mach/host_priv.h>
#include <mach/vm_map.h>

#include <libkern.h>
#include <mach-o/binary.h>


kern_return_t task_for_ios9_pid(mach_port_name_t target_tport,int pid,mach_port_name_t *kernel_task)
{
    kern_return_t kr;
    kr = task_for_pid(target_tport, pid, kernel_task);
    if ( kr )
    {
        printf("[ERROR] %s Line %d, result=%08x: \n","task_for_pid",__LINE__,kr);
        kr = host_get_special_port(mach_host_self(),0,4,kernel_task);
        if ( kr )
        {
            printf("[ERROR] %s Line %d, result=%08x: \n","host_get_special_port",__LINE__,kr);
        }
        else
        {
            printf("Calling host_get_special_port(mach_host_self(),0,4,kernel_task),sucess!\n");
        }
    }
    return kr;
}