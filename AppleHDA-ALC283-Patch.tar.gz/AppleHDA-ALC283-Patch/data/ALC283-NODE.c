
Verbs from Linux Codec Dump File: codec-Realtek-ALC283

Codec: Realtek ALC283   Address: 0   DevID: 283902595 (0x10ec0283)

   Jack   Color  Description                  Node     PinDefault             Original Verbs
--------------------------------------------------------------------------------------------------------
Digital Unknown  Mic at Int N/A              18 0x12   0x90a60130   01271c30 01271d01 01271ea6 01271f90
 Analog Unknown  Speaker at Int N/A          20 0x14   0x90170110   01471c10 01471d01 01471e17 01471f90
    1/4 Unknown  Line Out at Ext N/A         23 0x17   0x40020008   01771c08 01771d00 01771e02 01771f40
    1/8   Black  Speaker at Ext Rear         24 0x18   0x411111f0   01871cf0 01871d11 01871e11 01871f41
    1/8   Black  Speaker at Ext Rear         25 0x19   0x411111f0   01971cf0 01971d11 01971e11 01971f41
    1/8   Black  Speaker at Ext Rear         26 0x1a   0x411111f0   01a71cf0 01a71d11 01a71e11 01a71f41
 Speaker at Ext  Rear			             27 0x1b   1091637744   01b71cf0 01b71d11 01b71e11 01b71f41  
Unknown Unknown  Reserved at Ext N/A         29 0x1d   0x40e00001   01d71c01 01d71d00 01d71ee0 01d71f40
    1/8   Black  Speaker at Ext Rear         30 0x1e   0x411111f0   01e71cf0 01e71d11 01e71e11 01e71f41
    1/8   Black  HP Out at Ext Left          33 0x21   0x0321101f   02171c1f 02171d10 02171e21 02171f03
--------------------------------------------------------------------------------------------------------


   Jack   Color  Description                  Node     PinDefault             Modified Verbs
--------------------------------------------------------------------------------------------------------
Digital Unknown  Mic at Int N/A              18 0x12   0x90a60130   01271c30 01271d00 01271ea6 01271f90
 Analog Unknown  Speaker at Int N/A          20 0x14   0x90170110   01471c10 01471d00 01471e17 01471f90
    1/4 Unknown  Line Out at Ext N/A         23 0x17   0x40020008   01771c20 01771d00 01771e02 01771f40
Unknown Unknown  Reserved at Ext N/A         29 0x1d   0x40e00001   01d71c40 01d71d00 01d71ee0 01d71f40
    1/8   Black  HP Out at Ext Left          33 0x21   0x0321101f   02171c50 02171d10 02171e21 02171f00
--------------------------------------------------------------------------------------------------------

Modified Verbs in One Line: 01271c30 01271d00 01271ea6 01271f90 01471c10 01471d00 01471e17 01471f90 01771c20 01771d00 01771e02 01771f40 01d71c40 01d71d00 01d71ee0 01d71f40 02171c50 02171d10 02171e21 02171f00
--------------------------------------------------------------------------------------------------------

Digital Unknown  Mic at Int N/A             18 0x12   0x90a60130   01271c30 01271d00 01271ea6 01271f90
Analog Unknown  Speaker at Int N/A          20 0x14   0x90170110   01471c10 01471d00 01471e17 01471f90
    1/8   Black  Speaker at Ext Rear        25 0x19   0x411111f0   01971cf0 01971d11 01971e11 01971f41
    1/8   Black  HP Out at Ext Left         33 0x21   0x0321101f   02171c50 02171d10 02171e21 02171f00

# IN:
Mic Int             18 0x12
NODE: 0x11(17) -> 0x12(18)

Mic Ext / Line Int  25 0x19
NODE: 0x8(8)-> 0x23 (35) -> 0x19(25)

# OUT:
Speaker             20 0x14
NODE: 0x14(20) -> 0xC(12) -> 0x2(2)

HP OUT              33 0x21
NODE: 0x21(33) -> 0xD(13) -> 0x3(3)

ConfigData:
		PinDefault
Node        c  d  e  f      Description
0x12		30 01 A6 90		Mic at Int N/A
0x14		10 01 17 90		Speaker at Int N/A
0x17		08 00 02 40		Line Out at Ext N/A
0x21		1F 10 21 03		HP Out at Ext Left

Address + Node + 71c +【c】
Address + Node + 71d +【d】
Address + Node + 71e +【e】
Address + Node + 71f +【f】

01271C10 01271D01 01271EA0 01271F90 
01471C20 01471D01 01471E17 01471F90 
01971C30 01971D00 01971E8B 01971F00 
02171C40 02171D10 02171E2B 02171F01 

SET_EAPD_BTLENABLE at 0x14 & 0x21:
01470C02 02170C02
