DEC
perl zlib.pl inflate Platforms.xml.zlib > Platforms.xml
perl zlib.pl inflate layout66.xml.zlib > layout66.xml


ENC
perl zlib.pl deflate Platforms.xml > Platforms.xml.zlib
perl zlib.pl deflate layout66.xml > layout66.xml.zlib

