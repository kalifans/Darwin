################################################
### AppleHDA Patch for ALC 283 10.8.5 - 10.10.5
################################################
# Binary Patch
sudo perl -pi -e 's|\x3D\x84\x08\xEC\x10|\x3D\x00\x00\x00\x00|g' /System/Library/Extensions/AppleHDA.kext/Contents/MacOS/AppleHDA
sudo perl -pi -e 's|\x3D\x85\x08\xEC\x10|\x3D\x00\x00\x00\x00|g' /System/Library/Extensions/AppleHDA.kext/Contents/MacOS/AppleHDA
sudo perl -pi -e 's|\x3D\x84\x19\xD4\x11|\x3D\x83\x02\xEC\x10|g' /System/Library/Extensions/AppleHDA.kext/Contents/MacOS/AppleHDA

sudo chown 0:0 /System/Library/Extensions/AppleHDA.kext/Contents/MacOS/AppleHDA
sudo chmod 755 /System/Library/Extensions/AppleHDA.kext/Contents/MacOS/AppleHDA

# Replace layout
sudo rm /System/Library/Extensions/AppleHDA.kext/Contents/Resources/layout3.xml.zlib
sudo rm /System/Library/Extensions/AppleHDA.kext/Contents/Resources/Platforms.xml.zlib
sudo cp layout/layout3.xml.zlib /System/Library/Extensions/AppleHDA.kext/Contents/Resources/
sudo cp layout/Platforms.xml.zlib /System/Library/Extensions/AppleHDA.kext/Contents/Resources/

# add ALC283 ConfigData
sudo sed -i "" -ne 'p;/HDAConfigDefault/n' /System/Library/Extensions/AppleHDA.kext/Contents/PlugIns/AppleHDAHardwareConfigDriver.kext/Contents/Info.plist

sudo sed -i "" '/HDAConfigDefault/ a\
***<array>\
****<dict>\
*****<key>AFGLowPowerState</key>\
*****<data>AwAAAA==</data>\
*****<key>Codec</key>\
*****<string>Mirone - Realtek ALC283</string>\
*****<key>CodecID</key>\
*****<integer>283902595</integer>\
*****<key>ConfigData</key>\
*****<data>\
*****ASccEAEnHQEBJx6gAScfkAFHHCABRx0BAUce\
*****FwFHH5ABlxwwAZcdAAGXHosBlx8AAhccQAIX\
*****HRACFx4rAhcfAQFHDAICFwwC\
*****</data>\
*****<key>FuncGroup</key>\
*****<integer>1</integer>\
*****<key>LayoutID</key>\
*****<integer>3</integer>\
*****<key>WakeConfigData</key>\
*****<data>AUcMAg==</data>\
*****<key>WakeVerbReinit</key>\
*****<true/>\
****</dict>
' /System/Library/Extensions/AppleHDA.kext/Contents/PlugIns/AppleHDAHardwareConfigDriver.kext/Contents/Info.plist

sudo perl -pi -e 's|\x2A|\x09|g' /System/Library/Extensions/AppleHDA.kext/Contents/PlugIns/AppleHDAHardwareConfigDriver.kext/Contents/Info.plist

################################################
### Rebuild Kernel Caches
################################################
sudo rm -r /System/Library/Caches/*
sudo kextcache -a x86_64 -e
# sudo shutdown -r now
