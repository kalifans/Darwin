# Linux Make
export SYSROOT="$HOME/SDK/iPhoneOS6.1.sdk"
export CC="gcc"
export CXX="g++"
export CFLAGS="-I/usr/include/ -I."
export LDFLAGS="-L/usr/lib/ -L/usr/local/lib/"

# ALLC="finders.c functions.c patchers.c iBoot32Patcher.c"
# TARGET="iBoot32Patcher"
# $CC $CFLAGS $LDFLAGS $ALLC -o $TARGET

$CC $CFLAGS -c finders.c -o finders.o
$CC $CFLAGS -c functions.c -o functions.o
$CC $CFLAGS -c patchers.c -o patchers.o
$CC $CFLAGS -c iBoot32Patcher.c -o iBoot32Patcher.o

LIBS=""
ALLO="finders.o functions.o patchers.o iBoot32Patcher.o"
$CC $LDFLAGS $LIBS $ALLO -o iBoot32Patcher

