//
//  cydia.m
//  Trident
//
//  Created by Kali on 2017/8/5.
//  Copyright © 2017年 Benjamin Randazzo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sys/mount.h>
#import <spawn.h>

#import <mach-o/dyld.h>
#import <sys/stat.h>
#import <copyfile.h>

void cydia_inst(void) {

    char* nmz = strdup("/dev/disk0s1s1");
    mount( "hfs", "/", MNT_UPDATE, (void*)&nmz);
    system("/sbin/mount -t hfs -o update /dev/disk0s1s1 /");

    char path[256];
    uint32_t size = sizeof(path);
    _NSGetExecutablePath(path, &size);
    char* pt = realpath(path, 0);
    
    __block pid_t pd = 0;
    NSString* execpath = [[NSString stringWithUTF8String:pt]  stringByDeletingLastPathComponent];
    
    int f = open("/.installed_cydia", O_RDONLY);
    
    if (f == -1) {
        // copy tar
        NSString* tar = [execpath stringByAppendingPathComponent:@"tar"];
        NSString* cydia = [execpath stringByAppendingPathComponent:@"cydia.tar"];

        const char* jtar = [tar UTF8String];
        unlink("/bin/tar");
        copyfile(jtar, "/bin/tar", 0, COPYFILE_ALL);
        chmod("/bin/tar", 0777);
        jtar="/bin/tar";

        chdir("/");

        // install cydia
        posix_spawn(&pd, jtar, 0, 0, (char**)&(const char*[]){jtar, "--preserve-permissions", "--no-overwrite-dir", "-xvf", [cydia UTF8String], NULL}, NULL);
        waitpid(pd, 0, 0);
        open("/.installed_cydia", O_RDWR|O_CREAT);

        // copy launchctl
        NSString* jlaunchctl = [execpath stringByAppendingPathComponent:@"launchctl"];
        const char* jlctl = [jlaunchctl UTF8String];
        copyfile(jlctl, "/bin/launchctl", 0, COPYFILE_ALL);
        chmod("/bin/launchctl", 0755);

        // copy reload
        //NSString* reload = [execpath stringByAppendingPathComponent:@"reload"];
        //const char* jreload = [reload UTF8String];
        //unlink("/usr/libexec/reload");
        //copyfile(jreload, "/usr/libexec/reload", 0, COPYFILE_ALL);
        //chmod("/usr/libexec/reload", 0755);
        //chown("/usr/libexec/reload", 0, 0);
        
        // copy reload.plist
        //NSString* rplist = [execpath stringByAppendingPathComponent:@"0.reload.plist"];
        //const char* jrplist = [rplist UTF8String];
        //unlink("/Library/LaunchDaemons/0.reload.plist");
        //copyfile(jrplist, "/Library/LaunchDaemons/0.reload.plist", 0, COPYFILE_ALL);
        //chmod("/Library/LaunchDaemons/0.reload.plist", 0644);
        //chown("/Library/LaunchDaemons/0.reload.plist", 0, 0);


        // install untether
        NSString* untether = [execpath stringByAppendingPathComponent:@"untether.tar"];
        const char* juntether = [untether UTF8String];
        copyfile(juntether, "/tmp/untether.tar", 0, COPYFILE_ALL);
        chmod("/tmp/untether.tar", 0777);
        system("/bin/tar xvf /tmp/untether.tar");
        system("/untether/install");
        system("/bin/touch /untether/insted");

        //remove nosuid
        system("/bin/sed -i 's/,nosuid,nodev//g' /private/etc/fstab");

        //changing permissions
        //chmod("/private", 0777);
        //chmod("/private/var", 0777);
        //chmod("/private/var/mobile", 0777);
        //chmod("/private/var/mobile/Library", 0777);
        //chmod("/private/var/mobile/Library/Preferences", 0777);
        
        // remove ota update
        system("/bin/rm /System/Library/LaunchDaemons/com.apple.mobile.softwareupdated.plist");
        system("/bin/rm /System/Library/LaunchDaemons/com.apple.softwareupdateservicesd.plist");
        system("/bin/rm -rf /private/var/mobile/Library/Assets/com_apple_MobileAsset_SoftwareUpdate/*");
        system("/bin/rm -rf /private/var/mobile/Library/Assets/com_apple_MobileAsset_SoftwareUpdateDocumentation/*");

    }

    //start openssh service
    int ssh = open("/Library/LaunchDaemons/com.openssh.sshd.plist", O_RDONLY);
    if (ssh) {
        system("/bin/launchctl load /Library/LaunchDaemons/com.openssh.sshd.plist");
    }

    // restart springboard
    system("/usr/bin/killall -SIGSTOP cfprefsd");

    NSMutableDictionary* md = [[NSMutableDictionary alloc] initWithContentsOfFile:@"/var/mobile/Library/Preferences/com.apple.springboard.plist"];
    [md setObject:[NSNumber numberWithBool:YES] forKey:@"SBShowNonDefaultSystemApps"];
    [md writeToFile:@"/var/mobile/Library/Preferences/com.apple.springboard.plist" atomically:YES];

    system("/usr/bin/killall -9 cfprefsd");

    // no move /Applications to stash dir
    //system("/bin/touch /.cydia_no_stash");

    system("su mobile -c uicache");
    //system("killall backboardd");
    //system("/sbin/reboot");

}
