//
//  ViewController.h
//  Trident
//
//  Created by Benjamin Randazzo on 06/11/2016.
//  Copyright © 2016 Benjamin Randazzo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
