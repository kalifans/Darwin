#!/bin/bash


# DEVROOT="$HOME/Developer/CommandLineTools/IOSDEVROOT"
export SDKROOT=$(xcrun --sdk iphoneos --show-sdk-path)
export CC="$(xcrun -f clang) -arch armv7"
# export CXX="$(xcrun -f clang++) $ARCH"
# export LD=$DEVROOT/usr/bin/ld
# export AR=$DEVROOT/usr/bin/ar
# export AS=$DEVROOT/usr/bin/as
# export NM=$DEVROOT/usr/bin/nm
# export RANLIB=$DEVROOT/usr/bin/ranlib
export CFLAGS="-I$SDKROOT/usr/include/ -IHeaders/"
export LDFLAGS="-L$SDKROOT/usr/lib/"
# export CPPFLAGS=$CFLAGS
# export CXXFLAGS=$CFLAGS
# FRAMEWORKS="-framework IOKit"
SIGN_FLAGS="codesign -s - --entitlements ent.xml"
# SIGN_FLAGS="ldid -Sent.xml"
TARGER="exploit"
SRC="main.c"

TARGET="exploit"
$CC $CFLAGS $LDFLAGS $FRAMEWORKS $SRC -o $TARGER
$SIGN_FLAGS $TARGER
