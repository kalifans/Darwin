//
//  main.c
//  exp
//
//  Created by Kali on 2017/9/1.
//  Copyright (c) 2017年 Kali. All rights reserved.
//

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/kauth.h>
#include <sys/stat.h>

#include <pthread.h>

#include <mach/mach.h>
#include <mach/clock.h>
#include <sys/mount.h>
#include <assert.h>
#include <IOKit/IOKitLib.h>


#define DEFAULT_KERNEL_SLIDE    0x80000000
static vm_address_t kernel_base = DEFAULT_KERNEL_SLIDE;

static mach_port_t kernel_task = 0;

vm_address_t get_kernel_base()
{
    kern_return_t ret;
    task_t kernel_task;
    vm_region_submap_info_data_64_t info;
    vm_size_t size;
    mach_msg_type_number_t info_count = VM_REGION_SUBMAP_INFO_COUNT_64;
    unsigned int depth = 0;
    vm_address_t addr = 0x81200000; /* arm64: addr = 0xffffff8000000000 */

    ret = task_for_pid(mach_task_self(), 0, &kernel_task);
    if (ret != KERN_SUCCESS)
        return -1;

    while (1) {
        ret = vm_region_recurse_64(kernel_task, &addr, &size, &depth, (vm_region_info_t) & info, &info_count);
        if (ret != KERN_SUCCESS)
            break;
        if (size > 1024 * 1024 * 1024) {
            /*
             * https://code.google.com/p/iphone-dataprotection/
             * hax, sometimes on iOS7 kernel starts at +0x200000 in the 1Gb region
             */
            pointer_t buf;
            mach_msg_type_number_t sz = 0;
            addr += 0x200000;
            vm_read(kernel_task, addr + 0x1000, 512, &buf, &sz);
            if (*((uint32_t *)buf) != 0xfeedface) {
                addr -= 0x200000;
                vm_read(kernel_task, addr + 0x1000, 512, &buf, &sz);
                if (*((uint32_t*)buf) != 0xfeedface) {
                    break;
                }
            }
            return addr;
        }
        addr += size;
    }

    return -1;
}

void lwvm_patch(uint32_t kernel_base, mach_port_name_t kernel_task) {
    uint32_t nop32 = 0x46C046C0;
    uint32_t lwnm_addr = 0xB6373A + 0x1000 + kernel_base;
    vm_write(kernel_task, lwnm_addr, (vm_address_t)&nop32, 4); // nop
    
    uint8_t branch8 = 0xe0;
    uint32_t remount_addr = 0xEF679 + 0x1000 + kernel_base;
    vm_write(kernel_task, remount_addr, (vm_address_t)&branch8, 1); // b
    
    uint32_t remount_addr2 = 0x14 + remount_addr;
    vm_write(kernel_task, remount_addr2, (vm_address_t)&branch8, 1); // b
}

void amfi_patch(uint32_t kernel_base, mach_port_name_t kernel_task) {
    uint32_t amfi_patch_addr = 0x7640EC + 0x1000 + kernel_base;
    uint32_t branch_target_addr = 1 + 0x1DB30 + 0x1000 + kernel_base;
    vm_write(kernel_task, amfi_patch_addr, (vm_address_t)&branch_target_addr, 4);
}

void i_can_has_debugger_patch(uint32_t kernel_base, mach_port_name_t kernel_task) {
    uint8_t ichd1 = 0x1;
    uint32_t i_can_has_debugger_addr = 0x3AA734 + 0x1000 + kernel_base;
    vm_write(kernel_task, i_can_has_debugger_addr, (vm_address_t)&ichd1, 1);
}

void real_vm_map_enter_patch(uint32_t kernel_base, mach_port_name_t kernel_task) {
    uint16_t nop16 = 0xbf00;
    uint32_t real_vm_map_enter_addr = 0xD6344 + 0x1000 + kernel_base;
    vm_write(kernel_task, real_vm_map_enter_addr, (vm_address_t)&nop16, 2);
    
    uint32_t nop32 = 0xbf00bf00;
    uint32_t real_vm_map_enter_addr2 = 0x10 + real_vm_map_enter_addr;
    vm_write(kernel_task, real_vm_map_enter_addr2, (vm_address_t)&nop32, 4);
}

void real_vm_map_protect_patch(uint32_t kernel_base, mach_port_name_t kernel_task) {
    uint32_t nop32 = 0xbf00bf00;
    uint32_t real_vm_map_protect_addr = 0x7EECE + 0x1000 + kernel_base;
    vm_write(kernel_task, real_vm_map_protect_addr, (vm_address_t)&nop32, 4);
}

void task_for_pid_0ff(uint32_t kernel_base, mach_port_name_t kernel_task) {
    uint32_t task_for_pid_base = 0x2fe034 + 0x1000 + kernel_base;
    uint32_t pid_check_addr = 0x16 + task_for_pid_base;
    uint8_t tfp_patch = 0xff;
    vm_write(kernel_task, pid_check_addr, (vm_address_t)&tfp_patch, 1); // cmp r6, #ff
}

void cs_enforcement_disable_amfi(uint32_t kernel_base, mach_port_name_t kernel_task) {
    uint8_t cs1 = 0x1;
    uint32_t cs_enforcement_disable_addr = 0x764BE9 + 0x1000 + kernel_base;
    vm_write(kernel_task, cs_enforcement_disable_addr, (vm_address_t)&cs1, 1);
    
    uint32_t cs_enforcement_disable_addr2 = 0x23 + cs_enforcement_disable_addr;
    vm_write(kernel_task, cs_enforcement_disable_addr2, (vm_address_t)&cs1, 1);
}

void sandbox_patch(uint32_t kernel_base, mach_port_name_t kernel_task) {
    uint32_t sbops_patch = 0x00000000;
    uint32_t sbops_addr = 0xEB9850 + 0x1000 + kernel_base;
    vm_write(kernel_task, sbops_addr + 0x90, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x1e0, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x3f0, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x3f8, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x3fc, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x400, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x404, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x408, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x40c, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x410, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x414, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x420, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x424, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x42c, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x438, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x44c, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x450, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x454, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x458, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x460, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x464, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x468, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x46c, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x4bc, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x4f0, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x3d4, (vm_address_t)&sbops_patch, 4);
    vm_write(kernel_task, sbops_addr + 0x168, (vm_address_t)&sbops_patch, 4);
}

void remount_rootfs(void) {
    const char *root_fs = "/dev/disk0s1s1";
    mount( "hfs", "/", MNT_UPDATE, (void*)&root_fs);
}


int main(int argc, const char * argv[])
{
    uint32_t chunksize = 2048;
    //pthread_t insert_payload_thread;
    //volatile uint32_t payload_ptr = 0x12345678;
    //uint32_t args[] = {kernel_base, (uint32_t)&payload_ptr};
    char data[4096];
    uint32_t bufpos = 0;
    mach_port_t master = 0, res;
    kern_return_t kr;
    struct stat buf;
    task_t kernel_task;
    pointer_t b;
    uint32_t size;

    kernel_base = get_kernel_base();
    if (kernel_base == (vm_address_t)-1) {
        printf("failed to get kernel_baseel base...\n");
        return -1;
    }

    printf("Kernel base is 0x%08x.\n", kernel_base);

     /*
     * we can now find the kernel pmap. 
     */
    kern_return_t r = task_for_pid(mach_task_self(), 0, &kernel_task);
    if (r != 0) {
        printf("task_for_pid failed.\n");
        return -1;
    }
   

    /* Jailbreak */
    lwvm_patch(kernel_base, kernel_task);
    printf("Patch lwvm.\n");
    amfi_patch(kernel_base, kernel_task);
    printf("Patch amfi.\n");
    i_can_has_debugger_patch(kernel_base, kernel_task);
    printf("Patch i_can_has_debugger.\n");
    real_vm_map_enter_patch(kernel_base, kernel_task);
    printf("Patch real_vm_map_enter.\n");
    real_vm_map_protect_patch(kernel_base, kernel_task);
    printf("Patch real_vm_map_protect.\n");
    task_for_pid_0ff(kernel_base, kernel_task);
    printf("Patch task_for_pid.\n");
    cs_enforcement_disable_amfi(kernel_base, kernel_task);
    printf("Patch cs_enforcement_disable.\n");
    sandbox_patch(kernel_base, kernel_task);
    printf("Patch sandbox.\n");
    //remount_rootfs();
    //printf("Remount FileSystem.\n");

    return 0;
}

