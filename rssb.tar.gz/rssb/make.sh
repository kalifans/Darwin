
DEVROOT=$(xcrun --sdk iphoneos --show-sdk-platform-path)
IOSSDKROOT=$(xcrun --sdk iphoneos --show-sdk-path)
export SDKROOT=$IOSSDKROOT
export CC="$(xcrun -f clang) -arch armv7 -arch armv7s -arch arm64"
export CXX="$(xcrun -f clang++) -arch armv7 -arch armv7s -arch arm64"
export LD=$DEVROOT/usr/bin/ld
export AR=$DEVROOT/usr/bin/ar
export AS=$DEVROOT/usr/bin/as
export NM=$DEVROOT/usr/bin/nm
export RANLIB=$DEVROOT/usr/bin/ranlib
export CFLAGS="-I$SDKROOT/usr/include/"
export LDFLAGS="-L$SDKROOT/usr/lib/"
export CPPFLAGS=$CFLAGS
export CXXFLAGS=$CFLAGS
FRAMEWORKS="-framework Foundation"
SIGN_FLAGS="codesign -s - --entitlements ent.xml"
# SIGN_FLAGS="ldid -Sent.xml"

TARGER="rssb"
SRC="rssb.m"

$CC $CFLAGS $LDFLAGS $FRAMEWORKS $SRC -o $TARGER
$SIGN_FLAGS $TARGER

mkdir -p restartsb/usr/bin
mkdir -p restartsb/DEBIAN
mv rssb restartsb/usr/bin/

cat << EOF > restartsb/DEBIAN/control
Package: rssb
Priority: optional
Section: System
Installed-Size: 208
Maintainer: Torachiyo
Architecture: iphoneos-arm
Version: 1.0
Pre-Depends: dpkg (>= 1.14.25-8)
Description: Restart SpringBoard
EOF

dpkg -b restartsb rssb_1.0_iphoneos-arm.deb
