//
//  main.c
//  restartsb
//
//  Created by Kali on 2017/9/5.
//  Copyright (c) 2017年 Kali. All rights reserved.
//

#include <Foundation/Foundation.h>
#include <stdio.h>

int main()
{

    // Restart SpringBoard
    system("/usr/bin/killall -SIGSTOP cfprefsd");

    NSMutableDictionary* md = [[NSMutableDictionary alloc] initWithContentsOfFile:@"/var/mobile/Library/Preferences/com.apple.springboard.plist"];
    [md setObject:[NSNumber numberWithBool:YES] forKey:@"SBShowNonDefaultSystemApps"];
    [md writeToFile:@"/var/mobile/Library/Preferences/com.apple.springboard.plist" atomically:YES];

    system("/usr/bin/killall -9 cfprefsd");

    system("su mobile -c uicache");
    system("killall backboardd");

    return 0;
}

