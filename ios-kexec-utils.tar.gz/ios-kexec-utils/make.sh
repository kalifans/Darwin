

VER="6.1"

export SDKROOT=$(xcrun --sdk iphoneos$VER --show-sdk-path)
export CC="$(xcrun -f clang) -arch armv7 -arch armv7s"
export CFLAGS="-I$SDKROOT/usr/include/ -no-integrated-as -DINLINE_IT_ALL"
export LDFLAGS="-L$SDKROOT/usr/lib/ -miphoneos-version-min=6.0"
FRAMEWOEK="-framework IOKit -framework CoreFoundation"
SIGN_FLAGS="codesign -s - --entitlements tfp0.plist"

# kloader
ALLC="kloader.c"
TARGET="kloader"
$CC $CFLAGS $LDFLAGS $FRAMEWOEK $ALLC -o $TARGET
$SIGN_FLAGS $TARGET

# multi_kloader
ALLC="multi_kloader.c"
TARGET="multi_kloader"
$CC $CFLAGS $LDFLAGS $FRAMEWOEK $ALLC -o $TARGET
$SIGN_FLAGS $TARGET

# ibsspatch
ALLC="patch.c util.c ibootsup.c iboot_patcher.c"
TARGET="ibsspatch"
$CC $CFLAGS $LDFLAGS $FRAMEWOEK $ALLC -o $TARGET
$SIGN_FLAGS $TARGET

# img3maker
ALLC="img3maker.c"
TARGET="img3maker"
$CC $CFLAGS $LDFLAGS $FRAMEWOEK $ALLC -o $TARGET
$SIGN_FLAGS $TARGET

mkdir -p BUILD/usr/local/bin
install -c -m 755 multi_kloader BUILD/usr/local/bin
install -c -m 755 kloader BUILD/usr/local/bin
install -c -m 755 ibsspatch BUILD/usr/local/bin
install -c -m 755 img3maker BUILD/usr/local/bin
rm multi_kloader kloader ibsspatch img3maker
