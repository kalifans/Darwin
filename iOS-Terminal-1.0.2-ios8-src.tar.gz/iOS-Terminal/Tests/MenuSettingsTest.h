// MenuSettingsTest.h
// MobileTerminal

#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>

@class MenuSettings;

@interface MenuSettingsTest : SenTestCase {
@private
  MenuSettings* menuSettings;
}

- (void) testMenuSettings;

@end
