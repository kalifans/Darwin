#!/bin/bash

launchctl unload -w /Library/LaunchAgents/com.realtek.LineInSwitch.plist

sudo rm -rf /Library/LaunchAgents/com.realtek.LineInSwitch.plist
sudo rm -rf /usr/bin/LineInSwitch

exit 0
