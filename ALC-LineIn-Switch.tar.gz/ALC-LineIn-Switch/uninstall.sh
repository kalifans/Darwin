#!/bin/bash

sudo launchctl remove /Library/LaunchAgents/com.realtek.LineInSwitch.plist

sudo rm -rf /Library/LaunchAgents/com.realtek.LineInSwitch.plist
sudo rm -rf /usr/bin/LineInSwitch

sudo rm -rf /System/Library/Caches/com.apple.kext.caches/Startup/kernelcache
sudo rm -rf /System/Library/PrelinkedKernels/prelinkedkernel
sudo touch /System/Library/Extensions/ && sudo kextcache -u /

exit 0
