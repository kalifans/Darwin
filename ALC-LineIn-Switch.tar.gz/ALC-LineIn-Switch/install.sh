#!/bin/bash


sudo rm -rf /usr/bin/LineInSwitch
sudo cp LineInSwitch /usr/bin/
sudo chmod 755 /usr/bin/LineInSwitch
sudo chown root:wheel /usr/bin/LineInSwitch

launchctl unload -w /Library/LaunchAgents/com.realtek.LineInSwitch.plist
sudo rm /Library/LaunchAgents/com.realtek.LineInSwitch.plist
sudo cp com.realtek.LineInSwitch.plist /Library/LaunchAgents/
sudo chmod 644 /Library/LaunchAgents/com.realtek.LineInSwitch.plist
sudo chown root:wheel /Library/LaunchAgents/com.realtek.LineInSwitch.plist
launchctl load -w /Library/LaunchAgents/com.realtek.LineInSwitch.plist

exit 0
