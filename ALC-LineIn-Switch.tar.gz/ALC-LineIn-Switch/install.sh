#!/bin/bash

sudo cp LineInSwitch /usr/bin/
sudo chmod 755 /usr/bin/LineInSwitch
sudo chown root:wheel /usr/bin/LineInSwitch

sudo cp com.reltek.LineInSwitch.plist /Library/LaunchAgents/
sudo chmod 644 /Library/LaunchAgents/com.reltek.LineInSwitch.plist
sudo chown root:wheel /Library/LaunchAgents/com.reltek.LineInSwitch.plist
sudo launchctl load /Library/LaunchAgents/com.reltek.LineInSwitch.plist

sudo rm -rf /System/Library/Caches/com.apple.kext.caches/Startup/kernelcache
sudo rm -rf /System/Library/PrelinkedKernels/prelinkedkernel
sudo touch /System/Library/Extensions/ && sudo kextcache -u /

exit 0
