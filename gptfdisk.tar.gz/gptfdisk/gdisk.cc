// gdisk.cc
// Program modelled after Linux fdisk, but it manipulates GPT partitions
// rather than MBR partitions.
//
// by Rod Smith, project began February 2009

// hacked together to make partitioning your iPhone hopefully easy. it's messy but should work. -jon.

/* This program is copyright (c) 2009-2013 by Roderick W. Smith. It is distributed
under the terms of the GNU GPL version 2, as detailed in the COPYING file. */

#include <string.h>
#include <iostream>
#include "gpttext.h"
#include "guid.h"
#include <sys/statvfs.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include "sys/disk.h"
#include <sys/types.h>
#include <sys/stat.h>

#define RESIZE_PARTITION 0x80086802

long long roundUpLongLong(long long numToRound, long long multiple) {
	if (multiple == 0)
		return numToRound;

	long long remainder = numToRound % multiple;
	if (remainder == 0) {
		return numToRound + multiple - remainder + 0x8;
	}
	return numToRound + multiple - remainder;
}

int roundUp(int numToRound, int multiple) {
	if (multiple == 0)
		return numToRound;

	int remainder = numToRound % multiple;
	if (remainder == 0) {
		return numToRound + multiple - remainder + 0x8;
	}
	return numToRound + multiple - remainder;
}

long GetAvailableSpace(const char* path) {
	struct statvfs stat;
	if (statvfs(path, &stat) != 0) {
		return -1;
	}
	return stat.f_bfree;
}

void anErrorOccured() {
	GPTDataTextUI theGPT;
	theGPT.LoadPartitions("/dev/rdisk0s1");
	printf("An error occured. More information should follow.\n");
	theGPT.DisplayGPTData();
	exit(0);
}

int main(int argc, char* argv[]) {

	GPTDataTextUI theGPT;
	string device;
	UnicodeString uString;
	int isError = 0;
	struct stat st;
	string dataPartGUID;

	switch (argc) {
		case 1:
		
		/* no args for normal disk split */
		if (theGPT.LoadPartitions("/dev/rdisk0s1")) {

	//check some things before actually starting.
			if (!stat("/dev/disk0s1s4", &st) && !stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s5", &st)) {
				printf("You already have a partitioned device. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s4", &st)) {
				printf("You have an unexpected partition layout. If you have never messed with them before, please contact me (CoolBooter) so I can add support for your layout. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s5", &st)) {
				printf("You seem to have an extra partition for some reason. If this is knowlingly not your fault, sometimes the LwVM driver does this. A reboot should fix it. Exiting.\n");
				exit(0);
			}


			uint64_t varSize = theGPT.ShowDetails();
			dataPartGUID = theGPT.GetGUID();
			uint64_t availableBlocks = GetAvailableSpace("/private/var");
			int fd = open("/dev/rdisk0s1", O_RDWR | O_SHLOCK);
			uint32_t blocksize = 0;
			if ( ioctl(fd, DKIOCGETBLOCKSIZE, &blocksize) != 0 ) {
				printf("[-] ioctl DKIOCGETBLOCKSIZE failed.\n");
				close(fd);
				exit(-1);
			};

			//check for local rootfs (which CoolBooter will place there), use its' size if it exists.
			int rootfsSize;
			if (stat("/var/cbooter/working_dir/rootfs.raw", &st) == 0) {
				printf("RootFS exists on FS, using that size.\n");
				rootfsSize = roundUp((st.st_size / blocksize), 8);
			}
			else {
				printf("Setting new system partition size to 1.5GB.\n");
				rootfsSize = (1500000000 / blocksize);
			}

			uint64_t splitPart; 

			splitPart = availableBlocks / 4;

			if (splitPart < (availableBlocks - (((rootfsSize * blocksize) + 4672800000ULL) / blocksize)) || (varSize * blocksize) <= 8072800000ULL || (availableBlocks * blocksize) <= 8072800000ULL) {
				splitPart = (varSize - ((rootfsSize * blocksize + 2472800000ULL) / blocksize));
				if ((varSize * blocksize) <= 8072800000ULL) {
					splitPart = (varSize - ((rootfsSize * blocksize + 1972800000ULL) / blocksize));
				}
				else if ((availableBlocks * blocksize) <= 6072800000ULL) {
					splitPart = (varSize - ((rootfsSize * blocksize + 2472800000ULL) / blocksize));
				}
			}
			else {
				splitPart = (4672800000ULL / blocksize);
			}

			if (!splitPart)
				exit(-1);

			close(fd);

			//hfs_resize (big thanks to danzatt)
			uint64_t sizeInBlocks = splitPart;
			uint64_t sizeInBytes = sizeInBlocks * blocksize;
			printf("Resizing data volume to %llu blocks.\n", sizeInBlocks);
			int err;
			if (( err = fsctl("/private/var/", RESIZE_PARTITION, &sizeInBytes, 0)) != 0) {
				printf("[-] HFS resize failed. errno=%i\n", err);
				exit(-1);
			};

			for (int i=0;i<15;i++) {
				sync();
			}

	//begin GPT stuff
			theGPT.DeletePartition(1);
			usleep(100);
			int recreate = theGPT.CreatePartition(1, splitPart);
			if (recreate != 1) {
				anErrorOccured();
			}
			usleep(100);
			int setNameOfVar = theGPT.SetName(1);
			if (setNameOfVar != 1) {
				anErrorOccured();
			}

	//set effaceable attributes on current user partition.
			theGPT.SetAttributes(1);

	//re-set original UUID on current user partition.
			theGPT.ChangeUniqueGuid(dataPartGUID, 1);

	//resize partition table to 4 
			theGPT.ResizePartitionTable();

	//create new rootfs
			usleep(100);
			int createNewRootfs = theGPT.CreatePartition(2, rootfsSize);

			if (createNewRootfs != 1) {
				anErrorOccured();
			}

	//create new var
	//int newVarSize = subtractPart - rootfsSize;
			int createNewVarPart = theGPT.CreatePartition(3, NULL);
			if (createNewVarPart != 1) {
				anErrorOccured();
			}

			//re-set original UUID on current user partition.
			theGPT.ChangeUniqueGuid(dataPartGUID, 2);

	//done, write the changes
			printf("Got everything ready, now to write the new GPT header.\n");
			theGPT.SaveGPTData();
			sync();	
			if(stat("/dev/disk0s1s4", &st) == 0){
				printf("All done. Pray.\n");
				for (int i=0; i<20; i++) {
					sync();
				}
				return 0;
			}
			else {
				printf("Something's wrong.\n");
				anErrorOccured();
				return -1;
			}

		} 
		break;

		case 2:
		
		/* -u for uninstall */
		if (argv[1] == std::string("-u")) {

	//check some things before actually starting.
			if (stat("/dev/disk0s1s4", &st)) {
				printf("You don't seem to have a device prepared by CoolBooter. Exiting...\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s5", &st)) {
				printf("You seem to have an extra partition for some reason. If this is knowlingly not your fault, sometimes the LwVM driver does this. A reboot should fix it. Exiting...\n");
				exit(0);
			}

			if (stat("/dev/disk0s1s4", &st) && stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s5", &st)) {
				printf("You don't seem to have a partitioned device. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s4", &st)) {
				printf("You have an unexpected partition layout. If you have never messed with them before, please contact me (CoolBooter) so I can add support for your layout. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s5", &st)) {
				printf("You seem to have an extra partition for some reason. If this is knowlingly not your fault, sometimes the LwVM driver does this. A reboot should fix it. Exiting.\n");
				exit(0);
			}

	//begin GPT stuff
			if (theGPT.LoadPartitions("/dev/rdisk0s1")) {
				string dataPartGUID = theGPT.GetGUID();
				int revertVar = theGPT.RevertPartitions();
				printf("Reverting user partition.\n");
				if (revertVar != 1) {
					anErrorOccured();
				}

	//revert partition table to 2
				theGPT.RevertPartitionTable();

	//remake var
				theGPT.DeletePartition(1);
				usleep(100);
				int recreate = theGPT.RestorePartition();
				if (recreate != 1) {
					anErrorOccured();
				}
				usleep(100);
				int setNameOfVar = theGPT.SetName(1);
				if (setNameOfVar != 1) {
					anErrorOccured();
				}

	//re-set effaceable attributes
				theGPT.SetAttributes(1);

	//re-set original GUID
				theGPT.ChangeUniqueGuid(dataPartGUID, 1);	

	//save GPT changes
				printf("About to write changes to GPT header (cross fingers)\n");
				theGPT.SaveGPTData();
				usleep(450);
				for (int i=0;i<15;i++) {
					sync();
				}

				uint64_t varSize = theGPT.ShowDetails();

				int fd = open("/dev/rdisk0s1", O_RDWR | O_SHLOCK);

	//get block size
				uint64_t blocksize = 0;
				if ( ioctl(fd, DKIOCGETBLOCKSIZE, &blocksize) != 0 ) {
					printf("[-] ioctl DKIOCGETBLOCKSIZE failed. Are you root?\n");
					close(fd);
					exit(-1);
				};

	//hfs_resize (thanks again to danzatt)
				uint64_t subtractPart = varSize - 20;
				uint64_t sizeInBlocks = subtractPart;
				uint64_t sizeInBytes = sizeInBlocks * blocksize;
				printf("Resizing data volume to %llu blocks.\n", sizeInBlocks);
				int err;
				if ( ( err = fsctl("/private/var/", RESIZE_PARTITION, &sizeInBytes, 0)) != 0) {
					printf("[-] HFS resize failed. errno=%i\n", err);
					exit(-1);
				};
				usleep(100);
				for (int i=0; i<15; i++) {
					sync();
				}
				printf("All done. A reboot is recommended now.\n");
			}

		} // if

		/* -m for maximize */
		if (argv[1] == std::string("-m")) {

	//check some things before actually starting.
			if (!stat("/dev/disk0s1s4", &st)) {
				printf("You need to delete your extra partitions. Re-run with -u. Exiting...\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s5", &st)) {
				printf("You seem to have an extra partition for some reason. If this is knowlingly not your fault, sometimes the LwVM driver does this. A reboot should fix it. Exiting...\n");
				exit(0);
			}

			if (!stat("/dev/disk0s1s4", &st) && !stat("/dev/disk0s1s3", &st) && !stat("/dev/disk0s1s5", &st)) {
				printf("You need to delete your extra partitions. Re-run with -u. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s4", &st)) {
				printf("You have an unexpected partition layout. If you have never messed with them before, please contact me (CoolBooter) so I can add support for your layout. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s5", &st)) {
				printf("You seem to have an extra partition for some reason. If this is knowlingly not your fault, sometimes the LwVM driver does this. A reboot should fix it. Exiting.\n");
				exit(0);
			}

	//begin GPT stuff
			if (theGPT.LoadPartitions("/dev/rdisk0s1")) {

				string dataPartGUID = theGPT.GetGUID();

				uint64_t varSize = theGPT.ShowDetails();

				int fd = open("/dev/rdisk0s1", O_RDWR | O_SHLOCK);

	//get block size
				uint64_t blocksize = 0;
				if ( ioctl(fd, DKIOCGETBLOCKSIZE, &blocksize) != 0 ) {
					printf("[-] ioctl DKIOCGETBLOCKSIZE failed. Are you root?\n");
					close(fd);
					exit(-1);
				};

	//hfs_resize (thanks again to danzatt)
				uint64_t subtractPart = varSize - 20;
				uint64_t sizeInBlocks = subtractPart;
				uint64_t sizeInBytes = sizeInBlocks * blocksize;
				printf("Resizing data volume to %llu blocks.\n", sizeInBlocks);
				int err;
				if ( ( err = fsctl("/private/var/", RESIZE_PARTITION, &sizeInBytes, 0)) != 0) {
					printf("[-] HFS resize failed. errno=%i\n", err);
					exit(-1);
				};
				usleep(100);
				for (int i=0; i<15; i++) {
					sync();
				}
				printf("All done. A reboot is recommended now.\n");
			}
		} // if
		break;

		case 3:
		
		/* -rs for RootFSSize */
		if (argv[1] == std::string("-rs")) {
			

		//check some things before actually starting.
			if (!stat("/dev/disk0s1s4", &st) && !stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s5", &st)) {
				printf("You already have a partitioned device. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s4", &st)) {
				printf("You have an unexpected partition layout. If you have never messed with them before, please contact me (CoolBooter) so I can add support for your layout. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s5", &st)) {
				printf("You seem to have an extra partition for some reason. If this is knowlingly not your fault, sometimes the LwVM driver does this. A reboot should fix it. Exiting.\n");
				exit(0);
			}


			//begin GPT stuff
			if (theGPT.LoadPartitions("/dev/rdisk0s1")) {
				string dataPartGUID = theGPT.GetGUID();
			}

			uint64_t varSize = theGPT.ShowDetails();
			dataPartGUID = theGPT.GetGUID();
			uint64_t availableBlocks = GetAvailableSpace("/private/var");
			int fd = open("/dev/rdisk0s1", O_RDWR | O_SHLOCK);
			uint32_t blocksize = 0;
			if ( ioctl(fd, DKIOCGETBLOCKSIZE, &blocksize) != 0 ) {
				printf("[-] ioctl DKIOCGETBLOCKSIZE failed.\n");
				close(fd);
				exit(-1);
			};

			long long rootfsSize = roundUpLongLong((strtoull(argv[2], 0, 0) / blocksize), 8);

			/* Specified RootFS size must be between 1GB and 6GB */
			if ((rootfsSize * blocksize) < 1000000000LL || (rootfsSize * blocksize) > 6000000000LL) {
				printf("RootFS size must be between 1GB and 6GB\n");
				usleep(500);
				exit(-1);
			}

			uint64_t splitPart = availableBlocks / 4;

			/* If the user has an 8GB, they get about 2GB. If not, but they're low on space,*/
			/* they get about 2.5GB. Otherwise, about 4.5GB */
			/* (This is a bit of a mess) */
			if (splitPart < (availableBlocks - (((rootfsSize * blocksize) + 4672800000ULL) / blocksize)) || (varSize * blocksize) <= 8072800000ULL || (availableBlocks * blocksize) <= 8072800000ULL) {
				splitPart = (varSize - ((rootfsSize * blocksize + 2472800000ULL) / blocksize));
				if ((varSize * blocksize) <= 8072800000ULL) {
					splitPart = (varSize - ((rootfsSize * blocksize + 1972800000ULL) / blocksize));
				}
				else if ((availableBlocks * blocksize) <= 6072800000ULL) {
					splitPart = (varSize - ((rootfsSize * blocksize + 2472800000ULL) / blocksize));
				}
			}
			else {
				splitPart = (4672800000ULL / blocksize);
			}

			if (!splitPart)
				exit(-1);

			close(fd);

			//hfs_resize (big thanks to danzatt)
			uint64_t sizeInBlocks = splitPart;
			uint64_t sizeInBytes = sizeInBlocks * blocksize;
			printf("Resizing data volume to %llu blocks.\n", sizeInBlocks);
			int err;
			if (( err = fsctl("/private/var/", RESIZE_PARTITION, &sizeInBytes, 0)) != 0) {
				printf("[-] HFS resize failed. errno=%i\n", err);
				exit(-1);
			};

			/* Probably un-needed syncs, whatever */
			for (int i=0;i<15;i++) {
				sync();
			}

		//begin GPT stuff
			theGPT.DeletePartition(1);
			usleep(100);
			int recreate = theGPT.CreatePartition(1, splitPart);
			if (recreate != 1) {
				anErrorOccured();
			}
			usleep(100);
			int setNameOfVar = theGPT.SetName(1);
			if (setNameOfVar != 1) {
				anErrorOccured();
			}

		//set effaceable attributes on current user partition.
			theGPT.SetAttributes(1);

		//re-set original UUID on current user partition.
			theGPT.ChangeUniqueGuid(dataPartGUID, 1);

		//resize partition table to 4 
			theGPT.ResizePartitionTable();

		//create new rootfs
			usleep(100);
			int createNewRootfs = theGPT.CreatePartition(2, rootfsSize);

			if (createNewRootfs != 1) {
				anErrorOccured();
			}

		//create new var
		//int newVarSize = subtractPart - rootfsSize;
			int createNewVarPart = theGPT.CreatePartition(3, NULL);
			if (createNewVarPart != 1) {
				anErrorOccured();
			}

			//re-set original UUID on current user partition.
			theGPT.ChangeUniqueGuid(dataPartGUID, 2);

		//done, write the changes
			printf("Got everything ready, now to write the new GPT header.\n");
			theGPT.SaveGPTData();
			sync();	
			if(stat("/dev/disk0s1s4", &st) == 0){
				printf("All done. Pray.\n");
				for (int i=0; i<20; i++) {
					sync();
				}
				return 0;
			}
			else {
				printf("Something's wrong.\n");
				anErrorOccured();
				return -1;
			}
		}

		/* -ds for DataSize */
		if (argv[1] == std::string("-ds") && argv[2]) {

			//check some things before actually starting.
			if (!stat("/dev/disk0s1s4", &st) && !stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s5", &st)) {
				printf("You already have a partitioned device. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s4", &st)) {
				printf("You have an unexpected partition layout. If you have never messed with them before, please contact me (CoolBooter) so I can add support for your layout. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s5", &st)) {
				printf("You seem to have an extra partition for some reason. If this is knowlingly not your fault, sometimes the LwVM driver does this. A reboot should fix it. Exiting.\n");
				exit(0);
			}

			//begin GPT stuff
			if (theGPT.LoadPartitions("/dev/rdisk0s1")) {
				string dataPartGUID = theGPT.GetGUID();
			}

			/* varSize = the full size of the current data partition */
			uint64_t varSize = theGPT.ShowDetails();
			
			dataPartGUID = theGPT.GetGUID();
			
			uint64_t availableBlocks = GetAvailableSpace("/private/var");

			int fd = open("/dev/rdisk0s1", O_RDWR | O_SHLOCK);
			uint32_t blocksize = 0;
			if ( ioctl(fd, DKIOCGETBLOCKSIZE, &blocksize) != 0 ) {
				printf("[-] ioctl DKIOCGETBLOCKSIZE failed.\n");
				close(fd);
				exit(-1);
			};

			//check for local rootfs (which CoolBooter will place there), use its' size if it exists.
			uint64_t rootfsSize;
			if (stat("/var/cbooter/working_dir/rootfs.raw", &st) == 0) {
				printf("RootFS exists on FS, using that size.\n");
				rootfsSize = roundUp((st.st_size / blocksize), 8);
			}
			else {
				printf("Setting new system partition size to 1.5GB.\n");
				rootfsSize = (1500000000 / blocksize);
			}
			
			uint64_t dataBlocks = roundUpLongLong((strtoull(argv[2], 0, 0) / blocksize), 8);
			uint64_t dataSize = (dataBlocks * blocksize);
			uint64_t availableBytesOnVar = ((availableBlocks * blocksize) - rootfsSize);
			
			if (!(availableBytesOnVar && dataSize && dataBlocks))
				exit(-1);
		
			/* Specified RootFS size must be between 1GB and 6GB */
			if ((rootfsSize * blocksize) < 1000000000LL || (rootfsSize * blocksize) > 6000000000LL) {
				exit(-1);
			}
			
			/* Specified data partition size must be smaller than (available space - RootFS size) */ 
			if (dataSize > (availableBytesOnVar - rootfsSize)) {
				exit(-1);
			}
			
			/* Must have some available bytes left over after subtracting requested RootFS/DataSize */
			if ((availableBytesOnVar - dataSize - rootfsSize) > availableBytesOnVar) {
				exit(-1);
			}

			/* Must have >=1GB left over after subtracting requested RootFS/DataSize */
			if (((availableBytesOnVar - rootfsSize) - dataSize) < 1000000000LL) {
				exit(-1);
			}

			/* splitPart is the size of the current data partition - requested partition sizes */
			uint64_t splitPart = (varSize - rootfsSize) - (dataSize / blocksize); 

			if (!splitPart)
				exit(-1);
				
			/* Can't go lower than the space we have used */
			if (splitPart < (varSize - availableBlocks)) {
				printf("Not enough space available for requested partition layout.\n");
				exit(-1);
			}

			close(fd);

			//hfs_resize (big thanks to danzatt)
			uint64_t sizeInBlocks = splitPart;
			uint64_t sizeInBytes = sizeInBlocks * blocksize;
			printf("Resizing data volume to %llu blocks.\n", sizeInBlocks);
			int err;
			if (( err = fsctl("/private/var/", RESIZE_PARTITION, &sizeInBytes, 0)) != 0) {
				printf("[-] HFS resize failed. errno=%i\n", err);
				exit(-1);
			};
			
			/* Probably un-needed syncs, whatever */
			for (int i=0;i<15;i++) {
				sync();
			}

			//begin GPT stuff
			theGPT.DeletePartition(1);
			usleep(100);
			int recreate = theGPT.CreatePartition(1, splitPart);
			if (recreate != 1) {
				anErrorOccured();
			}
			usleep(100);
			int setNameOfVar = theGPT.SetName(1);
			if (setNameOfVar != 1) {
				anErrorOccured();
			}

			//set effaceable attributes on current user partition.
			theGPT.SetAttributes(1);

			//re-set original UUID on current user partition.
			theGPT.ChangeUniqueGuid(dataPartGUID, 1);

			//resize partition table to 4 
			theGPT.ResizePartitionTable();

			//create new rootfs
			usleep(100);
			int createNewRootfs = theGPT.CreatePartition(2, rootfsSize);

			if (createNewRootfs != 1) {
				anErrorOccured();
			}

			//create new var
			//int newVarSize = subtractPart - rootfsSize;
			int createNewVarPart = theGPT.CreatePartition(3, NULL);
			if (createNewVarPart != 1) {
				anErrorOccured();
			}

				//re-set original UUID on current user partition.
			theGPT.ChangeUniqueGuid(dataPartGUID, 2);

			//done, write the changes
			printf("Got everything ready, now to write the new GPT header.\n");
			theGPT.SaveGPTData();
			sync();	
			if(stat("/dev/disk0s1s4", &st) == 0){
				printf("All done. Pray.\n");
				for (int i=0; i<20; i++) {
					sync();
				}
				return 0;
			}
			else {
				printf("Something's wrong.\n");
				anErrorOccured();
				return -1;
			}
		}
		break;
		
		case 5:
		
		/* -rs for RootFSSize, -ds for DataSize */
		if (argv[1] == std::string("-rs") && argv[2] && argv[3] == std::string("-ds") && argv[4]) {

			//check some things before actually starting.
			if (!stat("/dev/disk0s1s4", &st) && !stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s5", &st)) {
				printf("You already have a partitioned device. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s3", &st) && stat("/dev/disk0s1s4", &st)) {
				printf("You have an unexpected partition layout. If you have never messed with them before, please contact me (CoolBooter) so I can add support for your layout. Exiting.\n");
				exit(0);
			}
			else if (!stat("/dev/disk0s1s5", &st)) {
				printf("You seem to have an extra partition for some reason. If this is knowlingly not your fault, sometimes the LwVM driver does this. A reboot should fix it. Exiting.\n");
				exit(0);
			}

			if (theGPT.LoadPartitions("/dev/rdisk0s1")) {
				string dataPartGUID = theGPT.GetGUID();
			}

			/* varSize = the full size of the current data partition */
			uint64_t varSize = theGPT.ShowDetails();
			
			dataPartGUID = theGPT.GetGUID();
			
			uint64_t availableBlocks = GetAvailableSpace("/private/var");

			int fd = open("/dev/rdisk0s1", O_RDWR | O_SHLOCK);
			uint32_t blocksize = 0;
			if ( ioctl(fd, DKIOCGETBLOCKSIZE, &blocksize) != 0 ) {
				printf("[-] ioctl DKIOCGETBLOCKSIZE failed.\n");
				close(fd);
				exit(-1);
			};
			
			uint64_t rootfsSize = roundUpLongLong((strtoull(argv[2], 0, 0) / blocksize), 8);
			uint64_t dataBlocks = roundUpLongLong((strtoull(argv[4], 0, 0) / blocksize), 8);
			uint64_t dataSize = (dataBlocks * blocksize);
			
			if (!(rootfsSize && dataBlocks && dataSize))
				exit(-1);
			
			uint64_t availableBytesOnVar = ((availableBlocks * blocksize) - rootfsSize);
		
			/* Specified RootFS size must be between 1GB and 6GB */
			if ((rootfsSize * blocksize) < 1000000000LL || (rootfsSize * blocksize) > 6000000000LL) {
				exit(-1);
			}
			
			/* Specified data partition size must be smaller than (available space - RootFS size) */ 
			if (dataSize > (availableBytesOnVar - rootfsSize)) {
				exit(-1);
			}
			
			/* Must have some available bytes left over after subtracting requested RootFS/DataSize */
			if ((availableBytesOnVar - dataSize - rootfsSize) > availableBytesOnVar) {
				exit(-1);
			}

			/* Must have >=1GB left over after subtracting requested RootFS/DataSize */
			if (((availableBytesOnVar - rootfsSize) - dataSize) < 1000000000LL) {
				exit(-1);
			}

			/* splitPart is the size of the current data partition - requested partition sizes */
			uint64_t splitPart = (varSize - rootfsSize) - (dataSize / blocksize); 

			if (!splitPart)
				exit(-1);
				
			/* Can't go lower than the space we have used */
			if (splitPart < (varSize - availableBlocks)) {
				printf("Not enough space available for requested partition layout.\n");
				exit(-1);
			}

			close(fd);

			//hfs_resize (big thanks to danzatt)
			uint64_t sizeInBlocks = splitPart;
			uint64_t sizeInBytes = sizeInBlocks * blocksize;
			printf("Resizing data volume to %llu blocks.\n", sizeInBlocks);
			int err;
			if (( err = fsctl("/private/var/", RESIZE_PARTITION, &sizeInBytes, 0)) != 0) {
				printf("[-] HFS resize failed. errno=%i\n", err);
				exit(-1);
			};

			/* Probably un-needed syncs, whatever */
			for (int i=0;i<15;i++) {
				sync();
			}

			//begin GPT stuff
			theGPT.DeletePartition(1);
			usleep(100);
			int recreate = theGPT.CreatePartition(1, splitPart);
			if (recreate != 1) {
				anErrorOccured();
			}
			usleep(100);
			int setNameOfVar = theGPT.SetName(1);
			if (setNameOfVar != 1) {
				anErrorOccured();
			}

			//set effaceable attributes on current user partition.
			theGPT.SetAttributes(1);

			//re-set original UUID on current user partition.
			theGPT.ChangeUniqueGuid(dataPartGUID, 1);

			//resize partition table to 4 
			theGPT.ResizePartitionTable();

			//create new rootfs
			usleep(100);
			int createNewRootfs = theGPT.CreatePartition(2, rootfsSize);

			if (createNewRootfs != 1) {
				anErrorOccured();
			}

			//create new var
			//int newVarSize = subtractPart - rootfsSize;
			int createNewVarPart = theGPT.CreatePartition(3, NULL);
			if (createNewVarPart != 1) {
				anErrorOccured();
			}

			//re-set original UUID on current user partition.
			theGPT.ChangeUniqueGuid(dataPartGUID, 2);

			//done, write the changes
			printf("Got everything ready, now to write the new GPT header.\n");
			theGPT.SaveGPTData();
			sync();	
			if(stat("/dev/disk0s1s4", &st) == 0){
				printf("All done. Pray.\n");
				for (int i=0; i<20; i++) {
					sync();
				}
				return 0;
			}
			else {
				printf("Something's wrong.\n");
				anErrorOccured();
				return -1;
			}
		}
		break;
		
	} //switch	
	
	return (isError);

} // main
