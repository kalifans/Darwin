
export SDKROOT=$(xcrun --sdk iphoneos6.1 --show-sdk-path)
export CC="$(xcrun -f clang) -arch armv7 -arch armv7s"
export CXX="$(xcrun -f clang++) -arch armv7 -arch armv7s"
export CFLAGS="-I$SDKROOT/usr/include/ -I. -O2 -D_FILE_OFFSET_BITS=64 -g"
export LDFLAGS="-L$SDKROOT/usr/lib/"

ALLCC="crc32.cc support.cc guid.cc gptpart.cc mbrpart.cc basicmbr.cc mbr.cc gpt.cc bsd.cc parttypes.cc attributes.cc diskio.cc diskio-unix.cc gdisk.cc gpttext.cc"

$CXX $CFLAGS $LDFLAGS $ALLCC -o gptdisk
