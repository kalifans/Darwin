//
//  cydia.m
//  Trident
//
//  Created by Kali on 2017/8/5.
//  Copyright © 2017年 Benjamin Randazzo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sys/mount.h>
#import <spawn.h>

#import <mach-o/dyld.h>
#import <sys/stat.h>
#import <copyfile.h>

void cydia_inst(void) {

    char* nmz = strdup("/dev/disk0s1s1");
    mount( "hfs", "/", MNT_UPDATE, (void*)&nmz);
    system("/sbin/mount -t hfs -o update /dev/disk0s1s1 /");

    char path[256];
    uint32_t size = sizeof(path);
    _NSGetExecutablePath(path, &size);
    char* pt = realpath(path, 0);
    
    __block pid_t pd = 0;
    NSString* execpath = [[NSString stringWithUTF8String:pt]  stringByDeletingLastPathComponent];
    
    int f = open("/.installed_cydia", O_RDONLY);
    
    if (f == -1) {
        // copy tar
        NSString* tar = [execpath stringByAppendingPathComponent:@"tar"];
        NSString* cydia = [execpath stringByAppendingPathComponent:@"cydia.tar"];

        const char* jtar = [tar UTF8String];
        unlink("/bin/tar");
        copyfile(jtar, "/bin/tar", 0, COPYFILE_ALL);
        chmod("/bin/tar", 0777);
        jtar="/bin/tar";

        chdir("/");

        // install cydia
        posix_spawn(&pd, jtar, 0, 0, (char**)&(const char*[]){jtar, "--preserve-permissions", "--no-overwrite-dir", "-xvf", [cydia UTF8String], NULL}, NULL);
        waitpid(pd, 0, 0);
        open("/.installed_cydia", O_RDWR|O_CREAT);

        // copy launchctl
        NSString* jlaunchctl = [execpath stringByAppendingPathComponent:@"launchctl"];
        const char* jlctl = [jlaunchctl UTF8String];
        copyfile(jlctl, "/bin/launchctl", 0, COPYFILE_ALL);
        chmod("/bin/launchctl", 0755);

        // copy reload
        NSString* reload = [execpath stringByAppendingPathComponent:@"reload"];
        const char* jreload = [reload UTF8String];
        unlink("/usr/libexec/reload");
        copyfile(jreload, "/usr/libexec/reload", 0, COPYFILE_ALL);
        chmod("/usr/libexec/reload", 0755);
        chown("/usr/libexec/reload", 0, 0);
        
        // copy reload.plist
        NSString* rplist = [execpath stringByAppendingPathComponent:@"0.reload.plist"];
        const char* jrplist = [rplist UTF8String];
        unlink("/Library/LaunchDaemons/0.reload.plist");
        copyfile(jrplist, "/Library/LaunchDaemons/0.reload.plist", 0, COPYFILE_ALL);
        chmod("/Library/LaunchDaemons/0.reload.plist", 0644);
        chown("/Library/LaunchDaemons/0.reload.plist", 0, 0);
        
        //remove nosuid
        system("/bin/sed -i 's/,nosuid,nodev//g' /private/etc/fstab");

        //changing permissions
        //chmod("/private", 0777);
        //chmod("/private/var", 0777);
        //chmod("/private/var/mobile", 0777);
        //chmod("/private/var/mobile/Library", 0777);
        //chmod("/private/var/mobile/Library/Preferences", 0777);
        
        // remove ota update
        //unlink("/System/Library/LaunchDaemons/com.apple.mobile.softwareupdated.plist");

    }

    //start openssh service
    int ssh = open("/Library/LaunchDaemons/com.openssh.sshd.plist", O_RDONLY);
    if (ssh) {
        system("/bin/launchctl load /Library/LaunchDaemons/com.openssh.sshd.plist");
    }

    // restart springboard
    system("/usr/bin/killall -SIGSTOP cfprefsd");
    //posix_spawn(&pd, "/usr/bin/killall", 0, 0, (char**)&(const char*[]){"/usr/bin/killall", "-SIGSTOP", "cfprefsd", NULL}, NULL);
    //waitpid(pd, 0, 0);

    NSMutableDictionary* md = [[NSMutableDictionary alloc] initWithContentsOfFile:@"/var/mobile/Library/Preferences/com.apple.springboard.plist"];
    [md setObject:[NSNumber numberWithBool:YES] forKey:@"SBShowNonDefaultSystemApps"];
    [md writeToFile:@"/var/mobile/Library/Preferences/com.apple.springboard.plist" atomically:YES];

    system("/usr/bin/killall -9 cfprefsd");
    //posix_spawn(&pd, "/usr/bin/killall", 0, 0, (char**)&(const char*[]){"/usr/bin/killall", "-9", "cfprefsd", NULL}, NULL);
    //waitpid(pd, 0, 0);

    // no move /Applications to stash dir
    system("/bin/touch /.cydia_no_stash");
    //posix_spawn(&pd, "/bin/touch", 0, 0, (char**)&(const char*[]){"/bin/touch", "/.cydia_no_stash", NULL}, NULL);
    //waitpid(pd, 0, 0);

    system("su mobile -c uicache");
    system("killall backboardd");

}
