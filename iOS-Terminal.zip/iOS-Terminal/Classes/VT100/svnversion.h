#define SVN_VERSION ((int)strtol("Unversioned directory", NULL, 10))
