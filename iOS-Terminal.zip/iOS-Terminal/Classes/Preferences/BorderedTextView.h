// BorderedTextView.h
// MobileTerminal

#import <UIKit/UIKit.h>


// A UITextView with a border that makes it look similar to a UITextField.
@interface BorderedTextView : UITextView {

}

@end
