#ifndef TASK_FOR_IOS9_PID_H
#define TASK_FOR_IOS9_PID_H

kern_return_t task_for_ios9_pid(mach_port_name_t target_tport,int pid,mach_port_name_t *kernel_task);

#endif