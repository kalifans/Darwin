//
//  ViewController.m
//  Sideloader
//
//  Created by Kali on 2017/1/15.
//  Copyright (c) 2017年 mintfans. All rights reserved.
//

#import "ViewController.h"

void ayy_lmao();

@interface ViewController ()

- (IBAction)Button:(UIButton *)sender;
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)Button:(UIButton *)sender {
    ayy_lmao();
}
@end
