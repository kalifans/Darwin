if (scale == 0) factor = 1;
else if (scale == 1) factor = 2;
else if (scale == 2) factor = 4;
else if (scale == 3) factor = 8;

// MOD 0
if (mod == 0) {
	//SIB START
	if (num_src == 4){ //SIB
		if (scale == 0) { //scale 0
			if (index == 4) { //INDEX4
				if (base == 5) {
					[DISP32] MODRM + 5
				} else {
					[BASE] MODRM + 1
				}
			} else { //Not INDEX4
				if (base == 5) {
					[DISP32 + INDEX] MODRM + 5
				} else {
					[BASE + INDEX] MODRM + 1
				}	
			}
		} else { //scale 1 2 3
			if (index == 4) { //INDEX4
				if (base == 5) {
					[DISP32] MODRM + 5
				} else {
					[BASE] MODRM + 1
				}
			} else { //Not INDEX4
				if (base == 5) {
					[DISP32 + (INDEX * FACTOR)] MODRM + 5
				} else {
					[BASE + (INDEX * FACTOR)] MODRM + 1
				}
			}
		}
	}
	//SIB END

	else {
		if (num_src == 5) {
			[DISP32] MODRM + 4
		} else {
			[SRC]
		}
	}
}

// MOD 1
if (mod == 1) {
	//SIB START
	if (num_src == 4) { //SIB
		if (scale == 0) { //scale 0
			if (index == 4) { //INDEX4
				[BASE + DISP8] MODRM + 2
			} else { //Not INDEX4
				[BASE + INDEX + DISP8] MODRM + 2
			}
		} else { //scale 1 2 3
			if (index == 4) { //INDEX4
				[BASE + DISP8] MODRM + 2
			} else { //Not INDEX4
				[BASE + (INDEX * FACTOR) + DISP8] MODRM + 2
			}
		}
	}
	//SIB END

	else {
		[SRC + DISP8] MODRM + 1
	}
}

// MOD 2
if (mod == 2) {
	//SIB START
	if (num_src == 4) { //SIB
		if (scale == 0) { //scale 0
			if (index == 4) { //INDEX4
				[BASE + DISP32] MODRM + 5
			} else { //Not INDEX4
				[BASE + INDEX + DISP32] MODRM + 5
			}
		} else { //scale 1 2 3
			if (index == 4) { //INDEX4
				[BASE + DISP32] MODRM + 5
			} else { //Not INDEX4
				[BASE + (INDEX * FACTOR) + DISP32] MODRM + 5
			}
		}
	}
	//SIB END

	else {
		[SRC + DISP32] MODRM + 4
	}
}
