 ModR/M byte:                     SIB ﻿byte:
  7 - 6    5 - 3    2 - 0          7 - 6    5 - 3    2 - 0
 -------- -------- --------       -------- -------- --------
| Mod    | Reg/   | R/M    |     | Scale  | Index  | Base   |
|        | Opcode |        |      -------- -------- --------
 -------- -------- --------

*******************************
*** ModRM
*******************************
* IF MOD 0
IF R/M = 4
    Enable SIB
IF R/M = 5
    R/M = [DISP32]
ELSE
    R/M = [REG]

* IF MOD 1
IF R/M = 4
    Enable SIB
ELSE
    R/M = [SRC + DISP8]

* IF MOD 2
IF R/M = 4
    Enable SIB
ELSE
    R/M = [SRC + DISP32]

*******************************
*** SIB
*******************************
IF Scale = 0 factor = 1
IF Scale = 1 factor = 2
IF Scale = 2 factor = 4
IF Scale = 3 factor = 8

* IF MOD 0
IF Scale = 0
   IF Index = 4
       IF Base = 5 or 13
           R/M = [DISP32]
       ELSE
           R/M = [BASE]
   ELSE
      IF Base = 5 or 13
          [DISP32 + INDEX]
      ELSE
          [BASE + INDEX]
ELSE //Scale = 1 2 3
   IF Index = 4
       IF Base = 5 or 13
           R/M = [DISP32]
       ELSE
           R/M = [BASE]
   ELSE
      IF Base = 5 or 13
          [DISP32 + (INDEX * FACTOR)]
      ELSE
          [BASE + (INDEX * FACTOR)]


* IF MOD 1
IF Scale = 0
    IF Index = 4
        [BASE + DISP8]
    ELSE
        [BASE + INDEX + DISP8]
ELSE //Scale = 1 2 3
    IF Index = 4
        [BASE + DISP8]
    ELSE
        [BASE + (INDEX * FACTOR) + DISP8]

* IF MOD 2
IF Scale = 0
    IF Index = 4
        [BASE + DISP32]
    ELSE
        [BASE + INDEX + DISP32]
ELSE //Scale = 1 2 3
    IF Index = 4
        [BASE + DISP32]
    ELSE
        [BASE + (INDEX * FACTOR) + DISP32]

