int _betterWorkingAndShit(int arg0, int arg1) {
    r7 = &arg_8;
    sp = sp - 0x188;
    arg_184 = arg0;
    arg_180 = arg1;
    _logToFile("Hacking the kernel\n", arg1, "Hacking the kernel\n", r3, r4);
    r0 = *objc_msgSend;
    arg_C8 = r0;
    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_C8);
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_178 = @"YLUProgressString";
    arg_17C = @"Dumping kernel";
    arg_C4 = r0;
    arg_C0 = 0x1;
    arg_BC = r2;
    var_0 = arg_C0;
    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_17C, &arg_178);
    r7 = r7;
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_B8 = r0;
    arg_B4 = @"YLUDidReceiveUpdateProgressNotification";
    arg_B0 = r2;
    var_0 = arg_B8;
    [arg_C4 postNotificationName:r2 object:r3 userInfo:STK-1];
    [arg_B8 release];
    [arg_C4 release];
    arg_174 = 0x0;
    r0 = _kernelSize(arg_180, &arg_174);
    arg_170 = r0;
    arg_AC = arg_170;
    _logToFile("Kernel size: 0x%08x\n", arg_AC, arg_B4, 0x0, STK-1);
    arg_16C = malloc(arg_170);
    arg_168 = 0x1000;
    arg_164 = 0x0;
    while (arg_164 << 0xc < arg_170) {
            arg_A8 = &arg_168;
            r1 = arg_180 + (arg_164 << 0xc);
            r3 = arg_16C + (arg_164 << 0xc);
            var_0 = arg_A8;
            arg_160 = vm_read_overwrite(arg_184, r1, 0x1000, r3, STK-1);
            if (arg_160 != 0x0) {
                    _logToFile("kr!=0\n", r1, 0x1000, r3, STK-1);
            }
            arg_164 = arg_164 + 0x1;
    }
    r0 = *objc_msgSend;
    arg_A4 = r0;
    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_A4);
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_158 = @"YLUProgressString";
    arg_15C = @"Patching lwvm";
    arg_A0 = r0;
    arg_9C = 0x1;
    arg_98 = r2;
    var_0 = arg_9C;
    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_15C, &arg_158);
    r7 = r7;
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_94 = r0;
    arg_90 = @"YLUDidReceiveUpdateProgressNotification";
    arg_8C = r2;
    var_0 = arg_94;
    [arg_A0 postNotificationName:arg_90 object:0x0 userInfo:STK-1];
    [arg_94 release];
    [arg_A0 release];
    arg_88 = &arg_154;
    var_0 = arg_88;

    _find_lwvm_patch_offsets(arg_180, arg_16C, arg_170, &arg_150);
    _logToFile("Will write 0x%08x,0x%08x\n", arg_150, arg_154, &arg_150, STK-1);
    if (arg_150 <= 0x4) {
            r2 = "\xC0F\xC0F";
            r3 = arg_150;
            arg_14C = vm_write(arg_184, arg_154 - arg_150, r2, r3);
            if (arg_14C != 0x0) {
                    _logToFile("Shit, vm write returned nonzero value: %d\n", arg_14C, r2, r3, STK-1);
            }
    }
    else {
            _write_primitive(arg_150, arg_154 + 0x1);
    }
    r0 = *objc_msgSend;
    arg_84 = r0;
    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_84);
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_144 = @"YLUProgressString";
    arg_148 = @"Patching filesystem";
    arg_80 = r0;
    arg_7C = 0x1;
    arg_78 = r2;
    var_0 = arg_7C;
    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_148, &arg_144);
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_74 = r0;
    arg_70 = @"YLUDidReceiveUpdateProgressNotification";
    arg_6C = r2;
    var_0 = arg_74;
    [arg_80 postNotificationName:arg_70 object:0x0 userInfo:STK-1];
    [arg_74 release];
    [arg_80 release];

    _find_remount_patch_offset(arg_180, arg_16C, arg_170, &arg_140);
    _logToFile("Found remount off: 0x%08x\n", arg_140, arg_170, &arg_140, STK-1);
    r0 = _read_primitive(arg_140);
    arg_13C = r0;
    arg_68 = arg_13C;
    _logToFile("Original value 0x%08x\n", arg_68, arg_170, &arg_140, STK-1);
    arg_13C = arg_13C & 0xffff00ff;
    arg_13C = arg_13C | 0xe000;
    _write_primitive(arg_140, arg_13C);
    r0 = _read_primitive(arg_140 + 0x14);
    arg_13C = r0;
    arg_64 = arg_13C;
    _logToFile("Original value 0x%08x\n", arg_64, arg_170, &arg_140, STK-1);
    arg_13C = arg_13C & 0xffff00ff;
    arg_13C = arg_13C | 0xe000;
    _write_primitive(arg_140 + 0x14, arg_13C);
    r0 = strdup("/dev/disk0s1s1");
    arg_138 = r0;
    r0 = mount("hfs", "/", 0x10000, &arg_138);
    arg_134 = r0;
    arg_60 = arg_134;
    _logToFile("Mount succeeded? %d\n", arg_60, 0x10000, &arg_138, STK-1);
    r0 = *objc_msgSend;
    arg_5C = r0;
    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_5C);
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_12C = @"YLUProgressString";
    arg_130 = @"Patching amfi";
    arg_58 = r0;
    arg_54 = 0x1;
    arg_50 = r2;
    var_0 = arg_54;
    r0 = loc_643a4(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_130, &arg_12C);
    r7 = r7;
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_4C = r0;
    arg_48 = @"YLUDidReceiveUpdateProgressNotification";
    arg_44 = r2;
    var_0 = arg_4C;
    [arg_58 postNotificationName:arg_48 object:0x0 userInfo:STK-1];
    [arg_4C release];
    [arg_58 release];
    arg_40 = &arg_124;
    var_0 = arg_40;

    _find_amfi_patch_offsets(arg_180, arg_16C, arg_170, &arg_128);
    _logToFile("What we hacked: 0x%08x 0x%08x\n", arg_128, arg_124, &arg_128, STK-1);
    _write_primitive(arg_128, arg_124 + 0x1);
    _find_i_can_has_debugger_patch_off(arg_180, arg_16C, arg_170, &arg_120);
    _logToFile("I can has debugger dst: 0x%08x\n", arg_120, arg_170, &arg_120, STK-1);
    _write_primitive(arg_120, 0x1);
    r2 = "Marijuan";
    r1 = 0x51 + arg_120 + 0x4;
    arg_11C = vm_write(arg_184, r1, r2, 0x8);
    if (arg_11C != 0x0) {
            _logToFile("failed write kernel\n", r1, r2, 0x8, STK-1);
    }

    _find_amfi_substrate_patch(arg_180, arg_16C, arg_170, &arg_118);
    arg_3C = &arg_110;
    var_0 = arg_3C;
    _find_real_vm_map_enter_patch(arg_180, arg_16C, arg_170, &arg_114);
    _find_real_vm_map_protect_patch(arg_180, arg_16C, arg_170, &arg_10C);
    var_0 = arg_10C;
    _logToFile("Found a bunch of shit, amfi substrate: 0x%08x, vm map enter 0x%08x 0x%08x, vm_map_protect 0x%08x\n", arg_118, arg_114, arg_110, STK-1);
    arg_11C = vm_write(arg_184, arg_118, 0x73f74, 0x2);
    if (arg_11C != 0x0) {
            _logToFile("Something went wrong vm writing amfi substrate HACK: %d\n", arg_11C, 0x73f74, 0x2, STK-1);
    }
    arg_11C = vm_write(arg_184, arg_114, 0x73f74, 0x2);
    if (arg_11C != 0x0) {
            _logToFile("Something went wrong vm writing vm map enter HACK: %d\n", arg_11C, 0x73f74, 0x2, STK-1);
    }
    _write_primitive(arg_110, 0xbf00bf00);
    _write_primitive(arg_10C, 0xbf00bf00);
    arg_38 = &arg_104;
    arg_34 = &arg_100;
    var_0 = arg_38;
    arg_4 = arg_34;

    _find_another_amfi_hack(arg_180, arg_16C, arg_170, &arg_108);
    _logToFile("0x%08x 0x%08x 0x%08x\n", arg_108, arg_104, arg_100, STK-1);
    arg_168 = 0x8;
    arg_30 = 0x8;
    arg_2C = &arg_168;
    var_0 = arg_2C;
    r0 = vm_read_overwrite(arg_184, arg_108, arg_30, &arg_F8, STK-1);
    arg_11C = r0;
    arg_28 = arg_174;
    _logToFile("where we will write MALWARE to: 0x%08x\n", arg_28, arg_30, &arg_F8, STK-1);
    arg_24 = *"\xDF\xF8\x02\xF0";
    _write_primitive(arg_108, arg_24);
    _write_primitive(arg_108 + 0x4, arg_174 + 0x1);
    r1 = arg_174;
    arg_11C = vm_write(arg_184, r1, 0x73f77, 0x10);
    if (arg_11C != 0x0) {
            _logToFile("Hacked FAILED\n", r1, 0x73f77, 0x10, STK-1);
    }
    r0 = vm_write(arg_184, arg_174 + 0x10, &arg_F8, 0x8);
    r1 = *objc_msgSend;
    arg_11C = r0;
    arg_20 = r1;
    r0 = loc_64396(NSNotificationCenter, @selector(defaultCenter), arg_20, objc_cls_ref_NSNotificationCenter);
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_F0 = @"YLUProgressString";
    arg_F4 = @"Patching tfp0";
    arg_1C = r0;
    arg_18 = 0x1;
    arg_14 = r2;
    var_0 = arg_18;
    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_F4, &arg_F0);
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_10 = r0;
    arg_C = @"YLUDidReceiveUpdateProgressNotification";
    arg_8 = r2;
    var_0 = arg_10;
    [arg_1C postNotificationName:arg_C object:0x0 userInfo:STK-1];
    [arg_10 release];
    [arg_1C release];

    _find_tfp_off(arg_180, arg_16C, arg_170, &arg_EC);
    arg_E8 = _read_primitive(arg_EC);
    arg_E8 = arg_E8 | 0xff;
    _write_primitive(arg_EC, arg_E8);
    _logToFile("patched pid_check\n", arg_E8, arg_170, &arg_EC, STK-1);
    arg_E4 = _find_cs_enforcement_disable_amfi(arg_180, arg_16C, arg_170);
    arg_E0 = "\x01";
    arg_DC = 0x1;
    arg_D8 = 0x6b901;
    while (arg_DC >> 0x2 != 0x0) {
            _write_primitive(arg_D8, *arg_E0);
            arg_E0 = arg_E0 + 0x4;
            arg_DC = arg_DC - 0x4;
            arg_D8 = arg_D8 + 0x4;
    }
    if ((arg_DC & 0x3) != 0x0) {
            arg_D4 = _read_primitive(arg_D8);
            arg_D0 = 0x0;
            while (arg_D0 < arg_DC) {
                    *(int8_t *)(&arg_D4 + arg_D0) = *(int8_t *)(arg_D0 + arg_E0);
                    arg_D0 = arg_D0 + 0x1;
            }
            _write_primitive(arg_D8, arg_D4);
    }
    arg_CC = 0x0;

   _find_sbops(arg_180, arg_16C, arg_170, &arg_CC);
    _logToFile("Found sbops 0x%08x\n", arg_CC, arg_170, &arg_CC, STK-1);
    _write_primitive(arg_CC + 0x90, 0x0);
    _write_primitive(arg_CC + 0x1e0, 0x0);
    _write_primitive(arg_CC + 0x1e0, 0x0);
    _write_primitive(arg_CC + 0x3f0, 0x0);
    _write_primitive(arg_CC + 0x3f8, 0x0);
    _write_primitive(arg_CC + 0x3fc, 0x0);
    _write_primitive(arg_CC + 0x400, 0x0);
    asm{ addw       r0, r0, #0x404 };
    _write_primitive(arg_CC, 0x0);
    _write_primitive(arg_CC + 0x408, 0x0);
    asm{ addw       r0, r0, #0x40c };
    _write_primitive(arg_CC, 0x0);
    _write_primitive(arg_CC + 0x410, 0x0);
    asm{ addw       r0, r0, #0x414 };
    _write_primitive(arg_CC, 0x0);
    _write_primitive(arg_CC + 0x420, 0x0);
    asm{ addw       r0, r0, #0x424 };
    _write_primitive(arg_CC, 0x0);
    asm{ addw       r0, r0, #0x42c };
    _write_primitive(arg_CC, 0x0);
    _write_primitive(arg_CC + 0x438, 0x0);
    asm{ addw       r0, r0, #0x44c };
    _write_primitive(arg_CC, 0x0);
    _write_primitive(arg_CC + 0x450, 0x0);
    asm{ addw       r0, r0, #0x454 };
    _write_primitive(arg_CC, 0x0);
    _write_primitive(arg_CC + 0x458, 0x0);
    asm{ addw       r0, r0, #0x45c };
    _write_primitive(arg_CC, 0x0);
    _write_primitive(arg_CC + 0x460, 0x0);
    _write_primitive(arg_CC + 0x460, 0x0);
    asm{ addw       r0, r0, #0x464 };
    _write_primitive(arg_CC, 0x0);
    _write_primitive(arg_CC + 0x468, 0x0);
    asm{ addw       r0, r0, #0x46c };
    _write_primitive(arg_CC, 0x0);
    asm{ addw       r0, r0, #0x4bc };
    _write_primitive(arg_CC, 0x0);
    _write_primitive(arg_CC + 0x4f0, 0x0);
    _write_primitive(arg_CC + 0x3d4, 0x0);
    r0 = _write_primitive(arg_CC + 0x168, 0x0);
    return r0;
}
