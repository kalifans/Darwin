int _startSSH(int arg0, int arg1) {
    STK35 = r7;
    r7 = &arg_C;
    sp = sp - 0x32c;
    r2 = *objc_msgSend;
    arg_328 = arg0;
    arg_324 = arg1;
    r0 = _objc_msgSend(NSNotificationCenter, @selector(defaultCenter), r2, 0x78f64, lr, STK35, r6, r5, r4);
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_31C = @"YLUProgressString";
    arg_320 = @"Installing SSH";
    arg_2D4 = r0;
    arg_2D0 = 0x1;
    arg_2CC = r2;
    var_0 = arg_2D0;
    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_320, &arg_31C);
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_2C8 = r0;
    arg_2C4 = @"YLUDidReceiveUpdateProgressNotification";
    arg_2C0 = r2;
    var_0 = arg_2C8;
    [arg_2D4 postNotificationName:arg_2C4 object:0x0 userInfo:STK-1];
    [arg_2C8 release];
    [arg_2D4 release];
    r0 = *objc_msgSend;
    arg_2BC = r0;
    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_2BC);
    r7 = r7;
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_2B8 = r0;
    arg_2B4 = @"/bin/tar";
    arg_2B0 = r2;
    COND = sign_extend_32([r0 fileExistsAtPath:arg_2B4]) == 0x0;
    r0 = 0x0;
    asm{ it         ne };
    if (!COND) {
            r0 = 0x1;
    }
    arg_2AC = r0 ^ 0xffffffff;
    [arg_2B8 release];
    if ((arg_2AC & 0x1) != 0x0) {
            r0 = *objc_msgSend;
            arg_2A8 = r0;
            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_2A8);
            r0 = [r0 retain];
            arg_2A4 = r0;
            arg_2A0 = @"tar";
            arg_29C = @"";
            r0 = _objc_msgSend(r0, @selector(URLForResource:withExtension:), arg_2A0, arg_29C);
            r0 = [r0 retain];
            r1 = *objc_msgSend;
            arg_298 = r0;
            arg_294 = r1;
            r0 = loc_63a52(r0, @selector(path), arg_294, r0);
            r0 = [r0 retain];
            arg_290 = r0;
            objc_retainAutorelease(r0);
            r1 = *objc_msgSend;
            arg_28C = r1;
            r0 = ("UTF8String")();
            r2 = *objc_msgSend;
            arg_288 = r0;
            arg_284 = @"/bin/tar";
            arg_280 = r2;
            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_284, arg_284);
            r0 = [r0 retain];
            r1 = *objc_msgSend;
            r3 = r0;
            arg_27C = r0;
            arg_278 = r1;
            r0 = loc_63a52(r3, @selector(path), arg_278, r3);
            r0 = [r0 retain];
            arg_274 = r0;
            objc_retainAutorelease(r0);
            r1 = *objc_msgSend;
            arg_270 = r1;
            r0 = ("UTF8String")();
            arg_26C = r0;
            _logToFile("We will try copying %s to %s\n", arg_288, arg_26C, r3, STK-1);
            [arg_274 release];
            [arg_27C release];
            [arg_290 release];
            [arg_298 release];
            [arg_2A4 release];
            r0 = *objc_msgSend;
            arg_268 = r0;
            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_268);
            r0 = [r0 retain];
            r3 = *objc_msgSend;
            arg_264 = r0;
            arg_260 = @"tar";
            arg_25C = @"";
            arg_258 = r3;
            r0 = [r0 URLForResource:arg_260 withExtension:arg_25C];
            r0 = [r0 retain];
            r1 = *objc_msgSend;
            arg_254 = r0;
            arg_250 = r1;
            r0 = loc_63a52(r0, @selector(path), arg_250, r0);
            r7 = r7;
            r0 = [r0 retain];
            arg_24C = r0;
            objc_retainAutorelease(r0);
            r1 = *objc_msgSend;
            arg_248 = r1;
            r0 = ("UTF8String")();
            arg_244 = copyfile(r0, "/bin/tar", 0x0, 0xf);
            [arg_24C release];
            [arg_254 release];
            [arg_264 release];
            arg_314 = arg_244;
            if (arg_314 != 0x0) {
                    arg_240 = arg_314;
                    arg_23C = *__error();
                    r0 = __error();
                    r0 = *r0;
                    r0 = strerror(r0);
                    arg_238 = r0;
                    r0 = _logToFile("copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_240, arg_23C, arg_238, STK-1);
            }
            else {
                    r0 = *objc_msgSend;
                    arg_234 = r0;
                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_234);
                    r7 = r7;
                    r0 = [r0 retain];
                    r2 = *objc_msgSend;
                    arg_230 = r0;
                    arg_22C = @"/bin/launchctl";
                    arg_228 = r2;
                    COND = sign_extend_32(("fileExistsAtPath:")(r0, @selector(fileExistsAtPath:), arg_22C, arg_22C)) == 0x0;
                    r0 = 0x0;
                    asm{  };
                    if (!COND) {
                            r0 = 0x1;
                    }
                    arg_224 = r0 ^ 0xffffffff;
                    [arg_230 release];
                    if ((arg_224 & 0x1) != 0x0) {
                            r0 = *objc_msgSend;
                            arg_220 = r0;
                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_220);
                            r0 = [r0 retain];
                            arg_21C = r0;
                            arg_218 = @"launchctl";
                            arg_214 = @"";
                            r0 = _objc_msgSend(r0, @selector(URLForResource:withExtension:), arg_218, arg_214);
                            r0 = [r0 retain];
                            r1 = *objc_msgSend;
                            r3 = r0;
                            arg_210 = r0;
                            arg_20C = r1;
                            r0 = loc_63a52(r3, @selector(path), arg_20C, r3);
                            r0 = [r0 retain];
                            arg_208 = r0;
                            objc_retainAutorelease(r0);
                            r1 = *objc_msgSend;
                            arg_204 = r1;
                            r0 = ("UTF8String")();
                            arg_200 = r0;
                            _logToFile("We will try copying %s to %s\n", arg_200, "/bin/launchctl", r3, STK-1);
                            [arg_208 release];
                            [arg_210 release];
                            [arg_21C release];
                            r0 = *objc_msgSend;
                            arg_1FC = r0;
                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_1FC);
                            r0 = [r0 retain];
                            r3 = *objc_msgSend;
                            arg_1F8 = r0;
                            arg_1F4 = @"launchctl";
                            arg_1F0 = @"";
                            arg_1EC = r3;
                            r0 = [r0 URLForResource:arg_1F4 withExtension:arg_1F0];
                            r0 = [r0 retain];
                            r1 = *objc_msgSend;
                            arg_1E8 = r0;
                            arg_1E4 = r1;
                            r0 = loc_63a52(r0, @selector(path), arg_1E4, r0);
                            r7 = r7;
                            r0 = [r0 retain];
                            arg_1E0 = r0;
                            objc_retainAutorelease(r0);
                            r1 = *objc_msgSend;
                            arg_1DC = r1;
                            r0 = ("UTF8String")();
                            arg_318 = copyfile(r0, "/bin/launchctl", 0x0, 0xf);
                            [arg_1E0 release];
                            [arg_1E8 release];
                            [arg_1F8 release];
                            if (arg_318 != 0x0) {
                                    arg_1D8 = arg_318;
                                    arg_1D4 = *__error();
                                    r0 = __error();
                                    r0 = *r0;
                                    r0 = strerror(r0);
                                    arg_1D0 = r0;
                                    r0 = _logToFile("copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_1D8, arg_1D4, arg_1D0, STK-1);
                            }
                            else {
                                    asm{ uxthne     r1, r1 };
                                    arg_318 = mkdir("/Library/LaunchDaemons", 0x1ed);
                                    if (arg_318 != 0x0) {
                                            arg_1CC = arg_318;
                                            arg_1C8 = *__error();
                                            r0 = __error();
                                            r0 = *r0;
                                            r0 = strerror(r0);
                                            arg_1C4 = r0;
                                            _logToFile("mkdir returned nonzero value: %d, errno: %d, strerror: %s\n", arg_1CC, arg_1C8, arg_1C4, STK-1);
                                    }
                                    r0 = *objc_msgSend;
                                    arg_1C0 = r0;
                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_1C0);
                                    r7 = r7;
                                    r0 = [r0 retain];
                                    r2 = *objc_msgSend;
                                    arg_1BC = r0;
                                    arg_1B8 = @"/Library/LaunchDaemons/dropbear.plist";
                                    r3 = arg_1B8;
                                    arg_1B4 = r2;
                                    r2 = r3;
                                    COND = sign_extend_32(("fileExistsAtPath:")(r0, @selector(fileExistsAtPath:), r2, r3)) == 0x0;
                                    r0 = 0x0;
                                    asm{ it         ne };
                                    if (!COND) {
                                            r0 = 0x1;
                                    }
                                    r1 = arg_1BC;
                                    arg_1B0 = r0 ^ 0xffffffff;
                                    [r1 release];
                                    if ((arg_1B0 & 0x1) != 0x0) {
                                            r0 = *objc_msgSend;
                                            arg_1AC = r0;
                                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_1AC);
                                            r0 = [r0 retain];
                                            arg_1A8 = r0;
                                            arg_1A4 = @"dropbear";
                                            arg_1A0 = @"plist";
                                            r0 = _objc_msgSend(r0, @selector(URLForResource:withExtension:), arg_1A4, arg_1A0);
                                            r0 = [r0 retain];
                                            r1 = *objc_msgSend;
                                            r3 = r0;
                                            arg_19C = r0;
                                            arg_198 = r1;
                                            r0 = loc_63a52(r3, @selector(path), arg_198, r3);
                                            r0 = [r0 retain];
                                            arg_194 = r0;
                                            objc_retainAutorelease(r0);
                                            r1 = *objc_msgSend;
                                            arg_190 = r1;
                                            r0 = ("UTF8String")();
                                            arg_18C = r0;
                                            _logToFile("We will try copying %s to %s\n", arg_18C, "/Library/LaunchDaemons/dropbear.plist", r3, STK-1);
                                            [arg_194 release];
                                            [arg_19C release];
                                            [arg_1A8 release];
                                            r0 = *objc_msgSend;
                                            arg_188 = r0;
                                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_188);
                                            r0 = [r0 retain];
                                            r3 = *objc_msgSend;
                                            arg_184 = r0;
                                            arg_180 = @"dropbear";
                                            arg_17C = @"plist";
                                            arg_178 = r3;
                                            r0 = [r0 URLForResource:arg_180 withExtension:arg_17C];
                                            r0 = [r0 retain];
                                            r1 = *objc_msgSend;
                                            arg_174 = r0;
                                            arg_170 = r1;
                                            r0 = loc_63a52(r0, @selector(path), arg_170, r0);
                                            r7 = r7;
                                            r0 = [r0 retain];
                                            arg_16C = r0;
                                            objc_retainAutorelease(r0);
                                            r1 = *objc_msgSend;
                                            arg_168 = r1;
                                            r0 = ("UTF8String")();
                                            r1 = "/Library/LaunchDaemons/dropbear.plist";
                                            r2 = 0x0;
                                            r3 = 0xf;
                                            arg_318 = copyfile(r0, r1, r2, r3);
                                            [arg_16C release];
                                            [arg_174 release];
                                            [arg_184 release];
                                            if (arg_318 != 0x0) {
                                                    arg_164 = arg_318;
                                                    arg_160 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_15C = r0;
                                                    r0 = _logToFile("Copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_164, arg_160, arg_15C, STK-1);
                                            }
                                            else {
                                                    _logToFile("Changing permissions\n", r1, r2, r3, STK-1);
                                                    asm{ uxthne.w   r1, lr };
                                                    arg_318 = chmod("/bin/tar", r1);
                                                    if (arg_318 != 0x0) {
                                                            arg_158 = arg_318;
                                                            arg_154 = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_150 = r0;
                                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_158, arg_154, arg_150, STK-1);
                                                    }
                                                    else {
                                                            asm{ uxth       r1, r1 };
                                                            arg_318 = chmod("/bin/launchctl", 0x1ff);
                                                            if (arg_318 != 0x0) {
                                                                    arg_14C = arg_318;
                                                                    arg_148 = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_144 = r0;
                                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_14C, arg_148, arg_144, STK-1);
                                                            }
                                                            else {
                                                                    asm{ uxth       r1, r1 };
                                                                    arg_318 = chmod("/Library/LaunchDaemons/dropbear.plist", 0x180);
                                                                    if (arg_318 != 0x0) {
                                                                            arg_140 = arg_318;
                                                                            arg_13C = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_138 = r0;
                                                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_140, arg_13C, arg_138, STK-1);
                                                                    }
                                                                    else {
                                                                            arg_134 = 0x0;
                                                                            arg_318 = chown("/Library/LaunchDaemons/dropbear.plist", 0x0, arg_134);
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_130 = arg_318;
                                                                                    arg_12C = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_128 = r0;
                                                                                    r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_130, arg_12C, arg_128, STK-1);
                                                                            }
                                                                            else {
                                                                                    r0 = *objc_msgSend;
                                                                                    arg_124 = r0;
                                                                                    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_124);
                                                                                    r0 = [r0 retain];
                                                                                    r2 = *objc_msgSend;
                                                                                    arg_30C = @"YLUProgressString";
                                                                                    arg_310 = @"Installing Cydia";
                                                                                    arg_120 = r0;
                                                                                    arg_11C = 0x1;
                                                                                    arg_118 = r2;
                                                                                    var_0 = arg_11C;
                                                                                    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_310, &arg_30C);
                                                                                    r0 = [r0 retain];
                                                                                    r2 = *objc_msgSend;
                                                                                    arg_114 = r0;
                                                                                    arg_110 = @"YLUDidReceiveUpdateProgressNotification";
                                                                                    arg_10C = r2;
                                                                                    var_0 = arg_114;
                                                                                    [arg_120 postNotificationName:arg_110 object:0x0 userInfo:STK-1];
                                                                                    [arg_114 release];
                                                                                    [arg_120 release];
                                                                                    r0 = *objc_msgSend;
                                                                                    arg_108 = r0;
                                                                                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_108);
                                                                                    r0 = [r0 retain];
                                                                                    r3 = *objc_msgSend;
                                                                                    arg_104 = r0;
                                                                                    arg_100 = @"Cydia-9.0r4-Raw";
                                                                                    arg_FC = @"tar";
                                                                                    arg_F8 = r3;
                                                                                    arg_308 = [[r0 URLForResource:arg_100 withExtension:arg_FC] retain];
                                                                                    [arg_104 release];
                                                                                    r0 = *objc_msgSend;
                                                                                    arg_F4 = r0;
                                                                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F4);
                                                                                    r7 = r7;
                                                                                    r0 = [r0 retain];
                                                                                    r2 = *objc_msgSend;
                                                                                    arg_F0 = r0;
                                                                                    arg_EC = @"/Applications/Cydia.app/";
                                                                                    r3 = arg_EC;
                                                                                    arg_E8 = r2;
                                                                                    r2 = r3;
                                                                                    COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                                    r0 = 0x0;
                                                                                    asm{ it         ne };
                                                                                    if (!COND) {
                                                                                            r0 = 0x1;
                                                                                    }
                                                                                    r1 = arg_F0;
                                                                                    arg_E4 = r0 ^ 0xffffffff;
                                                                                    [r1 release];
                                                                                    if ((arg_E4 & 0x1) != 0x0) {
                                                                                            _logToFile("Didn't find Cydia.app (so we'll assume bearded old bootstrap isn't extracted, we will extract it)\n", r1, r2, r3, STK-1);
                                                                                            arg_E0 = @"/bin/tar";
                                                                                            r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_E0);
                                                                                            r0 = [r0 retain];
                                                                                            r1 = *objc_msgSend;
                                                                                            arg_2F4 = @"-xvf";
                                                                                            arg_DC = r0;
                                                                                            arg_D8 = r1;
                                                                                            r0 = loc_63a52(arg_308, @selector(path), arg_D8);
                                                                                            r0 = [r0 retain];
                                                                                            r1 = *objc_msgSend;
                                                                                            arg_2F8 = r0;
                                                                                            arg_2FC = @"-C";
                                                                                            arg_300 = @"/";
                                                                                            arg_304 = @"--preserve-permissions";
                                                                                            arg_D4 = r0;
                                                                                            arg_D0 = r1;
                                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2F4, 0x5);
                                                                                            r7 = r7;
                                                                                            arg_CC = [r0 retain];
                                                                                            arg_318 = _easyPosixSpawn(arg_DC, arg_CC);
                                                                                            [arg_CC release];
                                                                                            [arg_D4 release];
                                                                                            [arg_DC release];
                                                                                            if (arg_318 != 0x0) {
                                                                                                    arg_C8 = arg_318;
                                                                                                    arg_C4 = *__error();
                                                                                                    r0 = __error();
                                                                                                    r0 = *r0;
                                                                                                    r0 = strerror(r0);
                                                                                                    arg_C0 = r0;
                                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C8, arg_C4, arg_C0, STK-1);
                                                                                            }
                                                                                    }
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_BC = @"/usr/bin/killall";
                                                                                    arg_B8 = r1;
                                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_BC, arg_B8);
                                                                                    r0 = [r0 retain];
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_2EC = @"-SIGSTOP";
                                                                                    arg_2F0 = @"cfprefsd";
                                                                                    arg_B4 = r0;
                                                                                    arg_B0 = r1;
                                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2EC, 0x2);
                                                                                    r7 = r7;
                                                                                    arg_AC = [r0 retain];
                                                                                    arg_A8 = _easyPosixSpawn(arg_B4, arg_AC);
                                                                                    [arg_AC release];
                                                                                    [arg_B4 release];
                                                                                    if (arg_318 != 0x0) {
                                                                                            arg_A4 = arg_318;
                                                                                            arg_A0 = *__error();
                                                                                            r0 = __error();
                                                                                            r0 = *r0;
                                                                                            r0 = strerror(r0);
                                                                                            arg_9C = r0;
                                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A4, arg_A0, arg_9C, STK-1);
                                                                                    }
                                                                                    r0 = *objc_msgSend;
                                                                                    arg_98 = r0;
                                                                                    r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_98);
                                                                                    r2 = *objc_msgSend;
                                                                                    arg_94 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                                    arg_90 = r2;
                                                                                    r0 = [r0 initWithContentsOfFile:arg_94];
                                                                                    r2 = *objc_msgSend;
                                                                                    arg_2E8 = r0;
                                                                                    arg_8C = arg_2E8;
                                                                                    arg_88 = 0x1;
                                                                                    arg_84 = r2;
                                                                                    r0 = [NSNumber numberWithBool:sign_extend_32(arg_88)];
                                                                                    r0 = [r0 retain];
                                                                                    r2 = *objc_msgSend;
                                                                                    arg_80 = r0;
                                                                                    arg_7C = @"SBShowNonDefaultSystemApps";
                                                                                    arg_78 = r2;
                                                                                    [arg_8C setObject:r0 forKey:arg_7C];
                                                                                    [arg_80 release];
                                                                                    r2 = *objc_msgSend;
                                                                                    arg_74 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                                    arg_70 = 0x1;
                                                                                    arg_6C = r2;
                                                                                    r0 = [arg_2E8 writeToFile:arg_74 atomically:sign_extend_32(arg_70)];
                                                                                    r2 = *objc_msgSend;
                                                                                    arg_68 = r0;
                                                                                    arg_64 = @"/usr/bin/killall";
                                                                                    arg_60 = r2;
                                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_64, arg_64);
                                                                                    r0 = [r0 retain];
                                                                                    r3 = 0x2;
                                                                                    r1 = *objc_msgSend;
                                                                                    r2 = &arg_2E0;
                                                                                    arg_2E0 = @"-9";
                                                                                    arg_2E4 = @"cfprefsd";
                                                                                    arg_5C = r0;
                                                                                    arg_58 = r1;
                                                                                    r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), r2, r3);
                                                                                    r7 = r7;
                                                                                    arg_54 = [r0 retain];
                                                                                    r1 = arg_54;
                                                                                    arg_318 = _easyPosixSpawn(arg_5C, r1);
                                                                                    [arg_54 release];
                                                                                    [arg_5C release];
                                                                                    if (arg_318 != 0x0) {
                                                                                            arg_50 = arg_318;
                                                                                            arg_4C = *__error();
                                                                                            r0 = __error();
                                                                                            r0 = *r0;
                                                                                            r0 = strerror(r0);
                                                                                            arg_48 = r0;
                                                                                            r1 = arg_50;
                                                                                            r2 = arg_4C;
                                                                                            r3 = arg_48;
                                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", r1, r2, r3, STK-1);
                                                                                    }
                                                                                    _logToFile("Touching /.bearded_old_man_no_stash\n", r1, r2, r3, STK-1);
                                                                                    arg_44 = @"/bin/touch";
                                                                                    r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_44);
                                                                                    r0 = [r0 retain];
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_2DC = @"/.cydia_no_stash";
                                                                                    arg_40 = r0;
                                                                                    arg_3C = r1;
                                                                                    arg_38 = [_OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2DC, 0x1) retain];
                                                                                    arg_318 = _easyPosixSpawn(arg_40, arg_38);
                                                                                    [arg_38 release];
                                                                                    [arg_40 release];
                                                                                    r0 = *objc_msgSend;
                                                                                    arg_34 = r0;
                                                                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_34);
                                                                                    r7 = r7;
                                                                                    r0 = [r0 retain];
                                                                                    r2 = *objc_msgSend;
                                                                                    arg_30 = r0;
                                                                                    arg_2C = @"/.cydia_no_stash";
                                                                                    r3 = arg_2C;
                                                                                    arg_28 = r2;
                                                                                    r2 = r3;
                                                                                    COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                                    r0 = 0x0;
                                                                                    asm{  };
                                                                                    if (!COND) {
                                                                                            r0 = 0x1;
                                                                                    }
                                                                                    r1 = arg_30;
                                                                                    arg_24 = r0 ^ 0xffffffff;
                                                                                    [r1 release];
                                                                                    if ((arg_24 & 0x1) != 0x0) {
                                                                                            _logToFile("WARNING WARNING WARNING\n", r1, r2, r3, STK-1);
                                                                                            _logToFile("Even though we tried creating cydia_no_stash it looks like it's not there. So don't open the app by bearded old man (aka saurik)!\n", r1, r2, r3, STK-1);
                                                                                    }
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_20 = @"/bin/touch";
                                                                                    arg_1C = r1;
                                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_20, arg_1C);
                                                                                    r0 = [r0 retain];
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_2D8 = @"/.installed_home_depot";
                                                                                    arg_18 = r0;
                                                                                    arg_14 = r1;
                                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2D8, 0x1);
                                                                                    arg_10 = [r0 retain];
                                                                                    arg_C = _easyPosixSpawn(arg_18, arg_10);
                                                                                    [arg_10 release];
                                                                                    [arg_18 release];
                                                                                    _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_324, arg_328, 0x1, STK-1);
                                                                                    r0 = system("su mobile -c uicache");
                                                                                    arg_8 = r0;
                                                                                    arg_4 = system("killall backboardd");
                                                                                    _write_primitive(arg_328, arg_324);
                                                                                    objc_storeStrong(&arg_2E8, 0x0);
                                                                                    r0 = objc_storeStrong(&arg_308, 0x0);
                                                                            }
                                                                    }
                                                            }
                                                    }
                                            }
                                    }
                                    else {
                                            _logToFile("Changing permissions\n", r1, r2, r3, STK-1);
                                            asm{ uxthne.w   r1, lr };
                                            arg_318 = chmod("/bin/tar", r1);
                                            if (arg_318 != 0x0) {
                                                    arg_158 = arg_318;
                                                    arg_154 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_150 = r0;
                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_158, arg_154, arg_150, STK-1);
                                            }
                                            else {
                                                    asm{ uxth       r1, r1 };
                                                    arg_318 = chmod("/bin/launchctl", 0x1ff);
                                                    if (arg_318 != 0x0) {
                                                            arg_14C = arg_318;
                                                            arg_148 = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_144 = r0;
                                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_14C, arg_148, arg_144, STK-1);
                                                    }
                                                    else {
                                                            asm{ uxth       r1, r1 };
                                                            arg_318 = chmod("/Library/LaunchDaemons/dropbear.plist", 0x180);
                                                            if (arg_318 != 0x0) {
                                                                    arg_140 = arg_318;
                                                                    arg_13C = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_138 = r0;
                                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_140, arg_13C, arg_138, STK-1);
                                                            }
                                                            else {
                                                                    arg_134 = 0x0;
                                                                    arg_318 = chown("/Library/LaunchDaemons/dropbear.plist", 0x0, arg_134);
                                                                    if (arg_318 != 0x0) {
                                                                            arg_130 = arg_318;
                                                                            arg_12C = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_128 = r0;
                                                                            r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_130, arg_12C, arg_128, STK-1);
                                                                    }
                                                                    else {
                                                                            r0 = *objc_msgSend;
                                                                            arg_124 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_124);
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_30C = @"YLUProgressString";
                                                                            arg_310 = @"Installing Cydia";
                                                                            arg_120 = r0;
                                                                            arg_11C = 0x1;
                                                                            arg_118 = r2;
                                                                            var_0 = arg_11C;
                                                                            r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_310, &arg_30C);
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_114 = r0;
                                                                            arg_110 = @"YLUDidReceiveUpdateProgressNotification";
                                                                            arg_10C = r2;
                                                                            var_0 = arg_114;
                                                                            [arg_120 postNotificationName:arg_110 object:0x0 userInfo:STK-1];
                                                                            [arg_114 release];
                                                                            [arg_120 release];
                                                                            r0 = *objc_msgSend;
                                                                            arg_108 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_108);
                                                                            r0 = [r0 retain];
                                                                            r3 = *objc_msgSend;
                                                                            arg_104 = r0;
                                                                            arg_100 = @"Cydia-9.0r4-Raw";
                                                                            arg_FC = @"tar";
                                                                            arg_F8 = r3;
                                                                            arg_308 = [[r0 URLForResource:arg_100 withExtension:arg_FC] retain];
                                                                            [arg_104 release];
                                                                            r0 = *objc_msgSend;
                                                                            arg_F4 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F4);
                                                                            r7 = r7;
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_F0 = r0;
                                                                            arg_EC = @"/Applications/Cydia.app/";
                                                                            r3 = arg_EC;
                                                                            arg_E8 = r2;
                                                                            r2 = r3;
                                                                            COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                            r0 = 0x0;
                                                                            asm{ it         ne };
                                                                            if (!COND) {
                                                                                    r0 = 0x1;
                                                                            }
                                                                            r1 = arg_F0;
                                                                            arg_E4 = r0 ^ 0xffffffff;
                                                                            [r1 release];
                                                                            if ((arg_E4 & 0x1) != 0x0) {
                                                                                    _logToFile("Didn't find Cydia.app (so we'll assume bearded old bootstrap isn't extracted, we will extract it)\n", r1, r2, r3, STK-1);
                                                                                    arg_E0 = @"/bin/tar";
                                                                                    r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_E0);
                                                                                    r0 = [r0 retain];
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_2F4 = @"-xvf";
                                                                                    arg_DC = r0;
                                                                                    arg_D8 = r1;
                                                                                    r0 = loc_63a52(arg_308, @selector(path), arg_D8);
                                                                                    r0 = [r0 retain];
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_2F8 = r0;
                                                                                    arg_2FC = @"-C";
                                                                                    arg_300 = @"/";
                                                                                    arg_304 = @"--preserve-permissions";
                                                                                    arg_D4 = r0;
                                                                                    arg_D0 = r1;
                                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2F4, 0x5);
                                                                                    r7 = r7;
                                                                                    arg_CC = [r0 retain];
                                                                                    arg_318 = _easyPosixSpawn(arg_DC, arg_CC);
                                                                                    [arg_CC release];
                                                                                    [arg_D4 release];
                                                                                    [arg_DC release];
                                                                                    if (arg_318 != 0x0) {
                                                                                            arg_C8 = arg_318;
                                                                                            arg_C4 = *__error();
                                                                                            r0 = __error();
                                                                                            r0 = *r0;
                                                                                            r0 = strerror(r0);
                                                                                            arg_C0 = r0;
                                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C8, arg_C4, arg_C0, STK-1);
                                                                                    }
                                                                            }
                                                                            r1 = *objc_msgSend;
                                                                            arg_BC = @"/usr/bin/killall";
                                                                            arg_B8 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_BC, arg_B8);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2EC = @"-SIGSTOP";
                                                                            arg_2F0 = @"cfprefsd";
                                                                            arg_B4 = r0;
                                                                            arg_B0 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2EC, 0x2);
                                                                            r7 = r7;
                                                                            arg_AC = [r0 retain];
                                                                            arg_A8 = _easyPosixSpawn(arg_B4, arg_AC);
                                                                            [arg_AC release];
                                                                            [arg_B4 release];
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_A4 = arg_318;
                                                                                    arg_A0 = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_9C = r0;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A4, arg_A0, arg_9C, STK-1);
                                                                            }
                                                                            r0 = *objc_msgSend;
                                                                            arg_98 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_98);
                                                                            r2 = *objc_msgSend;
                                                                            arg_94 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                            arg_90 = r2;
                                                                            r0 = [r0 initWithContentsOfFile:arg_94];
                                                                            r2 = *objc_msgSend;
                                                                            arg_2E8 = r0;
                                                                            arg_8C = arg_2E8;
                                                                            arg_88 = 0x1;
                                                                            arg_84 = r2;
                                                                            r0 = [NSNumber numberWithBool:sign_extend_32(arg_88)];
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_80 = r0;
                                                                            arg_7C = @"SBShowNonDefaultSystemApps";
                                                                            arg_78 = r2;
                                                                            [arg_8C setObject:r0 forKey:arg_7C];
                                                                            [arg_80 release];
                                                                            r2 = *objc_msgSend;
                                                                            arg_74 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                            arg_70 = 0x1;
                                                                            arg_6C = r2;
                                                                            r0 = [arg_2E8 writeToFile:arg_74 atomically:sign_extend_32(arg_70)];
                                                                            r2 = *objc_msgSend;
                                                                            arg_68 = r0;
                                                                            arg_64 = @"/usr/bin/killall";
                                                                            arg_60 = r2;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_64, arg_64);
                                                                            r0 = [r0 retain];
                                                                            r3 = 0x2;
                                                                            r1 = *objc_msgSend;
                                                                            r2 = &arg_2E0;
                                                                            arg_2E0 = @"-9";
                                                                            arg_2E4 = @"cfprefsd";
                                                                            arg_5C = r0;
                                                                            arg_58 = r1;
                                                                            r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), r2, r3);
                                                                            r7 = r7;
                                                                            arg_54 = [r0 retain];
                                                                            r1 = arg_54;
                                                                            arg_318 = _easyPosixSpawn(arg_5C, r1);
                                                                            [arg_54 release];
                                                                            [arg_5C release];
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_50 = arg_318;
                                                                                    arg_4C = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_48 = r0;
                                                                                    r1 = arg_50;
                                                                                    r2 = arg_4C;
                                                                                    r3 = arg_48;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", r1, r2, r3, STK-1);
                                                                            }
                                                                            _logToFile("Touching /.bearded_old_man_no_stash\n", r1, r2, r3, STK-1);
                                                                            arg_44 = @"/bin/touch";
                                                                            r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_44);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2DC = @"/.cydia_no_stash";
                                                                            arg_40 = r0;
                                                                            arg_3C = r1;
                                                                            arg_38 = [_OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2DC, 0x1) retain];
                                                                            arg_318 = _easyPosixSpawn(arg_40, arg_38);
                                                                            [arg_38 release];
                                                                            [arg_40 release];
                                                                            r0 = *objc_msgSend;
                                                                            arg_34 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_34);
                                                                            r7 = r7;
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_30 = r0;
                                                                            arg_2C = @"/.cydia_no_stash";
                                                                            r3 = arg_2C;
                                                                            arg_28 = r2;
                                                                            r2 = r3;
                                                                            COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                            r0 = 0x0;
                                                                            asm{  };
                                                                            if (!COND) {
                                                                                    r0 = 0x1;
                                                                            }
                                                                            r1 = arg_30;
                                                                            arg_24 = r0 ^ 0xffffffff;
                                                                            [r1 release];
                                                                            if ((arg_24 & 0x1) != 0x0) {
                                                                                    _logToFile("WARNING WARNING WARNING\n", r1, r2, r3, STK-1);
                                                                                    _logToFile("Even though we tried creating cydia_no_stash it looks like it's not there. So don't open the app by bearded old man (aka saurik)!\n", r1, r2, r3, STK-1);
                                                                            }
                                                                            r1 = *objc_msgSend;
                                                                            arg_20 = @"/bin/touch";
                                                                            arg_1C = r1;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_20, arg_1C);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2D8 = @"/.installed_home_depot";
                                                                            arg_18 = r0;
                                                                            arg_14 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2D8, 0x1);
                                                                            arg_10 = [r0 retain];
                                                                            arg_C = _easyPosixSpawn(arg_18, arg_10);
                                                                            [arg_10 release];
                                                                            [arg_18 release];
                                                                            _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_324, arg_328, 0x1, STK-1);
                                                                            r0 = system("su mobile -c uicache");
                                                                            arg_8 = r0;
                                                                            arg_4 = system("killall backboardd");
                                                                            _write_primitive(arg_328, arg_324);
                                                                            objc_storeStrong(&arg_2E8, 0x0);
                                                                            r0 = objc_storeStrong(&arg_308, 0x0);
                                                                    }
                                                            }
                                                    }
                                            }
                                    }
                            }
                    }
                    else {
                            asm{ uxthne     r1, r1 };
                            arg_318 = mkdir("/Library/LaunchDaemons", 0x1ed);
                            if (arg_318 != 0x0) {
                                    arg_1CC = arg_318;
                                    arg_1C8 = *__error();
                                    r0 = __error();
                                    r0 = *r0;
                                    r0 = strerror(r0);
                                    arg_1C4 = r0;
                                    _logToFile("mkdir returned nonzero value: %d, errno: %d, strerror: %s\n", arg_1CC, arg_1C8, arg_1C4, STK-1);
                            }
                            r0 = *objc_msgSend;
                            arg_1C0 = r0;
                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_1C0);
                            r7 = r7;
                            r0 = [r0 retain];
                            r2 = *objc_msgSend;
                            arg_1BC = r0;
                            arg_1B8 = @"/Library/LaunchDaemons/dropbear.plist";
                            r3 = arg_1B8;
                            arg_1B4 = r2;
                            r2 = r3;
                            COND = sign_extend_32(("fileExistsAtPath:")(r0, @selector(fileExistsAtPath:), r2, r3)) == 0x0;
                            r0 = 0x0;
                            asm{ it         ne };
                            if (!COND) {
                                    r0 = 0x1;
                            }
                            r1 = arg_1BC;
                            arg_1B0 = r0 ^ 0xffffffff;
                            [r1 release];
                            if ((arg_1B0 & 0x1) != 0x0) {
                                    r0 = *objc_msgSend;
                                    arg_1AC = r0;
                                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_1AC);
                                    r0 = [r0 retain];
                                    arg_1A8 = r0;
                                    arg_1A4 = @"dropbear";
                                    arg_1A0 = @"plist";
                                    r0 = _objc_msgSend(r0, @selector(URLForResource:withExtension:), arg_1A4, arg_1A0);
                                    r0 = [r0 retain];
                                    r1 = *objc_msgSend;
                                    r3 = r0;
                                    arg_19C = r0;
                                    arg_198 = r1;
                                    r0 = loc_63a52(r3, @selector(path), arg_198, r3);
                                    r0 = [r0 retain];
                                    arg_194 = r0;
                                    objc_retainAutorelease(r0);
                                    r1 = *objc_msgSend;
                                    arg_190 = r1;
                                    r0 = ("UTF8String")();
                                    arg_18C = r0;
                                    _logToFile("We will try copying %s to %s\n", arg_18C, "/Library/LaunchDaemons/dropbear.plist", r3, STK-1);
                                    [arg_194 release];
                                    [arg_19C release];
                                    [arg_1A8 release];
                                    r0 = *objc_msgSend;
                                    arg_188 = r0;
                                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_188);
                                    r0 = [r0 retain];
                                    r3 = *objc_msgSend;
                                    arg_184 = r0;
                                    arg_180 = @"dropbear";
                                    arg_17C = @"plist";
                                    arg_178 = r3;
                                    r0 = [r0 URLForResource:arg_180 withExtension:arg_17C];
                                    r0 = [r0 retain];
                                    r1 = *objc_msgSend;
                                    arg_174 = r0;
                                    arg_170 = r1;
                                    r0 = loc_63a52(r0, @selector(path), arg_170, r0);
                                    r7 = r7;
                                    r0 = [r0 retain];
                                    arg_16C = r0;
                                    objc_retainAutorelease(r0);
                                    r1 = *objc_msgSend;
                                    arg_168 = r1;
                                    r0 = ("UTF8String")();
                                    r1 = "/Library/LaunchDaemons/dropbear.plist";
                                    r2 = 0x0;
                                    r3 = 0xf;
                                    arg_318 = copyfile(r0, r1, r2, r3);
                                    [arg_16C release];
                                    [arg_174 release];
                                    [arg_184 release];
                                    if (arg_318 != 0x0) {
                                            arg_164 = arg_318;
                                            arg_160 = *__error();
                                            r0 = __error();
                                            r0 = *r0;
                                            r0 = strerror(r0);
                                            arg_15C = r0;
                                            r0 = _logToFile("Copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_164, arg_160, arg_15C, STK-1);
                                    }
                                    else {
                                            _logToFile("Changing permissions\n", r1, r2, r3, STK-1);
                                            asm{ uxthne.w   r1, lr };
                                            arg_318 = chmod("/bin/tar", r1);
                                            if (arg_318 != 0x0) {
                                                    arg_158 = arg_318;
                                                    arg_154 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_150 = r0;
                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_158, arg_154, arg_150, STK-1);
                                            }
                                            else {
                                                    asm{ uxth       r1, r1 };
                                                    arg_318 = chmod("/bin/launchctl", 0x1ff);
                                                    if (arg_318 != 0x0) {
                                                            arg_14C = arg_318;
                                                            arg_148 = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_144 = r0;
                                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_14C, arg_148, arg_144, STK-1);
                                                    }
                                                    else {
                                                            asm{ uxth       r1, r1 };
                                                            arg_318 = chmod("/Library/LaunchDaemons/dropbear.plist", 0x180);
                                                            if (arg_318 != 0x0) {
                                                                    arg_140 = arg_318;
                                                                    arg_13C = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_138 = r0;
                                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_140, arg_13C, arg_138, STK-1);
                                                            }
                                                            else {
                                                                    arg_134 = 0x0;
                                                                    arg_318 = chown("/Library/LaunchDaemons/dropbear.plist", 0x0, arg_134);
                                                                    if (arg_318 != 0x0) {
                                                                            arg_130 = arg_318;
                                                                            arg_12C = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_128 = r0;
                                                                            r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_130, arg_12C, arg_128, STK-1);
                                                                    }
                                                                    else {
                                                                            r0 = *objc_msgSend;
                                                                            arg_124 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_124);
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_30C = @"YLUProgressString";
                                                                            arg_310 = @"Installing Cydia";
                                                                            arg_120 = r0;
                                                                            arg_11C = 0x1;
                                                                            arg_118 = r2;
                                                                            var_0 = arg_11C;
                                                                            r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_310, &arg_30C);
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_114 = r0;
                                                                            arg_110 = @"YLUDidReceiveUpdateProgressNotification";
                                                                            arg_10C = r2;
                                                                            var_0 = arg_114;
                                                                            [arg_120 postNotificationName:arg_110 object:0x0 userInfo:STK-1];
                                                                            [arg_114 release];
                                                                            [arg_120 release];
                                                                            r0 = *objc_msgSend;
                                                                            arg_108 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_108);
                                                                            r0 = [r0 retain];
                                                                            r3 = *objc_msgSend;
                                                                            arg_104 = r0;
                                                                            arg_100 = @"Cydia-9.0r4-Raw";
                                                                            arg_FC = @"tar";
                                                                            arg_F8 = r3;
                                                                            arg_308 = [[r0 URLForResource:arg_100 withExtension:arg_FC] retain];
                                                                            [arg_104 release];
                                                                            r0 = *objc_msgSend;
                                                                            arg_F4 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F4);
                                                                            r7 = r7;
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_F0 = r0;
                                                                            arg_EC = @"/Applications/Cydia.app/";
                                                                            r3 = arg_EC;
                                                                            arg_E8 = r2;
                                                                            r2 = r3;
                                                                            COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                            r0 = 0x0;
                                                                            asm{ it         ne };
                                                                            if (!COND) {
                                                                                    r0 = 0x1;
                                                                            }
                                                                            r1 = arg_F0;
                                                                            arg_E4 = r0 ^ 0xffffffff;
                                                                            [r1 release];
                                                                            if ((arg_E4 & 0x1) != 0x0) {
                                                                                    _logToFile("Didn't find Cydia.app (so we'll assume bearded old bootstrap isn't extracted, we will extract it)\n", r1, r2, r3, STK-1);
                                                                                    arg_E0 = @"/bin/tar";
                                                                                    r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_E0);
                                                                                    r0 = [r0 retain];
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_2F4 = @"-xvf";
                                                                                    arg_DC = r0;
                                                                                    arg_D8 = r1;
                                                                                    r0 = loc_63a52(arg_308, @selector(path), arg_D8);
                                                                                    r0 = [r0 retain];
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_2F8 = r0;
                                                                                    arg_2FC = @"-C";
                                                                                    arg_300 = @"/";
                                                                                    arg_304 = @"--preserve-permissions";
                                                                                    arg_D4 = r0;
                                                                                    arg_D0 = r1;
                                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2F4, 0x5);
                                                                                    r7 = r7;
                                                                                    arg_CC = [r0 retain];
                                                                                    arg_318 = _easyPosixSpawn(arg_DC, arg_CC);
                                                                                    [arg_CC release];
                                                                                    [arg_D4 release];
                                                                                    [arg_DC release];
                                                                                    if (arg_318 != 0x0) {
                                                                                            arg_C8 = arg_318;
                                                                                            arg_C4 = *__error();
                                                                                            r0 = __error();
                                                                                            r0 = *r0;
                                                                                            r0 = strerror(r0);
                                                                                            arg_C0 = r0;
                                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C8, arg_C4, arg_C0, STK-1);
                                                                                    }
                                                                            }
                                                                            r1 = *objc_msgSend;
                                                                            arg_BC = @"/usr/bin/killall";
                                                                            arg_B8 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_BC, arg_B8);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2EC = @"-SIGSTOP";
                                                                            arg_2F0 = @"cfprefsd";
                                                                            arg_B4 = r0;
                                                                            arg_B0 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2EC, 0x2);
                                                                            r7 = r7;
                                                                            arg_AC = [r0 retain];
                                                                            arg_A8 = _easyPosixSpawn(arg_B4, arg_AC);
                                                                            [arg_AC release];
                                                                            [arg_B4 release];
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_A4 = arg_318;
                                                                                    arg_A0 = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_9C = r0;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A4, arg_A0, arg_9C, STK-1);
                                                                            }
                                                                            r0 = *objc_msgSend;
                                                                            arg_98 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_98);
                                                                            r2 = *objc_msgSend;
                                                                            arg_94 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                            arg_90 = r2;
                                                                            r0 = [r0 initWithContentsOfFile:arg_94];
                                                                            r2 = *objc_msgSend;
                                                                            arg_2E8 = r0;
                                                                            arg_8C = arg_2E8;
                                                                            arg_88 = 0x1;
                                                                            arg_84 = r2;
                                                                            r0 = [NSNumber numberWithBool:sign_extend_32(arg_88)];
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_80 = r0;
                                                                            arg_7C = @"SBShowNonDefaultSystemApps";
                                                                            arg_78 = r2;
                                                                            [arg_8C setObject:r0 forKey:arg_7C];
                                                                            [arg_80 release];
                                                                            r2 = *objc_msgSend;
                                                                            arg_74 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                            arg_70 = 0x1;
                                                                            arg_6C = r2;
                                                                            r0 = [arg_2E8 writeToFile:arg_74 atomically:sign_extend_32(arg_70)];
                                                                            r2 = *objc_msgSend;
                                                                            arg_68 = r0;
                                                                            arg_64 = @"/usr/bin/killall";
                                                                            arg_60 = r2;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_64, arg_64);
                                                                            r0 = [r0 retain];
                                                                            r3 = 0x2;
                                                                            r1 = *objc_msgSend;
                                                                            r2 = &arg_2E0;
                                                                            arg_2E0 = @"-9";
                                                                            arg_2E4 = @"cfprefsd";
                                                                            arg_5C = r0;
                                                                            arg_58 = r1;
                                                                            r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), r2, r3);
                                                                            r7 = r7;
                                                                            arg_54 = [r0 retain];
                                                                            r1 = arg_54;
                                                                            arg_318 = _easyPosixSpawn(arg_5C, r1);
                                                                            [arg_54 release];
                                                                            [arg_5C release];
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_50 = arg_318;
                                                                                    arg_4C = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_48 = r0;
                                                                                    r1 = arg_50;
                                                                                    r2 = arg_4C;
                                                                                    r3 = arg_48;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", r1, r2, r3, STK-1);
                                                                            }
                                                                            _logToFile("Touching /.bearded_old_man_no_stash\n", r1, r2, r3, STK-1);
                                                                            arg_44 = @"/bin/touch";
                                                                            r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_44);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2DC = @"/.cydia_no_stash";
                                                                            arg_40 = r0;
                                                                            arg_3C = r1;
                                                                            arg_38 = [_OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2DC, 0x1) retain];
                                                                            arg_318 = _easyPosixSpawn(arg_40, arg_38);
                                                                            [arg_38 release];
                                                                            [arg_40 release];
                                                                            r0 = *objc_msgSend;
                                                                            arg_34 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_34);
                                                                            r7 = r7;
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_30 = r0;
                                                                            arg_2C = @"/.cydia_no_stash";
                                                                            r3 = arg_2C;
                                                                            arg_28 = r2;
                                                                            r2 = r3;
                                                                            COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                            r0 = 0x0;
                                                                            asm{  };
                                                                            if (!COND) {
                                                                                    r0 = 0x1;
                                                                            }
                                                                            r1 = arg_30;
                                                                            arg_24 = r0 ^ 0xffffffff;
                                                                            [r1 release];
                                                                            if ((arg_24 & 0x1) != 0x0) {
                                                                                    _logToFile("WARNING WARNING WARNING\n", r1, r2, r3, STK-1);
                                                                                    _logToFile("Even though we tried creating cydia_no_stash it looks like it's not there. So don't open the app by bearded old man (aka saurik)!\n", r1, r2, r3, STK-1);
                                                                            }
                                                                            r1 = *objc_msgSend;
                                                                            arg_20 = @"/bin/touch";
                                                                            arg_1C = r1;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_20, arg_1C);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2D8 = @"/.installed_home_depot";
                                                                            arg_18 = r0;
                                                                            arg_14 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2D8, 0x1);
                                                                            arg_10 = [r0 retain];
                                                                            arg_C = _easyPosixSpawn(arg_18, arg_10);
                                                                            [arg_10 release];
                                                                            [arg_18 release];
                                                                            _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_324, arg_328, 0x1, STK-1);
                                                                            r0 = system("su mobile -c uicache");
                                                                            arg_8 = r0;
                                                                            arg_4 = system("killall backboardd");
                                                                            _write_primitive(arg_328, arg_324);
                                                                            objc_storeStrong(&arg_2E8, 0x0);
                                                                            r0 = objc_storeStrong(&arg_308, 0x0);
                                                                    }
                                                            }
                                                    }
                                            }
                                    }
                            }
                            else {
                                    _logToFile("Changing permissions\n", r1, r2, r3, STK-1);
                                    asm{ uxthne.w   r1, lr };
                                    arg_318 = chmod("/bin/tar", r1);
                                    if (arg_318 != 0x0) {
                                            arg_158 = arg_318;
                                            arg_154 = *__error();
                                            r0 = __error();
                                            r0 = *r0;
                                            r0 = strerror(r0);
                                            arg_150 = r0;
                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_158, arg_154, arg_150, STK-1);
                                    }
                                    else {
                                            asm{ uxth       r1, r1 };
                                            arg_318 = chmod("/bin/launchctl", 0x1ff);
                                            if (arg_318 != 0x0) {
                                                    arg_14C = arg_318;
                                                    arg_148 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_144 = r0;
                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_14C, arg_148, arg_144, STK-1);
                                            }
                                            else {
                                                    asm{ uxth       r1, r1 };
                                                    arg_318 = chmod("/Library/LaunchDaemons/dropbear.plist", 0x180);
                                                    if (arg_318 != 0x0) {
                                                            arg_140 = arg_318;
                                                            arg_13C = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_138 = r0;
                                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_140, arg_13C, arg_138, STK-1);
                                                    }
                                                    else {
                                                            arg_134 = 0x0;
                                                            arg_318 = chown("/Library/LaunchDaemons/dropbear.plist", 0x0, arg_134);
                                                            if (arg_318 != 0x0) {
                                                                    arg_130 = arg_318;
                                                                    arg_12C = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_128 = r0;
                                                                    r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_130, arg_12C, arg_128, STK-1);
                                                            }
                                                            else {
                                                                    r0 = *objc_msgSend;
                                                                    arg_124 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_124);
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_30C = @"YLUProgressString";
                                                                    arg_310 = @"Installing Cydia";
                                                                    arg_120 = r0;
                                                                    arg_11C = 0x1;
                                                                    arg_118 = r2;
                                                                    var_0 = arg_11C;
                                                                    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_310, &arg_30C);
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_114 = r0;
                                                                    arg_110 = @"YLUDidReceiveUpdateProgressNotification";
                                                                    arg_10C = r2;
                                                                    var_0 = arg_114;
                                                                    [arg_120 postNotificationName:arg_110 object:0x0 userInfo:STK-1];
                                                                    [arg_114 release];
                                                                    [arg_120 release];
                                                                    r0 = *objc_msgSend;
                                                                    arg_108 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_108);
                                                                    r0 = [r0 retain];
                                                                    r3 = *objc_msgSend;
                                                                    arg_104 = r0;
                                                                    arg_100 = @"Cydia-9.0r4-Raw";
                                                                    arg_FC = @"tar";
                                                                    arg_F8 = r3;
                                                                    arg_308 = [[r0 URLForResource:arg_100 withExtension:arg_FC] retain];
                                                                    [arg_104 release];
                                                                    r0 = *objc_msgSend;
                                                                    arg_F4 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F4);
                                                                    r7 = r7;
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_F0 = r0;
                                                                    arg_EC = @"/Applications/Cydia.app/";
                                                                    r3 = arg_EC;
                                                                    arg_E8 = r2;
                                                                    r2 = r3;
                                                                    COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                    r0 = 0x0;
                                                                    asm{ it         ne };
                                                                    if (!COND) {
                                                                            r0 = 0x1;
                                                                    }
                                                                    r1 = arg_F0;
                                                                    arg_E4 = r0 ^ 0xffffffff;
                                                                    [r1 release];
                                                                    if ((arg_E4 & 0x1) != 0x0) {
                                                                            _logToFile("Didn't find Cydia.app (so we'll assume bearded old bootstrap isn't extracted, we will extract it)\n", r1, r2, r3, STK-1);
                                                                            arg_E0 = @"/bin/tar";
                                                                            r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_E0);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2F4 = @"-xvf";
                                                                            arg_DC = r0;
                                                                            arg_D8 = r1;
                                                                            r0 = loc_63a52(arg_308, @selector(path), arg_D8);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2F8 = r0;
                                                                            arg_2FC = @"-C";
                                                                            arg_300 = @"/";
                                                                            arg_304 = @"--preserve-permissions";
                                                                            arg_D4 = r0;
                                                                            arg_D0 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2F4, 0x5);
                                                                            r7 = r7;
                                                                            arg_CC = [r0 retain];
                                                                            arg_318 = _easyPosixSpawn(arg_DC, arg_CC);
                                                                            [arg_CC release];
                                                                            [arg_D4 release];
                                                                            [arg_DC release];
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_C8 = arg_318;
                                                                                    arg_C4 = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_C0 = r0;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C8, arg_C4, arg_C0, STK-1);
                                                                            }
                                                                    }
                                                                    r1 = *objc_msgSend;
                                                                    arg_BC = @"/usr/bin/killall";
                                                                    arg_B8 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_BC, arg_B8);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2EC = @"-SIGSTOP";
                                                                    arg_2F0 = @"cfprefsd";
                                                                    arg_B4 = r0;
                                                                    arg_B0 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2EC, 0x2);
                                                                    r7 = r7;
                                                                    arg_AC = [r0 retain];
                                                                    arg_A8 = _easyPosixSpawn(arg_B4, arg_AC);
                                                                    [arg_AC release];
                                                                    [arg_B4 release];
                                                                    if (arg_318 != 0x0) {
                                                                            arg_A4 = arg_318;
                                                                            arg_A0 = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_9C = r0;
                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A4, arg_A0, arg_9C, STK-1);
                                                                    }
                                                                    r0 = *objc_msgSend;
                                                                    arg_98 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_98);
                                                                    r2 = *objc_msgSend;
                                                                    arg_94 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                    arg_90 = r2;
                                                                    r0 = [r0 initWithContentsOfFile:arg_94];
                                                                    r2 = *objc_msgSend;
                                                                    arg_2E8 = r0;
                                                                    arg_8C = arg_2E8;
                                                                    arg_88 = 0x1;
                                                                    arg_84 = r2;
                                                                    r0 = [NSNumber numberWithBool:sign_extend_32(arg_88)];
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_80 = r0;
                                                                    arg_7C = @"SBShowNonDefaultSystemApps";
                                                                    arg_78 = r2;
                                                                    [arg_8C setObject:r0 forKey:arg_7C];
                                                                    [arg_80 release];
                                                                    r2 = *objc_msgSend;
                                                                    arg_74 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                    arg_70 = 0x1;
                                                                    arg_6C = r2;
                                                                    r0 = [arg_2E8 writeToFile:arg_74 atomically:sign_extend_32(arg_70)];
                                                                    r2 = *objc_msgSend;
                                                                    arg_68 = r0;
                                                                    arg_64 = @"/usr/bin/killall";
                                                                    arg_60 = r2;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_64, arg_64);
                                                                    r0 = [r0 retain];
                                                                    r3 = 0x2;
                                                                    r1 = *objc_msgSend;
                                                                    r2 = &arg_2E0;
                                                                    arg_2E0 = @"-9";
                                                                    arg_2E4 = @"cfprefsd";
                                                                    arg_5C = r0;
                                                                    arg_58 = r1;
                                                                    r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), r2, r3);
                                                                    r7 = r7;
                                                                    arg_54 = [r0 retain];
                                                                    r1 = arg_54;
                                                                    arg_318 = _easyPosixSpawn(arg_5C, r1);
                                                                    [arg_54 release];
                                                                    [arg_5C release];
                                                                    if (arg_318 != 0x0) {
                                                                            arg_50 = arg_318;
                                                                            arg_4C = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_48 = r0;
                                                                            r1 = arg_50;
                                                                            r2 = arg_4C;
                                                                            r3 = arg_48;
                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", r1, r2, r3, STK-1);
                                                                    }
                                                                    _logToFile("Touching /.bearded_old_man_no_stash\n", r1, r2, r3, STK-1);
                                                                    arg_44 = @"/bin/touch";
                                                                    r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_44);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2DC = @"/.cydia_no_stash";
                                                                    arg_40 = r0;
                                                                    arg_3C = r1;
                                                                    arg_38 = [_OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2DC, 0x1) retain];
                                                                    arg_318 = _easyPosixSpawn(arg_40, arg_38);
                                                                    [arg_38 release];
                                                                    [arg_40 release];
                                                                    r0 = *objc_msgSend;
                                                                    arg_34 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_34);
                                                                    r7 = r7;
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_30 = r0;
                                                                    arg_2C = @"/.cydia_no_stash";
                                                                    r3 = arg_2C;
                                                                    arg_28 = r2;
                                                                    r2 = r3;
                                                                    COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                    r0 = 0x0;
                                                                    asm{  };
                                                                    if (!COND) {
                                                                            r0 = 0x1;
                                                                    }
                                                                    r1 = arg_30;
                                                                    arg_24 = r0 ^ 0xffffffff;
                                                                    [r1 release];
                                                                    if ((arg_24 & 0x1) != 0x0) {
                                                                            _logToFile("WARNING WARNING WARNING\n", r1, r2, r3, STK-1);
                                                                            _logToFile("Even though we tried creating cydia_no_stash it looks like it's not there. So don't open the app by bearded old man (aka saurik)!\n", r1, r2, r3, STK-1);
                                                                    }
                                                                    r1 = *objc_msgSend;
                                                                    arg_20 = @"/bin/touch";
                                                                    arg_1C = r1;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_20, arg_1C);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2D8 = @"/.installed_home_depot";
                                                                    arg_18 = r0;
                                                                    arg_14 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2D8, 0x1);
                                                                    arg_10 = [r0 retain];
                                                                    arg_C = _easyPosixSpawn(arg_18, arg_10);
                                                                    [arg_10 release];
                                                                    [arg_18 release];
                                                                    _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_324, arg_328, 0x1, STK-1);
                                                                    r0 = system("su mobile -c uicache");
                                                                    arg_8 = r0;
                                                                    arg_4 = system("killall backboardd");
                                                                    _write_primitive(arg_328, arg_324);
                                                                    objc_storeStrong(&arg_2E8, 0x0);
                                                                    r0 = objc_storeStrong(&arg_308, 0x0);
                                                            }
                                                    }
                                            }
                                    }
                            }
                    }
            }
    }
    else {
            r0 = *objc_msgSend;
            arg_234 = r0;
            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_234);
            r7 = r7;
            r0 = [r0 retain];
            r2 = *objc_msgSend;
            arg_230 = r0;
            arg_22C = @"/bin/launchctl";
            arg_228 = r2;
            COND = sign_extend_32(("fileExistsAtPath:")(r0, @selector(fileExistsAtPath:), arg_22C, arg_22C)) == 0x0;
            r0 = 0x0;
            asm{  };
            if (!COND) {
                    r0 = 0x1;
            }
            arg_224 = r0 ^ 0xffffffff;
            [arg_230 release];
            if ((arg_224 & 0x1) != 0x0) {
                    r0 = *objc_msgSend;
                    arg_220 = r0;
                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_220);
                    r0 = [r0 retain];
                    arg_21C = r0;
                    arg_218 = @"launchctl";
                    arg_214 = @"";
                    r0 = _objc_msgSend(r0, @selector(URLForResource:withExtension:), arg_218, arg_214);
                    r0 = [r0 retain];
                    r1 = *objc_msgSend;
                    r3 = r0;
                    arg_210 = r0;
                    arg_20C = r1;
                    r0 = loc_63a52(r3, @selector(path), arg_20C, r3);
                    r0 = [r0 retain];
                    arg_208 = r0;
                    objc_retainAutorelease(r0);
                    r1 = *objc_msgSend;
                    arg_204 = r1;
                    r0 = ("UTF8String")();
                    arg_200 = r0;
                    _logToFile("We will try copying %s to %s\n", arg_200, "/bin/launchctl", r3, STK-1);
                    [arg_208 release];
                    [arg_210 release];
                    [arg_21C release];
                    r0 = *objc_msgSend;
                    arg_1FC = r0;
                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_1FC);
                    r0 = [r0 retain];
                    r3 = *objc_msgSend;
                    arg_1F8 = r0;
                    arg_1F4 = @"launchctl";
                    arg_1F0 = @"";
                    arg_1EC = r3;
                    r0 = [r0 URLForResource:arg_1F4 withExtension:arg_1F0];
                    r0 = [r0 retain];
                    r1 = *objc_msgSend;
                    arg_1E8 = r0;
                    arg_1E4 = r1;
                    r0 = loc_63a52(r0, @selector(path), arg_1E4, r0);
                    r7 = r7;
                    r0 = [r0 retain];
                    arg_1E0 = r0;
                    objc_retainAutorelease(r0);
                    r1 = *objc_msgSend;
                    arg_1DC = r1;
                    r0 = ("UTF8String")();
                    arg_318 = copyfile(r0, "/bin/launchctl", 0x0, 0xf);
                    [arg_1E0 release];
                    [arg_1E8 release];
                    [arg_1F8 release];
                    if (arg_318 != 0x0) {
                            arg_1D8 = arg_318;
                            arg_1D4 = *__error();
                            r0 = __error();
                            r0 = *r0;
                            r0 = strerror(r0);
                            arg_1D0 = r0;
                            r0 = _logToFile("copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_1D8, arg_1D4, arg_1D0, STK-1);
                    }
                    else {
                            asm{ uxthne     r1, r1 };
                            arg_318 = mkdir("/Library/LaunchDaemons", 0x1ed);
                            if (arg_318 != 0x0) {
                                    arg_1CC = arg_318;
                                    arg_1C8 = *__error();
                                    r0 = __error();
                                    r0 = *r0;
                                    r0 = strerror(r0);
                                    arg_1C4 = r0;
                                    _logToFile("mkdir returned nonzero value: %d, errno: %d, strerror: %s\n", arg_1CC, arg_1C8, arg_1C4, STK-1);
                            }
                            r0 = *objc_msgSend;
                            arg_1C0 = r0;
                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_1C0);
                            r7 = r7;
                            r0 = [r0 retain];
                            r2 = *objc_msgSend;
                            arg_1BC = r0;
                            arg_1B8 = @"/Library/LaunchDaemons/dropbear.plist";
                            r3 = arg_1B8;
                            arg_1B4 = r2;
                            r2 = r3;
                            COND = sign_extend_32(("fileExistsAtPath:")(r0, @selector(fileExistsAtPath:), r2, r3)) == 0x0;
                            r0 = 0x0;
                            asm{ it         ne };
                            if (!COND) {
                                    r0 = 0x1;
                            }
                            r1 = arg_1BC;
                            arg_1B0 = r0 ^ 0xffffffff;
                            [r1 release];
                            if ((arg_1B0 & 0x1) != 0x0) {
                                    r0 = *objc_msgSend;
                                    arg_1AC = r0;
                                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_1AC);
                                    r0 = [r0 retain];
                                    arg_1A8 = r0;
                                    arg_1A4 = @"dropbear";
                                    arg_1A0 = @"plist";
                                    r0 = _objc_msgSend(r0, @selector(URLForResource:withExtension:), arg_1A4, arg_1A0);
                                    r0 = [r0 retain];
                                    r1 = *objc_msgSend;
                                    r3 = r0;
                                    arg_19C = r0;
                                    arg_198 = r1;
                                    r0 = loc_63a52(r3, @selector(path), arg_198, r3);
                                    r0 = [r0 retain];
                                    arg_194 = r0;
                                    objc_retainAutorelease(r0);
                                    r1 = *objc_msgSend;
                                    arg_190 = r1;
                                    r0 = ("UTF8String")();
                                    arg_18C = r0;
                                    _logToFile("We will try copying %s to %s\n", arg_18C, "/Library/LaunchDaemons/dropbear.plist", r3, STK-1);
                                    [arg_194 release];
                                    [arg_19C release];
                                    [arg_1A8 release];
                                    r0 = *objc_msgSend;
                                    arg_188 = r0;
                                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_188);
                                    r0 = [r0 retain];
                                    r3 = *objc_msgSend;
                                    arg_184 = r0;
                                    arg_180 = @"dropbear";
                                    arg_17C = @"plist";
                                    arg_178 = r3;
                                    r0 = [r0 URLForResource:arg_180 withExtension:arg_17C];
                                    r0 = [r0 retain];
                                    r1 = *objc_msgSend;
                                    arg_174 = r0;
                                    arg_170 = r1;
                                    r0 = loc_63a52(r0, @selector(path), arg_170, r0);
                                    r7 = r7;
                                    r0 = [r0 retain];
                                    arg_16C = r0;
                                    objc_retainAutorelease(r0);
                                    r1 = *objc_msgSend;
                                    arg_168 = r1;
                                    r0 = ("UTF8String")();
                                    r1 = "/Library/LaunchDaemons/dropbear.plist";
                                    r2 = 0x0;
                                    r3 = 0xf;
                                    arg_318 = copyfile(r0, r1, r2, r3);
                                    [arg_16C release];
                                    [arg_174 release];
                                    [arg_184 release];
                                    if (arg_318 != 0x0) {
                                            arg_164 = arg_318;
                                            arg_160 = *__error();
                                            r0 = __error();
                                            r0 = *r0;
                                            r0 = strerror(r0);
                                            arg_15C = r0;
                                            r0 = _logToFile("Copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_164, arg_160, arg_15C, STK-1);
                                    }
                                    else {
                                            _logToFile("Changing permissions\n", r1, r2, r3, STK-1);
                                            asm{ uxthne.w   r1, lr };
                                            arg_318 = chmod("/bin/tar", r1);
                                            if (arg_318 != 0x0) {
                                                    arg_158 = arg_318;
                                                    arg_154 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_150 = r0;
                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_158, arg_154, arg_150, STK-1);
                                            }
                                            else {
                                                    asm{ uxth       r1, r1 };
                                                    arg_318 = chmod("/bin/launchctl", 0x1ff);
                                                    if (arg_318 != 0x0) {
                                                            arg_14C = arg_318;
                                                            arg_148 = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_144 = r0;
                                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_14C, arg_148, arg_144, STK-1);
                                                    }
                                                    else {
                                                            asm{ uxth       r1, r1 };
                                                            arg_318 = chmod("/Library/LaunchDaemons/dropbear.plist", 0x180);
                                                            if (arg_318 != 0x0) {
                                                                    arg_140 = arg_318;
                                                                    arg_13C = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_138 = r0;
                                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_140, arg_13C, arg_138, STK-1);
                                                            }
                                                            else {
                                                                    arg_134 = 0x0;
                                                                    arg_318 = chown("/Library/LaunchDaemons/dropbear.plist", 0x0, arg_134);
                                                                    if (arg_318 != 0x0) {
                                                                            arg_130 = arg_318;
                                                                            arg_12C = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_128 = r0;
                                                                            r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_130, arg_12C, arg_128, STK-1);
                                                                    }
                                                                    else {
                                                                            r0 = *objc_msgSend;
                                                                            arg_124 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_124);
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_30C = @"YLUProgressString";
                                                                            arg_310 = @"Installing Cydia";
                                                                            arg_120 = r0;
                                                                            arg_11C = 0x1;
                                                                            arg_118 = r2;
                                                                            var_0 = arg_11C;
                                                                            r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_310, &arg_30C);
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_114 = r0;
                                                                            arg_110 = @"YLUDidReceiveUpdateProgressNotification";
                                                                            arg_10C = r2;
                                                                            var_0 = arg_114;
                                                                            [arg_120 postNotificationName:arg_110 object:0x0 userInfo:STK-1];
                                                                            [arg_114 release];
                                                                            [arg_120 release];
                                                                            r0 = *objc_msgSend;
                                                                            arg_108 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_108);
                                                                            r0 = [r0 retain];
                                                                            r3 = *objc_msgSend;
                                                                            arg_104 = r0;
                                                                            arg_100 = @"Cydia-9.0r4-Raw";
                                                                            arg_FC = @"tar";
                                                                            arg_F8 = r3;
                                                                            arg_308 = [[r0 URLForResource:arg_100 withExtension:arg_FC] retain];
                                                                            [arg_104 release];
                                                                            r0 = *objc_msgSend;
                                                                            arg_F4 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F4);
                                                                            r7 = r7;
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_F0 = r0;
                                                                            arg_EC = @"/Applications/Cydia.app/";
                                                                            r3 = arg_EC;
                                                                            arg_E8 = r2;
                                                                            r2 = r3;
                                                                            COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                            r0 = 0x0;
                                                                            asm{ it         ne };
                                                                            if (!COND) {
                                                                                    r0 = 0x1;
                                                                            }
                                                                            r1 = arg_F0;
                                                                            arg_E4 = r0 ^ 0xffffffff;
                                                                            [r1 release];
                                                                            if ((arg_E4 & 0x1) != 0x0) {
                                                                                    _logToFile("Didn't find Cydia.app (so we'll assume bearded old bootstrap isn't extracted, we will extract it)\n", r1, r2, r3, STK-1);
                                                                                    arg_E0 = @"/bin/tar";
                                                                                    r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_E0);
                                                                                    r0 = [r0 retain];
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_2F4 = @"-xvf";
                                                                                    arg_DC = r0;
                                                                                    arg_D8 = r1;
                                                                                    r0 = loc_63a52(arg_308, @selector(path), arg_D8);
                                                                                    r0 = [r0 retain];
                                                                                    r1 = *objc_msgSend;
                                                                                    arg_2F8 = r0;
                                                                                    arg_2FC = @"-C";
                                                                                    arg_300 = @"/";
                                                                                    arg_304 = @"--preserve-permissions";
                                                                                    arg_D4 = r0;
                                                                                    arg_D0 = r1;
                                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2F4, 0x5);
                                                                                    r7 = r7;
                                                                                    arg_CC = [r0 retain];
                                                                                    arg_318 = _easyPosixSpawn(arg_DC, arg_CC);
                                                                                    [arg_CC release];
                                                                                    [arg_D4 release];
                                                                                    [arg_DC release];
                                                                                    if (arg_318 != 0x0) {
                                                                                            arg_C8 = arg_318;
                                                                                            arg_C4 = *__error();
                                                                                            r0 = __error();
                                                                                            r0 = *r0;
                                                                                            r0 = strerror(r0);
                                                                                            arg_C0 = r0;
                                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C8, arg_C4, arg_C0, STK-1);
                                                                                    }
                                                                            }
                                                                            r1 = *objc_msgSend;
                                                                            arg_BC = @"/usr/bin/killall";
                                                                            arg_B8 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_BC, arg_B8);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2EC = @"-SIGSTOP";
                                                                            arg_2F0 = @"cfprefsd";
                                                                            arg_B4 = r0;
                                                                            arg_B0 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2EC, 0x2);
                                                                            r7 = r7;
                                                                            arg_AC = [r0 retain];
                                                                            arg_A8 = _easyPosixSpawn(arg_B4, arg_AC);
                                                                            [arg_AC release];
                                                                            [arg_B4 release];
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_A4 = arg_318;
                                                                                    arg_A0 = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_9C = r0;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A4, arg_A0, arg_9C, STK-1);
                                                                            }
                                                                            r0 = *objc_msgSend;
                                                                            arg_98 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_98);
                                                                            r2 = *objc_msgSend;
                                                                            arg_94 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                            arg_90 = r2;
                                                                            r0 = [r0 initWithContentsOfFile:arg_94];
                                                                            r2 = *objc_msgSend;
                                                                            arg_2E8 = r0;
                                                                            arg_8C = arg_2E8;
                                                                            arg_88 = 0x1;
                                                                            arg_84 = r2;
                                                                            r0 = [NSNumber numberWithBool:sign_extend_32(arg_88)];
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_80 = r0;
                                                                            arg_7C = @"SBShowNonDefaultSystemApps";
                                                                            arg_78 = r2;
                                                                            [arg_8C setObject:r0 forKey:arg_7C];
                                                                            [arg_80 release];
                                                                            r2 = *objc_msgSend;
                                                                            arg_74 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                            arg_70 = 0x1;
                                                                            arg_6C = r2;
                                                                            r0 = [arg_2E8 writeToFile:arg_74 atomically:sign_extend_32(arg_70)];
                                                                            r2 = *objc_msgSend;
                                                                            arg_68 = r0;
                                                                            arg_64 = @"/usr/bin/killall";
                                                                            arg_60 = r2;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_64, arg_64);
                                                                            r0 = [r0 retain];
                                                                            r3 = 0x2;
                                                                            r1 = *objc_msgSend;
                                                                            r2 = &arg_2E0;
                                                                            arg_2E0 = @"-9";
                                                                            arg_2E4 = @"cfprefsd";
                                                                            arg_5C = r0;
                                                                            arg_58 = r1;
                                                                            r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), r2, r3);
                                                                            r7 = r7;
                                                                            arg_54 = [r0 retain];
                                                                            r1 = arg_54;
                                                                            arg_318 = _easyPosixSpawn(arg_5C, r1);
                                                                            [arg_54 release];
                                                                            [arg_5C release];
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_50 = arg_318;
                                                                                    arg_4C = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_48 = r0;
                                                                                    r1 = arg_50;
                                                                                    r2 = arg_4C;
                                                                                    r3 = arg_48;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", r1, r2, r3, STK-1);
                                                                            }
                                                                            _logToFile("Touching /.bearded_old_man_no_stash\n", r1, r2, r3, STK-1);
                                                                            arg_44 = @"/bin/touch";
                                                                            r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_44);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2DC = @"/.cydia_no_stash";
                                                                            arg_40 = r0;
                                                                            arg_3C = r1;
                                                                            arg_38 = [_OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2DC, 0x1) retain];
                                                                            arg_318 = _easyPosixSpawn(arg_40, arg_38);
                                                                            [arg_38 release];
                                                                            [arg_40 release];
                                                                            r0 = *objc_msgSend;
                                                                            arg_34 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_34);
                                                                            r7 = r7;
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_30 = r0;
                                                                            arg_2C = @"/.cydia_no_stash";
                                                                            r3 = arg_2C;
                                                                            arg_28 = r2;
                                                                            r2 = r3;
                                                                            COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                            r0 = 0x0;
                                                                            asm{  };
                                                                            if (!COND) {
                                                                                    r0 = 0x1;
                                                                            }
                                                                            r1 = arg_30;
                                                                            arg_24 = r0 ^ 0xffffffff;
                                                                            [r1 release];
                                                                            if ((arg_24 & 0x1) != 0x0) {
                                                                                    _logToFile("WARNING WARNING WARNING\n", r1, r2, r3, STK-1);
                                                                                    _logToFile("Even though we tried creating cydia_no_stash it looks like it's not there. So don't open the app by bearded old man (aka saurik)!\n", r1, r2, r3, STK-1);
                                                                            }
                                                                            r1 = *objc_msgSend;
                                                                            arg_20 = @"/bin/touch";
                                                                            arg_1C = r1;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_20, arg_1C);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2D8 = @"/.installed_home_depot";
                                                                            arg_18 = r0;
                                                                            arg_14 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2D8, 0x1);
                                                                            arg_10 = [r0 retain];
                                                                            arg_C = _easyPosixSpawn(arg_18, arg_10);
                                                                            [arg_10 release];
                                                                            [arg_18 release];
                                                                            _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_324, arg_328, 0x1, STK-1);
                                                                            r0 = system("su mobile -c uicache");
                                                                            arg_8 = r0;
                                                                            arg_4 = system("killall backboardd");
                                                                            _write_primitive(arg_328, arg_324);
                                                                            objc_storeStrong(&arg_2E8, 0x0);
                                                                            r0 = objc_storeStrong(&arg_308, 0x0);
                                                                    }
                                                            }
                                                    }
                                            }
                                    }
                            }
                            else {
                                    _logToFile("Changing permissions\n", r1, r2, r3, STK-1);
                                    asm{ uxthne.w   r1, lr };
                                    arg_318 = chmod("/bin/tar", r1);
                                    if (arg_318 != 0x0) {
                                            arg_158 = arg_318;
                                            arg_154 = *__error();
                                            r0 = __error();
                                            r0 = *r0;
                                            r0 = strerror(r0);
                                            arg_150 = r0;
                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_158, arg_154, arg_150, STK-1);
                                    }
                                    else {
                                            asm{ uxth       r1, r1 };
                                            arg_318 = chmod("/bin/launchctl", 0x1ff);
                                            if (arg_318 != 0x0) {
                                                    arg_14C = arg_318;
                                                    arg_148 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_144 = r0;
                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_14C, arg_148, arg_144, STK-1);
                                            }
                                            else {
                                                    asm{ uxth       r1, r1 };
                                                    arg_318 = chmod("/Library/LaunchDaemons/dropbear.plist", 0x180);
                                                    if (arg_318 != 0x0) {
                                                            arg_140 = arg_318;
                                                            arg_13C = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_138 = r0;
                                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_140, arg_13C, arg_138, STK-1);
                                                    }
                                                    else {
                                                            arg_134 = 0x0;
                                                            arg_318 = chown("/Library/LaunchDaemons/dropbear.plist", 0x0, arg_134);
                                                            if (arg_318 != 0x0) {
                                                                    arg_130 = arg_318;
                                                                    arg_12C = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_128 = r0;
                                                                    r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_130, arg_12C, arg_128, STK-1);
                                                            }
                                                            else {
                                                                    r0 = *objc_msgSend;
                                                                    arg_124 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_124);
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_30C = @"YLUProgressString";
                                                                    arg_310 = @"Installing Cydia";
                                                                    arg_120 = r0;
                                                                    arg_11C = 0x1;
                                                                    arg_118 = r2;
                                                                    var_0 = arg_11C;
                                                                    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_310, &arg_30C);
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_114 = r0;
                                                                    arg_110 = @"YLUDidReceiveUpdateProgressNotification";
                                                                    arg_10C = r2;
                                                                    var_0 = arg_114;
                                                                    [arg_120 postNotificationName:arg_110 object:0x0 userInfo:STK-1];
                                                                    [arg_114 release];
                                                                    [arg_120 release];
                                                                    r0 = *objc_msgSend;
                                                                    arg_108 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_108);
                                                                    r0 = [r0 retain];
                                                                    r3 = *objc_msgSend;
                                                                    arg_104 = r0;
                                                                    arg_100 = @"Cydia-9.0r4-Raw";
                                                                    arg_FC = @"tar";
                                                                    arg_F8 = r3;
                                                                    arg_308 = [[r0 URLForResource:arg_100 withExtension:arg_FC] retain];
                                                                    [arg_104 release];
                                                                    r0 = *objc_msgSend;
                                                                    arg_F4 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F4);
                                                                    r7 = r7;
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_F0 = r0;
                                                                    arg_EC = @"/Applications/Cydia.app/";
                                                                    r3 = arg_EC;
                                                                    arg_E8 = r2;
                                                                    r2 = r3;
                                                                    COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                    r0 = 0x0;
                                                                    asm{ it         ne };
                                                                    if (!COND) {
                                                                            r0 = 0x1;
                                                                    }
                                                                    r1 = arg_F0;
                                                                    arg_E4 = r0 ^ 0xffffffff;
                                                                    [r1 release];
                                                                    if ((arg_E4 & 0x1) != 0x0) {
                                                                            _logToFile("Didn't find Cydia.app (so we'll assume bearded old bootstrap isn't extracted, we will extract it)\n", r1, r2, r3, STK-1);
                                                                            arg_E0 = @"/bin/tar";
                                                                            r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_E0);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2F4 = @"-xvf";
                                                                            arg_DC = r0;
                                                                            arg_D8 = r1;
                                                                            r0 = loc_63a52(arg_308, @selector(path), arg_D8);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2F8 = r0;
                                                                            arg_2FC = @"-C";
                                                                            arg_300 = @"/";
                                                                            arg_304 = @"--preserve-permissions";
                                                                            arg_D4 = r0;
                                                                            arg_D0 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2F4, 0x5);
                                                                            r7 = r7;
                                                                            arg_CC = [r0 retain];
                                                                            arg_318 = _easyPosixSpawn(arg_DC, arg_CC);
                                                                            [arg_CC release];
                                                                            [arg_D4 release];
                                                                            [arg_DC release];
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_C8 = arg_318;
                                                                                    arg_C4 = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_C0 = r0;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C8, arg_C4, arg_C0, STK-1);
                                                                            }
                                                                    }
                                                                    r1 = *objc_msgSend;
                                                                    arg_BC = @"/usr/bin/killall";
                                                                    arg_B8 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_BC, arg_B8);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2EC = @"-SIGSTOP";
                                                                    arg_2F0 = @"cfprefsd";
                                                                    arg_B4 = r0;
                                                                    arg_B0 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2EC, 0x2);
                                                                    r7 = r7;
                                                                    arg_AC = [r0 retain];
                                                                    arg_A8 = _easyPosixSpawn(arg_B4, arg_AC);
                                                                    [arg_AC release];
                                                                    [arg_B4 release];
                                                                    if (arg_318 != 0x0) {
                                                                            arg_A4 = arg_318;
                                                                            arg_A0 = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_9C = r0;
                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A4, arg_A0, arg_9C, STK-1);
                                                                    }
                                                                    r0 = *objc_msgSend;
                                                                    arg_98 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_98);
                                                                    r2 = *objc_msgSend;
                                                                    arg_94 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                    arg_90 = r2;
                                                                    r0 = [r0 initWithContentsOfFile:arg_94];
                                                                    r2 = *objc_msgSend;
                                                                    arg_2E8 = r0;
                                                                    arg_8C = arg_2E8;
                                                                    arg_88 = 0x1;
                                                                    arg_84 = r2;
                                                                    r0 = [NSNumber numberWithBool:sign_extend_32(arg_88)];
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_80 = r0;
                                                                    arg_7C = @"SBShowNonDefaultSystemApps";
                                                                    arg_78 = r2;
                                                                    [arg_8C setObject:r0 forKey:arg_7C];
                                                                    [arg_80 release];
                                                                    r2 = *objc_msgSend;
                                                                    arg_74 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                    arg_70 = 0x1;
                                                                    arg_6C = r2;
                                                                    r0 = [arg_2E8 writeToFile:arg_74 atomically:sign_extend_32(arg_70)];
                                                                    r2 = *objc_msgSend;
                                                                    arg_68 = r0;
                                                                    arg_64 = @"/usr/bin/killall";
                                                                    arg_60 = r2;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_64, arg_64);
                                                                    r0 = [r0 retain];
                                                                    r3 = 0x2;
                                                                    r1 = *objc_msgSend;
                                                                    r2 = &arg_2E0;
                                                                    arg_2E0 = @"-9";
                                                                    arg_2E4 = @"cfprefsd";
                                                                    arg_5C = r0;
                                                                    arg_58 = r1;
                                                                    r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), r2, r3);
                                                                    r7 = r7;
                                                                    arg_54 = [r0 retain];
                                                                    r1 = arg_54;
                                                                    arg_318 = _easyPosixSpawn(arg_5C, r1);
                                                                    [arg_54 release];
                                                                    [arg_5C release];
                                                                    if (arg_318 != 0x0) {
                                                                            arg_50 = arg_318;
                                                                            arg_4C = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_48 = r0;
                                                                            r1 = arg_50;
                                                                            r2 = arg_4C;
                                                                            r3 = arg_48;
                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", r1, r2, r3, STK-1);
                                                                    }
                                                                    _logToFile("Touching /.bearded_old_man_no_stash\n", r1, r2, r3, STK-1);
                                                                    arg_44 = @"/bin/touch";
                                                                    r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_44);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2DC = @"/.cydia_no_stash";
                                                                    arg_40 = r0;
                                                                    arg_3C = r1;
                                                                    arg_38 = [_OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2DC, 0x1) retain];
                                                                    arg_318 = _easyPosixSpawn(arg_40, arg_38);
                                                                    [arg_38 release];
                                                                    [arg_40 release];
                                                                    r0 = *objc_msgSend;
                                                                    arg_34 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_34);
                                                                    r7 = r7;
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_30 = r0;
                                                                    arg_2C = @"/.cydia_no_stash";
                                                                    r3 = arg_2C;
                                                                    arg_28 = r2;
                                                                    r2 = r3;
                                                                    COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                    r0 = 0x0;
                                                                    asm{  };
                                                                    if (!COND) {
                                                                            r0 = 0x1;
                                                                    }
                                                                    r1 = arg_30;
                                                                    arg_24 = r0 ^ 0xffffffff;
                                                                    [r1 release];
                                                                    if ((arg_24 & 0x1) != 0x0) {
                                                                            _logToFile("WARNING WARNING WARNING\n", r1, r2, r3, STK-1);
                                                                            _logToFile("Even though we tried creating cydia_no_stash it looks like it's not there. So don't open the app by bearded old man (aka saurik)!\n", r1, r2, r3, STK-1);
                                                                    }
                                                                    r1 = *objc_msgSend;
                                                                    arg_20 = @"/bin/touch";
                                                                    arg_1C = r1;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_20, arg_1C);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2D8 = @"/.installed_home_depot";
                                                                    arg_18 = r0;
                                                                    arg_14 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2D8, 0x1);
                                                                    arg_10 = [r0 retain];
                                                                    arg_C = _easyPosixSpawn(arg_18, arg_10);
                                                                    [arg_10 release];
                                                                    [arg_18 release];
                                                                    _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_324, arg_328, 0x1, STK-1);
                                                                    r0 = system("su mobile -c uicache");
                                                                    arg_8 = r0;
                                                                    arg_4 = system("killall backboardd");
                                                                    _write_primitive(arg_328, arg_324);
                                                                    objc_storeStrong(&arg_2E8, 0x0);
                                                                    r0 = objc_storeStrong(&arg_308, 0x0);
                                                            }
                                                    }
                                            }
                                    }
                            }
                    }
            }
            else {
                    asm{ uxthne     r1, r1 };
                    arg_318 = mkdir("/Library/LaunchDaemons", 0x1ed);
                    if (arg_318 != 0x0) {
                            arg_1CC = arg_318;
                            arg_1C8 = *__error();
                            r0 = __error();
                            r0 = *r0;
                            r0 = strerror(r0);
                            arg_1C4 = r0;
                            _logToFile("mkdir returned nonzero value: %d, errno: %d, strerror: %s\n", arg_1CC, arg_1C8, arg_1C4, STK-1);
                    }
                    r0 = *objc_msgSend;
                    arg_1C0 = r0;
                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_1C0);
                    r7 = r7;
                    r0 = [r0 retain];
                    r2 = *objc_msgSend;
                    arg_1BC = r0;
                    arg_1B8 = @"/Library/LaunchDaemons/dropbear.plist";
                    r3 = arg_1B8;
                    arg_1B4 = r2;
                    r2 = r3;
                    COND = sign_extend_32(("fileExistsAtPath:")(r0, @selector(fileExistsAtPath:), r2, r3)) == 0x0;
                    r0 = 0x0;
                    asm{ it         ne };
                    if (!COND) {
                            r0 = 0x1;
                    }
                    r1 = arg_1BC;
                    arg_1B0 = r0 ^ 0xffffffff;
                    [r1 release];
                    if ((arg_1B0 & 0x1) != 0x0) {
                            r0 = *objc_msgSend;
                            arg_1AC = r0;
                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_1AC);
                            r0 = [r0 retain];
                            arg_1A8 = r0;
                            arg_1A4 = @"dropbear";
                            arg_1A0 = @"plist";
                            r0 = _objc_msgSend(r0, @selector(URLForResource:withExtension:), arg_1A4, arg_1A0);
                            r0 = [r0 retain];
                            r1 = *objc_msgSend;
                            r3 = r0;
                            arg_19C = r0;
                            arg_198 = r1;
                            r0 = loc_63a52(r3, @selector(path), arg_198, r3);
                            r0 = [r0 retain];
                            arg_194 = r0;
                            objc_retainAutorelease(r0);
                            r1 = *objc_msgSend;
                            arg_190 = r1;
                            r0 = ("UTF8String")();
                            arg_18C = r0;
                            _logToFile("We will try copying %s to %s\n", arg_18C, "/Library/LaunchDaemons/dropbear.plist", r3, STK-1);
                            [arg_194 release];
                            [arg_19C release];
                            [arg_1A8 release];
                            r0 = *objc_msgSend;
                            arg_188 = r0;
                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_188);
                            r0 = [r0 retain];
                            r3 = *objc_msgSend;
                            arg_184 = r0;
                            arg_180 = @"dropbear";
                            arg_17C = @"plist";
                            arg_178 = r3;
                            r0 = [r0 URLForResource:arg_180 withExtension:arg_17C];
                            r0 = [r0 retain];
                            r1 = *objc_msgSend;
                            arg_174 = r0;
                            arg_170 = r1;
                            r0 = loc_63a52(r0, @selector(path), arg_170, r0);
                            r7 = r7;
                            r0 = [r0 retain];
                            arg_16C = r0;
                            objc_retainAutorelease(r0);
                            r1 = *objc_msgSend;
                            arg_168 = r1;
                            r0 = ("UTF8String")();
                            r1 = "/Library/LaunchDaemons/dropbear.plist";
                            r2 = 0x0;
                            r3 = 0xf;
                            arg_318 = copyfile(r0, r1, r2, r3);
                            [arg_16C release];
                            [arg_174 release];
                            [arg_184 release];
                            if (arg_318 != 0x0) {
                                    arg_164 = arg_318;
                                    arg_160 = *__error();
                                    r0 = __error();
                                    r0 = *r0;
                                    r0 = strerror(r0);
                                    arg_15C = r0;
                                    r0 = _logToFile("Copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_164, arg_160, arg_15C, STK-1);
                            }
                            else {
                                    _logToFile("Changing permissions\n", r1, r2, r3, STK-1);
                                    asm{ uxthne.w   r1, lr };
                                    arg_318 = chmod("/bin/tar", r1);
                                    if (arg_318 != 0x0) {
                                            arg_158 = arg_318;
                                            arg_154 = *__error();
                                            r0 = __error();
                                            r0 = *r0;
                                            r0 = strerror(r0);
                                            arg_150 = r0;
                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_158, arg_154, arg_150, STK-1);
                                    }
                                    else {
                                            asm{ uxth       r1, r1 };
                                            arg_318 = chmod("/bin/launchctl", 0x1ff);
                                            if (arg_318 != 0x0) {
                                                    arg_14C = arg_318;
                                                    arg_148 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_144 = r0;
                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_14C, arg_148, arg_144, STK-1);
                                            }
                                            else {
                                                    asm{ uxth       r1, r1 };
                                                    arg_318 = chmod("/Library/LaunchDaemons/dropbear.plist", 0x180);
                                                    if (arg_318 != 0x0) {
                                                            arg_140 = arg_318;
                                                            arg_13C = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_138 = r0;
                                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_140, arg_13C, arg_138, STK-1);
                                                    }
                                                    else {
                                                            arg_134 = 0x0;
                                                            arg_318 = chown("/Library/LaunchDaemons/dropbear.plist", 0x0, arg_134);
                                                            if (arg_318 != 0x0) {
                                                                    arg_130 = arg_318;
                                                                    arg_12C = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_128 = r0;
                                                                    r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_130, arg_12C, arg_128, STK-1);
                                                            }
                                                            else {
                                                                    r0 = *objc_msgSend;
                                                                    arg_124 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_124);
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_30C = @"YLUProgressString";
                                                                    arg_310 = @"Installing Cydia";
                                                                    arg_120 = r0;
                                                                    arg_11C = 0x1;
                                                                    arg_118 = r2;
                                                                    var_0 = arg_11C;
                                                                    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_310, &arg_30C);
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_114 = r0;
                                                                    arg_110 = @"YLUDidReceiveUpdateProgressNotification";
                                                                    arg_10C = r2;
                                                                    var_0 = arg_114;
                                                                    [arg_120 postNotificationName:arg_110 object:0x0 userInfo:STK-1];
                                                                    [arg_114 release];
                                                                    [arg_120 release];
                                                                    r0 = *objc_msgSend;
                                                                    arg_108 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_108);
                                                                    r0 = [r0 retain];
                                                                    r3 = *objc_msgSend;
                                                                    arg_104 = r0;
                                                                    arg_100 = @"Cydia-9.0r4-Raw";
                                                                    arg_FC = @"tar";
                                                                    arg_F8 = r3;
                                                                    arg_308 = [[r0 URLForResource:arg_100 withExtension:arg_FC] retain];
                                                                    [arg_104 release];
                                                                    r0 = *objc_msgSend;
                                                                    arg_F4 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F4);
                                                                    r7 = r7;
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_F0 = r0;
                                                                    arg_EC = @"/Applications/Cydia.app/";
                                                                    r3 = arg_EC;
                                                                    arg_E8 = r2;
                                                                    r2 = r3;
                                                                    COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                    r0 = 0x0;
                                                                    asm{ it         ne };
                                                                    if (!COND) {
                                                                            r0 = 0x1;
                                                                    }
                                                                    r1 = arg_F0;
                                                                    arg_E4 = r0 ^ 0xffffffff;
                                                                    [r1 release];
                                                                    if ((arg_E4 & 0x1) != 0x0) {
                                                                            _logToFile("Didn't find Cydia.app (so we'll assume bearded old bootstrap isn't extracted, we will extract it)\n", r1, r2, r3, STK-1);
                                                                            arg_E0 = @"/bin/tar";
                                                                            r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_E0);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2F4 = @"-xvf";
                                                                            arg_DC = r0;
                                                                            arg_D8 = r1;
                                                                            r0 = loc_63a52(arg_308, @selector(path), arg_D8);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_2F8 = r0;
                                                                            arg_2FC = @"-C";
                                                                            arg_300 = @"/";
                                                                            arg_304 = @"--preserve-permissions";
                                                                            arg_D4 = r0;
                                                                            arg_D0 = r1;
                                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2F4, 0x5);
                                                                            r7 = r7;
                                                                            arg_CC = [r0 retain];
                                                                            arg_318 = _easyPosixSpawn(arg_DC, arg_CC);
                                                                            [arg_CC release];
                                                                            [arg_D4 release];
                                                                            [arg_DC release];
                                                                            if (arg_318 != 0x0) {
                                                                                    arg_C8 = arg_318;
                                                                                    arg_C4 = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_C0 = r0;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C8, arg_C4, arg_C0, STK-1);
                                                                            }
                                                                    }
                                                                    r1 = *objc_msgSend;
                                                                    arg_BC = @"/usr/bin/killall";
                                                                    arg_B8 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_BC, arg_B8);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2EC = @"-SIGSTOP";
                                                                    arg_2F0 = @"cfprefsd";
                                                                    arg_B4 = r0;
                                                                    arg_B0 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2EC, 0x2);
                                                                    r7 = r7;
                                                                    arg_AC = [r0 retain];
                                                                    arg_A8 = _easyPosixSpawn(arg_B4, arg_AC);
                                                                    [arg_AC release];
                                                                    [arg_B4 release];
                                                                    if (arg_318 != 0x0) {
                                                                            arg_A4 = arg_318;
                                                                            arg_A0 = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_9C = r0;
                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A4, arg_A0, arg_9C, STK-1);
                                                                    }
                                                                    r0 = *objc_msgSend;
                                                                    arg_98 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_98);
                                                                    r2 = *objc_msgSend;
                                                                    arg_94 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                    arg_90 = r2;
                                                                    r0 = [r0 initWithContentsOfFile:arg_94];
                                                                    r2 = *objc_msgSend;
                                                                    arg_2E8 = r0;
                                                                    arg_8C = arg_2E8;
                                                                    arg_88 = 0x1;
                                                                    arg_84 = r2;
                                                                    r0 = [NSNumber numberWithBool:sign_extend_32(arg_88)];
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_80 = r0;
                                                                    arg_7C = @"SBShowNonDefaultSystemApps";
                                                                    arg_78 = r2;
                                                                    [arg_8C setObject:r0 forKey:arg_7C];
                                                                    [arg_80 release];
                                                                    r2 = *objc_msgSend;
                                                                    arg_74 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                    arg_70 = 0x1;
                                                                    arg_6C = r2;
                                                                    r0 = [arg_2E8 writeToFile:arg_74 atomically:sign_extend_32(arg_70)];
                                                                    r2 = *objc_msgSend;
                                                                    arg_68 = r0;
                                                                    arg_64 = @"/usr/bin/killall";
                                                                    arg_60 = r2;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_64, arg_64);
                                                                    r0 = [r0 retain];
                                                                    r3 = 0x2;
                                                                    r1 = *objc_msgSend;
                                                                    r2 = &arg_2E0;
                                                                    arg_2E0 = @"-9";
                                                                    arg_2E4 = @"cfprefsd";
                                                                    arg_5C = r0;
                                                                    arg_58 = r1;
                                                                    r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), r2, r3);
                                                                    r7 = r7;
                                                                    arg_54 = [r0 retain];
                                                                    r1 = arg_54;
                                                                    arg_318 = _easyPosixSpawn(arg_5C, r1);
                                                                    [arg_54 release];
                                                                    [arg_5C release];
                                                                    if (arg_318 != 0x0) {
                                                                            arg_50 = arg_318;
                                                                            arg_4C = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_48 = r0;
                                                                            r1 = arg_50;
                                                                            r2 = arg_4C;
                                                                            r3 = arg_48;
                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", r1, r2, r3, STK-1);
                                                                    }
                                                                    _logToFile("Touching /.bearded_old_man_no_stash\n", r1, r2, r3, STK-1);
                                                                    arg_44 = @"/bin/touch";
                                                                    r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_44);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2DC = @"/.cydia_no_stash";
                                                                    arg_40 = r0;
                                                                    arg_3C = r1;
                                                                    arg_38 = [_OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2DC, 0x1) retain];
                                                                    arg_318 = _easyPosixSpawn(arg_40, arg_38);
                                                                    [arg_38 release];
                                                                    [arg_40 release];
                                                                    r0 = *objc_msgSend;
                                                                    arg_34 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_34);
                                                                    r7 = r7;
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_30 = r0;
                                                                    arg_2C = @"/.cydia_no_stash";
                                                                    r3 = arg_2C;
                                                                    arg_28 = r2;
                                                                    r2 = r3;
                                                                    COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                                    r0 = 0x0;
                                                                    asm{  };
                                                                    if (!COND) {
                                                                            r0 = 0x1;
                                                                    }
                                                                    r1 = arg_30;
                                                                    arg_24 = r0 ^ 0xffffffff;
                                                                    [r1 release];
                                                                    if ((arg_24 & 0x1) != 0x0) {
                                                                            _logToFile("WARNING WARNING WARNING\n", r1, r2, r3, STK-1);
                                                                            _logToFile("Even though we tried creating cydia_no_stash it looks like it's not there. So don't open the app by bearded old man (aka saurik)!\n", r1, r2, r3, STK-1);
                                                                    }
                                                                    r1 = *objc_msgSend;
                                                                    arg_20 = @"/bin/touch";
                                                                    arg_1C = r1;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_20, arg_1C);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2D8 = @"/.installed_home_depot";
                                                                    arg_18 = r0;
                                                                    arg_14 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2D8, 0x1);
                                                                    arg_10 = [r0 retain];
                                                                    arg_C = _easyPosixSpawn(arg_18, arg_10);
                                                                    [arg_10 release];
                                                                    [arg_18 release];
                                                                    _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_324, arg_328, 0x1, STK-1);
                                                                    r0 = system("su mobile -c uicache");
                                                                    arg_8 = r0;
                                                                    arg_4 = system("killall backboardd");
                                                                    _write_primitive(arg_328, arg_324);
                                                                    objc_storeStrong(&arg_2E8, 0x0);
                                                                    r0 = objc_storeStrong(&arg_308, 0x0);
                                                            }
                                                    }
                                            }
                                    }
                            }
                    }
                    else {
                            _logToFile("Changing permissions\n", r1, r2, r3, STK-1);
                            asm{ uxthne.w   r1, lr };
                            arg_318 = chmod("/bin/tar", r1);
                            if (arg_318 != 0x0) {
                                    arg_158 = arg_318;
                                    arg_154 = *__error();
                                    r0 = __error();
                                    r0 = *r0;
                                    r0 = strerror(r0);
                                    arg_150 = r0;
                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_158, arg_154, arg_150, STK-1);
                            }
                            else {
                                    asm{ uxth       r1, r1 };
                                    arg_318 = chmod("/bin/launchctl", 0x1ff);
                                    if (arg_318 != 0x0) {
                                            arg_14C = arg_318;
                                            arg_148 = *__error();
                                            r0 = __error();
                                            r0 = *r0;
                                            r0 = strerror(r0);
                                            arg_144 = r0;
                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_14C, arg_148, arg_144, STK-1);
                                    }
                                    else {
                                            asm{ uxth       r1, r1 };
                                            arg_318 = chmod("/Library/LaunchDaemons/dropbear.plist", 0x180);
                                            if (arg_318 != 0x0) {
                                                    arg_140 = arg_318;
                                                    arg_13C = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_138 = r0;
                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_140, arg_13C, arg_138, STK-1);
                                            }
                                            else {
                                                    arg_134 = 0x0;
                                                    arg_318 = chown("/Library/LaunchDaemons/dropbear.plist", 0x0, arg_134);
                                                    if (arg_318 != 0x0) {
                                                            arg_130 = arg_318;
                                                            arg_12C = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_128 = r0;
                                                            r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_130, arg_12C, arg_128, STK-1);
                                                    }
                                                    else {
                                                            r0 = *objc_msgSend;
                                                            arg_124 = r0;
                                                            r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_124);
                                                            r0 = [r0 retain];
                                                            r2 = *objc_msgSend;
                                                            arg_30C = @"YLUProgressString";
                                                            arg_310 = @"Installing Cydia";
                                                            arg_120 = r0;
                                                            arg_11C = 0x1;
                                                            arg_118 = r2;
                                                            var_0 = arg_11C;
                                                            r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_310, &arg_30C);
                                                            r0 = [r0 retain];
                                                            r2 = *objc_msgSend;
                                                            arg_114 = r0;
                                                            arg_110 = @"YLUDidReceiveUpdateProgressNotification";
                                                            arg_10C = r2;
                                                            var_0 = arg_114;
                                                            [arg_120 postNotificationName:arg_110 object:0x0 userInfo:STK-1];
                                                            [arg_114 release];
                                                            [arg_120 release];
                                                            r0 = *objc_msgSend;
                                                            arg_108 = r0;
                                                            r0 = _OBJC_CLASS_$_NSBundle(NSBundle, @selector(mainBundle), arg_108);
                                                            r0 = [r0 retain];
                                                            r3 = *objc_msgSend;
                                                            arg_104 = r0;
                                                            arg_100 = @"Cydia-9.0r4-Raw";
                                                            arg_FC = @"tar";
                                                            arg_F8 = r3;
                                                            arg_308 = [[r0 URLForResource:arg_100 withExtension:arg_FC] retain];
                                                            [arg_104 release];
                                                            r0 = *objc_msgSend;
                                                            arg_F4 = r0;
                                                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F4);
                                                            r7 = r7;
                                                            r0 = [r0 retain];
                                                            r2 = *objc_msgSend;
                                                            arg_F0 = r0;
                                                            arg_EC = @"/Applications/Cydia.app/";
                                                            r3 = arg_EC;
                                                            arg_E8 = r2;
                                                            r2 = r3;
                                                            COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                            r0 = 0x0;
                                                            asm{ it         ne };
                                                            if (!COND) {
                                                                    r0 = 0x1;
                                                            }
                                                            r1 = arg_F0;
                                                            arg_E4 = r0 ^ 0xffffffff;
                                                            [r1 release];
                                                            if ((arg_E4 & 0x1) != 0x0) {
                                                                    _logToFile("Didn't find Cydia.app (so we'll assume bearded old bootstrap isn't extracted, we will extract it)\n", r1, r2, r3, STK-1);
                                                                    arg_E0 = @"/bin/tar";
                                                                    r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_E0);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2F4 = @"-xvf";
                                                                    arg_DC = r0;
                                                                    arg_D8 = r1;
                                                                    r0 = loc_63a52(arg_308, @selector(path), arg_D8);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_2F8 = r0;
                                                                    arg_2FC = @"-C";
                                                                    arg_300 = @"/";
                                                                    arg_304 = @"--preserve-permissions";
                                                                    arg_D4 = r0;
                                                                    arg_D0 = r1;
                                                                    r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2F4, 0x5);
                                                                    r7 = r7;
                                                                    arg_CC = [r0 retain];
                                                                    arg_318 = _easyPosixSpawn(arg_DC, arg_CC);
                                                                    [arg_CC release];
                                                                    [arg_D4 release];
                                                                    [arg_DC release];
                                                                    if (arg_318 != 0x0) {
                                                                            arg_C8 = arg_318;
                                                                            arg_C4 = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_C0 = r0;
                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C8, arg_C4, arg_C0, STK-1);
                                                                    }
                                                            }
                                                            r1 = *objc_msgSend;
                                                            arg_BC = @"/usr/bin/killall";
                                                            arg_B8 = r1;
                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_BC, arg_B8);
                                                            r0 = [r0 retain];
                                                            r1 = *objc_msgSend;
                                                            arg_2EC = @"-SIGSTOP";
                                                            arg_2F0 = @"cfprefsd";
                                                            arg_B4 = r0;
                                                            arg_B0 = r1;
                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2EC, 0x2);
                                                            r7 = r7;
                                                            arg_AC = [r0 retain];
                                                            arg_A8 = _easyPosixSpawn(arg_B4, arg_AC);
                                                            [arg_AC release];
                                                            [arg_B4 release];
                                                            if (arg_318 != 0x0) {
                                                                    arg_A4 = arg_318;
                                                                    arg_A0 = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_9C = r0;
                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A4, arg_A0, arg_9C, STK-1);
                                                            }
                                                            r0 = *objc_msgSend;
                                                            arg_98 = r0;
                                                            r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_98);
                                                            r2 = *objc_msgSend;
                                                            arg_94 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                            arg_90 = r2;
                                                            r0 = [r0 initWithContentsOfFile:arg_94];
                                                            r2 = *objc_msgSend;
                                                            arg_2E8 = r0;
                                                            arg_8C = arg_2E8;
                                                            arg_88 = 0x1;
                                                            arg_84 = r2;
                                                            r0 = [NSNumber numberWithBool:sign_extend_32(arg_88)];
                                                            r0 = [r0 retain];
                                                            r2 = *objc_msgSend;
                                                            arg_80 = r0;
                                                            arg_7C = @"SBShowNonDefaultSystemApps";
                                                            arg_78 = r2;
                                                            [arg_8C setObject:r0 forKey:arg_7C];
                                                            [arg_80 release];
                                                            r2 = *objc_msgSend;
                                                            arg_74 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                            arg_70 = 0x1;
                                                            arg_6C = r2;
                                                            r0 = [arg_2E8 writeToFile:arg_74 atomically:sign_extend_32(arg_70)];
                                                            r2 = *objc_msgSend;
                                                            arg_68 = r0;
                                                            arg_64 = @"/usr/bin/killall";
                                                            arg_60 = r2;
                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_64, arg_64);
                                                            r0 = [r0 retain];
                                                            r3 = 0x2;
                                                            r1 = *objc_msgSend;
                                                            r2 = &arg_2E0;
                                                            arg_2E0 = @"-9";
                                                            arg_2E4 = @"cfprefsd";
                                                            arg_5C = r0;
                                                            arg_58 = r1;
                                                            r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), r2, r3);
                                                            r7 = r7;
                                                            arg_54 = [r0 retain];
                                                            r1 = arg_54;
                                                            arg_318 = _easyPosixSpawn(arg_5C, r1);
                                                            [arg_54 release];
                                                            [arg_5C release];
                                                            if (arg_318 != 0x0) {
                                                                    arg_50 = arg_318;
                                                                    arg_4C = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_48 = r0;
                                                                    r1 = arg_50;
                                                                    r2 = arg_4C;
                                                                    r3 = arg_48;
                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", r1, r2, r3, STK-1);
                                                            }
                                                            _logToFile("Touching /.bearded_old_man_no_stash\n", r1, r2, r3, STK-1);
                                                            arg_44 = @"/bin/touch";
                                                            r0 = _objc_msgSend(NSURL, @selector(fileURLWithPath:), arg_44);
                                                            r0 = [r0 retain];
                                                            r1 = *objc_msgSend;
                                                            arg_2DC = @"/.cydia_no_stash";
                                                            arg_40 = r0;
                                                            arg_3C = r1;
                                                            arg_38 = [_OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2DC, 0x1) retain];
                                                            arg_318 = _easyPosixSpawn(arg_40, arg_38);
                                                            [arg_38 release];
                                                            [arg_40 release];
                                                            r0 = *objc_msgSend;
                                                            arg_34 = r0;
                                                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_34);
                                                            r7 = r7;
                                                            r0 = [r0 retain];
                                                            r2 = *objc_msgSend;
                                                            arg_30 = r0;
                                                            arg_2C = @"/.cydia_no_stash";
                                                            r3 = arg_2C;
                                                            arg_28 = r2;
                                                            r2 = r3;
                                                            COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
                                                            r0 = 0x0;
                                                            asm{  };
                                                            if (!COND) {
                                                                    r0 = 0x1;
                                                            }
                                                            r1 = arg_30;
                                                            arg_24 = r0 ^ 0xffffffff;
                                                            [r1 release];
                                                            if ((arg_24 & 0x1) != 0x0) {
                                                                    _logToFile("WARNING WARNING WARNING\n", r1, r2, r3, STK-1);
                                                                    _logToFile("Even though we tried creating cydia_no_stash it looks like it's not there. So don't open the app by bearded old man (aka saurik)!\n", r1, r2, r3, STK-1);
                                                            }
                                                            r1 = *objc_msgSend;
                                                            arg_20 = @"/bin/touch";
                                                            arg_1C = r1;
                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_20, arg_1C);
                                                            r0 = [r0 retain];
                                                            r1 = *objc_msgSend;
                                                            arg_2D8 = @"/.installed_home_depot";
                                                            arg_18 = r0;
                                                            arg_14 = r1;
                                                            r0 = _OBJC_CLASS_$_NSArray(NSArray, @selector(arrayWithObjects:count:), &arg_2D8, 0x1);
                                                            arg_10 = [r0 retain];
                                                            arg_C = _easyPosixSpawn(arg_18, arg_10);
                                                            [arg_10 release];
                                                            [arg_18 release];
                                                            _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_324, arg_328, 0x1, STK-1);
                                                            r0 = system("su mobile -c uicache");
                                                            arg_8 = r0;
                                                            arg_4 = system("killall backboardd");
                                                            _write_primitive(arg_328, arg_324);
                                                            objc_storeStrong(&arg_2E8, 0x0);
                                                            r0 = objc_storeStrong(&arg_308, 0x0);
                                                    }
                                            }
                                    }
                            }
                    }
            }
    }
    return r0;
}
