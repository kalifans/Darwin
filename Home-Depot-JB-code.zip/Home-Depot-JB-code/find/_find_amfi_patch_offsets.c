int _find_amfi_patch_offsets(int arg0, int arg1, int arg2, int arg3) {
    r7 = sp;
    sp = sp - 0x78;
    r9 = *(r7 + 0x8);
    var_74 = arg0;
    var_70 = arg1;
    var_6C = arg2;
    var_68 = arg3;
    var_64 = r9;
    var_60 = memmem(var_70, var_6C, "int _validateCodeDirectoryHashInDaemon", 0x26);
    var_0 = var_60 - var_70;
    r0 = _find_other_literal_ref(var_74, var_70, var_6C, var_70);
    var_5C = r0;
    var_30 = 0x315a1;
    var_0 = var_30;
    var_58 = _find_last_insn_matching(var_74, var_70, var_6C, var_5C);
    var_54 = var_58;
    do {
            var_2C = 0x318d7;
            var_0 = var_2C;
            var_54 = _find_next_insn_matching(var_74, var_70, var_6C, var_54);
            var_50 = *(int8_t *)var_54;
            r0 = _insn_mov_imm_rd(var_54);
            var_4C = r0;
            var_28 = 0x49000 + (var_54 - var_70) + var_74;
            var_24 = printf("%p %d %d\n", var_28, var_50, var_4C);
            if (var_50 != 0x14) goto loc_3279a;
    } while (true);
    var_20 = printf("found it.\n");
    var_1C = 0x30171;
    var_0 = var_1C;
    var_48 = _find_next_insn_matching(var_74, var_70, var_6C, var_54);
    r0 = _insn_bl_imm32(var_48);
    var_44 = 0x4 + r0 + var_48;
    var_18 = var_48;
    var_14 = printf("BL address %p target %p\n", var_18, var_44);
    COND = _insn_is_mov_imm(var_44) == 0x0;
    r0 = 0x0;
    asm{ it         ne };
    if (!COND) {
            r0 = 0x1;
    }
    if (((r0 ^ 0xffffffff) & 0x1) != 0x0) {
            r0 = __assert_rtn("find_amfi_patch_offsets", "/Volumes/LEAN/Downloads/Archive 2 2/homedepot/Yalu/patchfinder.c", 0x603, "insn_is_mov_imm(blTarget)");
    }
    else {
            var_10 = "AbsoluteMovTarget %x %x\n";
            var_40 = _insn_movt_imm_imm(var_44 + 0x4);
            var_C = _insn_mov_imm_imm(var_44);
            r0 = _insn_movt_imm_imm(var_44 + 0x4);
            var_3C = var_C | r0;
            var_38 = 0xc + (var_C | r0) + var_44;
            r0 = printf(var_10, var_38, var_40);
            *var_68 = (var_38 - var_70) + var_74;
            var_34 = var_70;
            var_8 = r0;
            do {
                    r0 = memmem(var_70, var_6C, 0x73f2f, 0x4);
                    var_34 = r0;
            } while ((r0 & 0x1) != 0x0);
            r0 = printf("Found: %p\n", (0x0 - var_70) + var_34);
            *var_64 = var_74 + (0x0 - var_70) + var_34;
            var_4 = r0;
            return r0;
    }
    return r0;
}
