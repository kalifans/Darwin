int _find_remount_patch_offset(int arg0, int arg1, int arg2, int arg3) {
    sp = sp - 0x34;
    var_30 = arg0;
    var_2C = arg1;
    var_28 = arg2;
    var_24 = arg3;
    var_20 = memmem(var_2C, var_28, _find_remount_patch_offset.remap_search, 0xa);
    r0 = var_20;
    if (r0 == 0x0) {
    }
    else {
            var_10 = 0x315a1;
            var_0 = var_10;
            r0 = _find_last_insn_matching(var_30, var_2C, var_28, var_20);
            var_1C = r0;
            var_C = 0x3267d;
            var_0 = var_C;
            r0 = _find_next_insn_matching(var_30, var_2C, var_28, var_1C);
            var_18 = r0;
            var_8 = 0x3250d;
            var_0 = var_8;
            r0 = _find_next_insn_matching(var_30, var_2C, var_28, var_18);
            var_14 = r0;
            var_4 = 0x30225;
            var_0 = var_4;
            var_14 = _find_next_insn_matching(var_30, var_2C, var_28, var_14);
            r0 = (var_14 - var_2C) + var_30;
            *var_24 = r0;
    }
    return r0;
}

_find_remount_patch_offset.remap_search:
00073f25         db  0x02 ; '.'                                                 ; XREF=_find_remount_patch_offset+14
00073f26         db  0x91 ; '.'
00073f27         db  0x03 ; '.'
00073f28         db  0x94 ; '.'
00073f29         db  0x04 ; '.'
00073f2a         db  0x91 ; '.'
00073f2b         db  0x07 ; '.'
00073f2c         db  0x99 ; '.'
00073f2d         db  0x08 ; '.'
00073f2e         db  0x9a ; '.'
00073f2f         db  0x00 ; '.'                                                 ; XREF=_find_amfi_patch_offsets+510
00073f30         db  0x20 ; ' '
00073f31         db  0x70 ; 'p'
00073f32         db  0x47 ; 'G'
00073f33         db  0x00 ; '.'

int _find_last_insn_matching(int arg0, int arg1, int arg2, int arg3) {
    r7 = sp;
    sp = sp - 0x1c;
    r9 = *(r7 + 0x8);
    var_14 = arg0;
    var_10 = arg1;
    var_C = arg2;
    var_8 = arg3;
    var_4 = r9;

loc_30100:
    if (var_8 >= var_10) goto loc_30166;
    goto loc_30108;

loc_30166:
    var_18 = 0x0;

loc_3016a:
    r0 = var_18;
    return r0;

loc_30108:
    if ((_insn_is_32bit(var_8 + 0xfffffffc) == 0x0) || (_insn_is_32bit(var_8 + 0xfffffffa) != 0x0)) {
            var_8 = var_8 + 0xfffffffe;
    }
    else {
            var_8 = var_8 + 0xfffffffc;
    }
    var_0 = var_4;
    if ((var_0)(var_8, var_0) == 0x0) goto loc_30100;
    var_18 = var_8;
    goto loc_3016a;
}

int _find_next_insn_matching(int arg0, int arg1, int arg2, int arg3) {
    r7 = sp;
    sp = sp - 0x1c;
    r9 = *(r7 + 0x8);
    var_14 = arg0;
    var_10 = arg1;
    var_C = arg2;
    var_8 = arg3;
    var_4 = r9;

loc_324ba:
    if (var_8 >= var_10 + var_C) goto loc_32502;
    goto loc_324c6;

loc_32502:
    var_18 = 0x0;

loc_32506:
    r0 = var_18;
    return r0;

loc_324c6:
    if ((_insn_is_32bit(var_8) == 0x0) || (_insn_is_32bit(var_8 + 0x2) != 0x0)) {
            var_8 = var_8 + 0x2;
    }
    else {
            var_8 = var_8 + 0x4;
    }
    var_0 = var_4;
    if ((var_0)(var_8, var_0) == 0x0) goto loc_324ba;
    var_18 = var_8;
    goto loc_32506;
}

