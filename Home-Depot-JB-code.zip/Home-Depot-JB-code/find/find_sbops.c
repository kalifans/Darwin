int _find_sbops(int arg0, int arg1, int arg2, int arg3) {
    sp = sp - 0x18;
    var_14 = arg0;
    var_10 = arg1;
    var_C = arg2;
    var_8 = arg3;
    var_4 = memmem(var_10, var_C, "Seatbelt sandbox policy", 0x17);
    var_0 = 0x0;

loc_32eda:
    r0 = var_0;
    if (r0 >= var_C >> 0x2) goto loc_32f1c;
    goto loc_32eea;

loc_32f1c:
    return r0;

loc_32eea:
    if (*(var_10 + var_0 * 0x4) != var_14 + (0x0 - var_10) + var_4) goto loc_32f12;
    goto loc_32f02;

loc_32f12:
    var_0 = var_0 + 0x1;
    goto loc_32eda;

loc_32f02:
    r0 = *(0xc + var_10 + (var_0 << 0x2));
    *var_8 = r0;
    goto loc_32f1c;
}
