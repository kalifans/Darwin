int _find_amfi_substrate_patch(int arg0, int arg1, int arg2, int arg3) {
    sp = sp - 0x40;
    var_3C = arg0;
    var_38 = arg1;
    var_34 = arg2;
    var_30 = arg3;
    var_2C = memmem(var_38, var_34, "com.apple.rootless.install", 0x1a);
    var_0 = var_2C - var_38;
    r0 = _find_other_literal_ref(var_3C, var_38, var_34, var_38);
    var_28 = r0;
    var_18 = 0x49000 + (var_28 - var_38) + var_3C;
    r0 = printf("ref: %p\n", var_18);
    var_24 = var_28;
    var_14 = r0;
    do {
            var_10 = 0x309e3;
            var_0 = var_10;
            var_24 = _find_next_insn_matching(var_3C, var_38, var_34, var_24);
            var_20 = _insn_cmp_imm_imm(var_24);
            r0 = _insn_cmp_imm_rn(var_24);
            var_1C = r0;
            var_C = 0x49000 + (var_24 - var_38) + var_3C;
            var_8 = printf("%p %d %d\n", var_C, var_20, var_1C);
            if (var_20 != 0x0) goto loc_32ac6;
    } while (true);
    var_4 = printf("found it.\n");
    r0 = (var_24 - var_38) + var_3C;
    *var_30 = r0;
    return r0;
}
