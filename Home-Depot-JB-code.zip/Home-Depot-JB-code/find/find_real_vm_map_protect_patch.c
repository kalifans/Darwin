int _find_real_vm_map_protect_patch(int arg0, int arg1, int arg2, int arg3) {
    sp = sp - 0x20;
    var_1C = arg0;
    var_18 = arg1;
    var_14 = arg2;
    var_10 = arg3;
    var_C = memmem(var_18, var_14, _find_real_vm_map_protect_patch.search, 0x6);
    r0 = var_C;
    if (r0 == 0x0) {
    }
    else {
            var_4 = 0x32bd3;
            var_0 = var_4;
            var_8 = _find_next_insn_matching(var_1C, var_18, var_14, var_C);
            r0 = (var_8 - var_18) + var_1C;
            *var_10 = r0;
    }
    return r0;
}

_find_real_vm_map_protect_patch.search:
12 f4 00 1f  4b 68
00073f3c         db  0x12 ; '.'
00073f3d         db  0xf4 ; '.'
00073f3e         db  0x00 ; '.'
00073f3f         db  0x1f ; '.'
00073f40         db  0x4b ; 'K'
00073f41         db  0x68 ; 'h'
