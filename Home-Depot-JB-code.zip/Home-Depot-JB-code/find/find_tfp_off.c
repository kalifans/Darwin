int _find_tfp_off(int arg0, int arg1, int arg2, int arg3) {
    var_1C = arg0;
    var_18 = arg1;
    var_14 = arg2;
    var_10 = arg3;
    r0 = memmem(var_18, var_14, 0x73f60, 0xf);
    var_C = r0;
    var_4 = 0x309e3;
    var_0 = var_4;
    var_8 = _find_next_insn_matching(var_1C, var_18, var_14, var_C);
    r0 = (var_8 - var_18) + var_1C;
    *var_10 = r0;
    return r0;
}
