int _find_literal_ref(int arg0, int arg1, int arg2, int arg3) {
    r7 = &arg_4;
    sp = sp - 0x74;
    r9 = *(r7 + 0x8);
    arg_6C = arg0;
    arg_68 = arg1;
    arg_64 = arg2;
    arg_60 = arg3;
    arg_5C = r9;
    arg_58 = arg_60;
    memset(&arg_18, 0x0 & 0xff, 0x40);

loc_2ff88:
    if (arg_58 >= arg_68 + arg_64) goto loc_300e0;
    goto loc_2ff96;

loc_300e0:
    arg_70 = 0x0;

loc_300e4:
    r0 = arg_70;
    return r0;

loc_2ff96:
    if (_insn_is_mov_imm(arg_58) == 0x0) goto loc_2ffc4;
    goto loc_2ffa0;

loc_2ffc4:
    if (_insn_is_ldr_literal(arg_58) == 0x0) goto loc_30024;
    goto loc_2ffce;

loc_30024:
    if (_insn_is_movt(arg_58) == 0x0) goto loc_30058;
    goto loc_3002e;

loc_30058:
    if (_insn_is_add_reg(arg_58) == 0x0) goto loc_300b6;
    goto loc_30062;

loc_300b6:
    r0 = _insn_is_32bit(arg_58);
    lr = 0x2;
    COND = r0 == 0x0;
    r0 = 0x0;
    asm{ it         ne };
    if (!COND) {
            r0 = 0x1;
    }
    asm{  };
    if ((r0 & 0x1) == 0x0) {
            lr = 0x1;
    }
    arg_58 = arg_58 + (lr << 0x1);
    goto loc_2ff88;

loc_30062:
    arg_10 = _insn_add_reg_rd(arg_58);
    if ((_insn_add_reg_rm(arg_58) == 0xf) && (_insn_add_reg_rn(arg_58) == arg_10)) goto loc_30082;
    goto loc_300b6;

loc_30082:
    *((arg_10 << 0x2) + &arg_18) = *((arg_10 << 0x2) + &arg_18) + (arg_58 - arg_68) + 0x4;
    if (*(&arg_18 + (arg_10 << 0x2)) != arg_5C) goto loc_300b6;
    arg_70 = arg_58;
    goto loc_300e4;

loc_3002e:
    var_0 = _insn_movt_imm(arg_58) << 0x10;
    r0 = _insn_movt_rd(arg_58);
    *((r0 << 0x2) + &arg_18) = var_0 | *((r0 << 0x2) + &arg_18);
    goto loc_300b6;

loc_2ffce:
    arg_8 = arg_68 + ((arg_58 - arg_68) + 0x4 & 0xfffffffc);
    arg_14 = _insn_ldr_literal_imm(arg_58) + arg_8;
    if ((arg_14 >= arg_68) && (arg_14 + 0x4 <= arg_68 + arg_64)) {
            arg_4 = *arg_14;
            *((_insn_ldr_literal_rt(arg_58) << 0x2) + &arg_18) = arg_4;
    }
    goto loc_300b6;

loc_2ffa0:
    arg_C = _insn_mov_imm_imm(arg_58);
    *((_insn_mov_imm_rd(arg_58) << 0x2) + &arg_18) = arg_C;
    goto loc_300b6;
}