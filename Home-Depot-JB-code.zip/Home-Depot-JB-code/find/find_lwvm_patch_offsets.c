int _find_lwvm_patch_offsets(int arg0, int arg1, int arg2, int arg3) {
    r7 = sp;
    sp = sp - 0x64;
    r9 = *(r7 + 0x8);
    var_60 = arg0;
    var_5C = arg1;
    var_58 = arg2;
    var_54 = arg3;
    var_50 = r9;
    var_4C = memmem(var_5C, var_58, "_mapForIO", 0x9);
    var_0 = var_4C - var_5C;
    r0 = _find_literal_ref(var_60, var_5C, var_58, var_5C);
    var_48 = r0;
    var_1C = 0x315a1;
    var_0 = var_1C;
    r0 = _find_last_insn_matching(var_60, var_5C, var_58, var_48);
    var_44 = r0;
    var_18 = 0x3250d;
    var_0 = var_18;
    var_40 = _find_next_insn_matching(var_60, var_5C, var_58, var_44);
    var_3C = var_44;
    do {
            var_14 = 0x30b0f;
            var_0 = var_14;
            var_3C = _find_next_insn_matching(var_60, var_5C, var_58, var_3C);
            var_38 = _insn_ldr_imm_imm(var_3C);
            if (var_38 == 0x16) {
                break;
            }
    } while (true);
    if (_insn_is_bne_w(var_3C + 0xfffffffc) != 0x0) {
            var_10 = 0x1;
    }
    else {
            r0 = _insn_is_bne(var_3C + 0xfffffffe);
            r1 = 0x0;
            COND = r0 == 0x0;
            r0 = 0x0;
            asm{ it         ne };
            if (!COND) {
                    r0 = 0x1;
            }
            asm{  };
            if ((r0 & 0x1) == 0x0) {
                    r1 = 0x0 ^ 0xffffffff;
            }
            var_10 = r1;
    }
    var_34 = var_10;
    r0 = var_34;
    if (r0 != -0x1) {
            r0 = printf("Is BNE.W: %d\n", var_34);
            *var_50 = (var_3C - var_5C) + var_60;
            var_C = r0;
            var_8 = 0x30171;
            var_0 = var_8;
            var_30 = _find_next_insn_matching(var_60, var_5C, var_58, var_40);
            if (var_30 < var_3C) {
                    r0 = printf("We don't have a BL!\n");
                    lr = 0x4;
                    r1 = 0x0;
                    asm{  };
                    if (var_34 != 0x0) {
                            r1 = 0x1;
                    }
                    asm{  };
                    if ((r1 & 0x1) == 0x0) {
                            lr = 0x2;
                    }
                    *var_54 = lr;
                    var_4 = r0;
            }
            else {
                    r0 = _insn_bl_imm32(var_30);
                    var_2C = r0;
                    var_28 = 0x4 + r0 + var_30;
                    r0 = _insn_mov_imm_imm(0x4 + r0 + var_30);
                    var_24 = r0;
                    var_20 = 0x4 + r0 + var_28 + 0x8;
                    r0 = (var_20 - var_5C) + var_60;
                    *var_54 = r0;
            }
    }
    return r0;
}

==============================================================

int _insn_ldr_imm_imm(int arg0) {
    var_0 = arg0;
    r0 = *(int16_t *)var_0;
    r0 = SAR(r0, 0x6) & 0x1f;
    return r0;
}

int _insn_is_bne_w(int arg0) {
    sp = sp - 0x8;
    arg_4 = arg0;
    r0 = *(int16_t *)arg_4;
    var_0 = 0x0;
    if ((r0 & 0xf800) == 0xf000) {
            r1 = *(int16_t *)arg_4;
            var_0 = 0x0;
            if ((r1 & 0x3c0) == 0x40) {
                    COND = (*(int16_t *)(arg_4 + 0x2) & 0xd000) != 0x8000;
                    r0 = 0x0;
                    asm{ it         eq };
                    if (!COND) {
                            r0 = 0x1;
                    }
                    var_0 = r0;
            }
    }
    r0 = var_0 & 0x1;
    return r0;
}

int _insn_is_bne(int arg0) {
    sp = sp - 0x8;
    var_4 = arg0;
    r0 = _insn_is_b_conditional(var_4);
    var_0 = 0x0;
    if (r0 != 0x0) {
            COND = (*(int16_t *)var_4 & 0xf00) != 0x100;
            r0 = 0x0;
            asm{ it         eq };
            if (!COND) {
                    r0 = 0x1;
            }
            var_0 = r0;
    }
    r0 = var_0 & 0x1;
    return r0;
}

int _insn_bl_imm32(int arg0) {
    sp = sp - 0x28;
    r1 = 0xff000000;
    arg_24 = arg0;
    arg_22 = *(int16_t *)arg_24;
    arg_20 = *(int16_t *)(arg_24 + 0x2);
    arg_1C = SAR(arg_22, 0xa) & 0x1;
    arg_18 = SAR(arg_20, 0xd) & 0x1;
    arg_14 = SAR(arg_20, 0xb) & 0x1;
    arg_10 = (arg_18 ^ arg_1C ^ 0xffffffff) & 0x1;
    arg_C = (arg_14 ^ arg_1C ^ 0xffffffff) & 0x1;
    arg_8 = arg_22 & 0x3ff;
    arg_4 = arg_20 & 0x7ff;
    r0 = arg_4 << 0x1 | arg_8 << 0xc | arg_C << 0x16 | arg_10 << 0x17;
    r2 = 0x0;
    asm{ it         ne };
    if (arg_1C != 0x0) {
            r2 = 0x1;
    }
    asm{  };
    if ((r2 & 0x1) == 0x0) {
            r1 = 0x0;
    }
    var_0 = r0 | r1;
    r0 = var_0;
    return r0;
}

int _insn_mov_imm_imm(int arg0) {
    sp = sp - 0x8;
    var_0 = arg0;
    if ((*(int16_t *)var_0 & 0xf800) == 0x2000) {
            var_4 = *(int16_t *)var_0 & 0xf;
    }
    else {
            if (((*(int16_t *)var_0 & 0xfbef) != 0xf04f) || ((*(int16_t *)(var_0 + 0x2) & 0x8000) != 0x0)) {
                    if (((*(int16_t *)var_0 & 0xfbf0) != 0xf240) || ((*(int16_t *)(var_0 + 0x2) & 0x8000) != 0x0)) {
                            var_4 = 0x0;
                    }
                    else {
                            var_4 = (*(int16_t *)var_0 & 0xf) << 0xc | (*(int16_t *)var_0 & 0x400) << 0x1 | SAR((*(int16_t *)(var_0 + 0x2) & 0x7000), 0x4) | *(int16_t *)(var_0 + 0x2) & 0xff;
                    }
            }
            else {
                    r0 = *(int16_t *)var_0;
                    r0 = (r0 & 0x400) << 0x1 | SAR((*(int16_t *)(var_0 + 0x2) & 0x7000), 0x4);
                    asm{ uxth       r0, r0 };
                    var_4 = _thumb_expand_imm_c();
            }
    }
    r0 = var_4;
    return r0;
}
