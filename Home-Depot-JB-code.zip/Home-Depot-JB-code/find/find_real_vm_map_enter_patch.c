int _find_real_vm_map_enter_patch(int arg0, int arg1, int arg2, int arg3) {
    r7 = sp;
    sp = sp - 0x3c;
    r9 = *(r7 + 0x8);
    var_38 = arg0;
    var_34 = arg1;
    var_30 = arg2;
    var_2C = arg3;
    var_28 = r9;
    var_24 = memmem(var_34, var_30, _find_real_vm_map_enter_patch.search, 0x8);
    r0 = var_24;
    if (r0 == 0x0) {
    }
    else {
            var_14 = 0x30171;
            var_0 = var_14;
            r0 = _find_next_insn_matching(var_38, var_34, var_30, var_24);
            var_20 = r0;
            var_10 = 0x30225;
            var_0 = var_10;
            r0 = _find_next_insn_matching(var_38, var_34, var_30, var_20);
            var_1C = r0;
            *var_2C = (var_1C - var_34) + var_38;
            var_C = 0x32bd3;
            var_0 = var_C;
            r0 = _find_next_insn_matching(var_38, var_34, var_30, var_1C);
            var_18 = r0;
            *var_28 = (var_18 - var_34) + var_38;
            var_8 = var_24;
            r0 = printf("Found bytes: %p %p %p", var_8, var_20, var_1C);
            var_4 = r0;
    }
    return r0;
}

_find_real_vm_map_enter_patch.search:
19 98 40 f4  80 10 19 90
00073f34         db  0x19 ; '.'
00073f35         db  0x98 ; '.'
00073f36         db  0x40 ; '@'
00073f37         db  0xf4 ; '.'
00073f38         db  0x80 ; '.'
00073f39         db  0x10 ; '.'
00073f3a         db  0x19 ; '.'
00073f3b         db  0x90 ; '.'
