int _find_last_insn_matching(int arg0, int arg1, int arg2, int arg3) {
    r7 = sp;
    sp = sp - 0x1c;
    r9 = *(r7 + 0x8);
    var_14 = arg0;
    var_10 = arg1;
    var_C = arg2;
    var_8 = arg3;
    var_4 = r9;

loc_30100:
    if (var_8 >= var_10) goto loc_30166;
    goto loc_30108;

loc_30166:
    var_18 = 0x0;

loc_3016a:
    r0 = var_18;
    return r0;

loc_30108:
    if ((_insn_is_32bit(var_8 + 0xfffffffc) == 0x0) || (_insn_is_32bit(var_8 + 0xfffffffa) != 0x0)) {
            var_8 = var_8 + 0xfffffffe;
    }
    else {
            var_8 = var_8 + 0xfffffffc;
    }
    var_0 = var_4;
    if ((var_0)(var_8, var_0) == 0x0) goto loc_30100;
    var_18 = var_8;
    goto loc_3016a;
}
