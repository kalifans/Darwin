int _find_another_amfi_hack(int arg0, int arg1, int arg2, int arg3) {
    r9 = *(&arg_4 + 0xc);
    r12 = *(&arg_4 + 0x8);
    arg_38 = arg0;
    arg_34 = arg1;
    arg_30 = arg2;
    arg_2C = arg3;
    arg_28 = r12;
    arg_24 = r9;
    arg_20 = memmem(arg_34, arg_30, "AMFI: hook..execve() killing pid %u: %s", 0x27);
    var_0 = arg_20 - arg_34;
    arg_1C = _find_yet_another_literal_ref(arg_38, arg_34, arg_30, arg_34);
    r0 = _other_insn_ldr_literal_imm(arg_1C + 0xfffffffc);
    arg_18 = r0;
    arg_14 = arg_18 + 0x2 + arg_1C + 0xfffffffc;
    *0xfffffffc = (arg_14 - arg_34) + arg_38;
    arg_8 = 0x30171;
    var_0 = arg_8;
    r0 = _find_next_insn_matching(arg_38, arg_34, arg_30, arg_1C);
    arg_10 = r0;
    *arg_28 = (arg_10 - arg_34) + arg_38;
    arg_4 = 0x32dad;
    var_0 = arg_4;
    arg_C = _find_next_insn_matching(arg_38, arg_34, arg_30, arg_1C);
    r0 = (arg_C + 0xfffffffa - arg_34) + arg_38;
    *0xfffffffa = r0;
    return r0;
}


=======================
int _find_yet_another_literal_ref(int arg0, int arg1, int arg2, int arg3) {
    r7 = &arg_4;
    asm{ bfc        r4, #0x0, #0x3 };
    sp = sp - 0x8c;
    r9 = *(r7 + 0x8);
    arg_84 = arg0;
    arg_80 = arg1;
    arg_7C = arg2;
    arg_78 = arg3;
    arg_74 = r9;
    arg_70 = arg_78;
    memset(&arg_30, 0x0 & 0xff, 0x40);

loc_31404:
    if (arg_70 >= arg_80 + arg_7C) goto loc_31594;
    goto loc_31412;

loc_31594:
    arg_88 = 0x0;

loc_31598:
    r0 = arg_88;
    return r0;

loc_31412:
    if (_insn_is_mov_imm(arg_70) == 0x0) goto loc_31440;
    goto loc_3141c;

loc_31440:
    if (_insn_is_ldr_literal(arg_70) == 0x0) goto loc_314d8;
    goto loc_3144a;

loc_314d8:
    if (_insn_is_movt(arg_70) == 0x0) goto loc_3150c;
    goto loc_314e2;

loc_3150c:
    if (_insn_is_add_reg(arg_70) == 0x0) goto loc_3156a;
    goto loc_31516;

loc_3156a:
    r0 = _insn_is_32bit(arg_70);
    lr = 0x2;
    COND = r0 == 0x0;
    r0 = 0x0;
    asm{ it         ne };
    if (!COND) {
            r0 = 0x1;
    }
    asm{  };
    if ((r0 & 0x1) == 0x0) {
            lr = 0x1;
    }
    arg_70 = arg_70 + (lr << 0x1);
    goto loc_31404;

loc_31516:
    arg_18 = _insn_add_reg_rd(arg_70);
    if ((_insn_add_reg_rm(arg_70) == 0xf) && (_insn_add_reg_rn(arg_70) == arg_18)) goto loc_31536;
    goto loc_3156a;

loc_31536:
    *((arg_18 << 0x2) + &arg_30) = *((arg_18 << 0x2) + &arg_30) + (arg_70 - arg_80) + 0x4;
    if (*(&arg_30 + (arg_18 << 0x2)) != arg_74) goto loc_3156a;
    arg_88 = arg_70;
    goto loc_31598;

loc_314e2:
    var_0 = _insn_movt_imm(arg_70) << 0x10;
    r0 = _insn_movt_rd(arg_70);
    *((r0 << 0x2) + &arg_30) = var_0 | *((r0 << 0x2) + &arg_30);
    goto loc_3156a;

loc_3144a:
    arg_10 = arg_80 + ((arg_70 - arg_80) + 0x4 & !0x3);
    arg_2C = _insn_ldr_literal_imm(arg_70) + arg_10;
    r0 = arg_70 - arg_80;
    r1 = 0x0 - 0x0 + !CARRY(FLAGS);
    r0 = r0 - 0x72ba41;
    COND = r1 < 0x0 + !CARRY(FLAGS);
    arg_C = r0;
    arg_8 = r1;
    if (!COND) {
            r0 = *(int8_t *)arg_70;
            arg_24 = 0x0;
            arg_20 = r0 << 0x2;
            arg_1C = 0x2 + arg_70 + *(int8_t *)arg_70;
            arg_2C = arg_1C;
            if ((arg_2C >= arg_80) && (arg_2C + 0x4 <= arg_80 + arg_7C)) {
                    arg_4 = *arg_2C;
                    *((_insn_ldr_literal_rt(arg_70) << 0x2) + &arg_30) = arg_4;
            }
    }
    else {
            r0 = *(int8_t *)arg_70;
            arg_24 = 0x0;
            arg_20 = r0 << 0x2;
            arg_1C = 0x2 + arg_70 + *(int8_t *)arg_70;
            arg_2C = arg_1C;
            if ((arg_2C >= arg_80) && (arg_2C + 0x4 <= arg_80 + arg_7C)) {
                    arg_4 = *arg_2C;
                    *((_insn_ldr_literal_rt(arg_70) << 0x2) + &arg_30) = arg_4;
            }
    }
    goto loc_3156a;

loc_3141c:
    arg_14 = _insn_mov_imm_imm(arg_70);
    *((_insn_mov_imm_rd(arg_70) << 0x2) + &arg_30) = arg_14;
    goto loc_3156a;
}



int _other_insn_ldr_literal_imm(int arg0) {
    var_0 = arg0;
    r0 = *(int16_t *)var_0;
    r0 = (r0 & 0xff) << 0x2;
    return r0;
}

