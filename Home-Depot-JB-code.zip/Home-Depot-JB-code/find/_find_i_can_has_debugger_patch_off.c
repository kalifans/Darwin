int _find_i_can_has_debugger_patch_off(int arg0, int arg1, int arg2, int arg3) {
    var_10 = arg0;
    var_C = arg1;
    var_8 = arg2;
    var_4 = arg3;
    var_0 = memmem(var_C, var_8, "Darwin Kernel", 0xd);
    r0 = var_10 + (0x0 - var_C) + var_0 + 0xfffffffc;
    *0x4 = r0;
    return r0;
}
