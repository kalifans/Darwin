int _startSSH_real(int arg0, int arg1) {
    STK35 = r7;
    r7 = &arg_C;
    sp = sp - 0x1cc;
    r2 = *objc_msgSend;
    arg_1C8 = arg0;
    arg_1C4 = arg1;
    arg_1C0 = 0x0;
    r0 = _objc_msgSend(NSFileManager, @selector(defaultManager), r2, 0x78dcc, lr, STK35, r6, r5, r4);
    r7 = r7;
    r0 = [r0 retain];
    r2 = *objc_msgSend;
    arg_18C = r0;
    arg_188 = @"/.installed_home_depot";
    r3 = arg_188;
    arg_184 = r2;
    r2 = r3;
    COND = sign_extend_32([r0 fileExistsAtPath:r2]) == 0x0;
    r0 = 0x0;
    asm{ it         ne };
    if (!COND) {
            r0 = 0x1;
    }
    r1 = arg_18C;
    arg_180 = r0 ^ 0xffffffff;
    [r1 release];
    if ((arg_180 & 0x1) != 0x0) {
            _logToFile("Re-extracting bootstrap\n", r1, r2, r3, STK-1);
            r0 = *objc_msgSend;
            arg_17C = r0;
            r0 = ("mainBundle")(NSBundle, @selector(mainBundle));
            r0 = [r0 retain];
            r2 = *objc_msgSend;
            arg_178 = r0;
            arg_174 = @"Cydia-9.0r4-Raw";
            arg_170 = r2;
            arg_1BC = [[r0 URLForResource:arg_174 withExtension:@"tar"] retain];
            [arg_178 release];
            r1 = *objc_msgSend;
            arg_16C = @"/bin/tar";
            arg_168 = r1;
            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_16C, arg_168);
            r0 = [r0 retain];
            r1 = *objc_msgSend;
            arg_1A4 = @"-xvf";
            arg_164 = r0;
            arg_160 = r1;
            r0 = loc_63a52(arg_1BC, @selector(path), arg_160, arg_1BC);
            r0 = [r0 retain];
            r1 = *objc_msgSend;
            arg_1A8 = r0;
            arg_1AC = @"-C";
            arg_1B0 = @"/";
            arg_1B4 = @"--preserve-permissions";
            arg_15C = r0;
            arg_158 = r1;
            r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), &arg_1A4, 0x5);
            arg_154 = [r0 retain];
            arg_150 = _easyPosixSpawn(arg_164, arg_154);
            [arg_154 release];
            [arg_15C release];
            [arg_164 release];
            arg_1B8 = arg_150;
            if (arg_1B8 != 0x0) {
                    arg_14C = arg_1B8;
                    arg_148 = *__error();
                    r0 = __error();
                    r0 = *r0;
                    r0 = strerror(r0);
                    arg_144 = r0;
                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_14C, arg_148, arg_144, STK-1);
            }
            _startSSH(arg_1C8, arg_1C4);
            r0 = objc_storeStrong(&arg_1BC, 0x0);
    }
    else {
            _logToFile("Launching dropbear\n", r1, r2, r3, STK-1);
            r0 = *objc_msgSend;
            arg_140 = r0;
            r0 = loc_635b0(NSFileManager, @selector(defaultManager));
            r7 = r7;
            r0 = [r0 retain];
            r3 = r0;
            arg_13C = r0;
            arg_138 = @"/usr/libexec/reload";
            r2 = arg_138;
            COND = sign_extend_32(_objc_msgSend(r3, @selector(fileExistsAtPath:), r2, r3)) == 0x0;
            r0 = 0x0;
            asm{  };
            if (!COND) {
                    r0 = 0x1;
            }
            r1 = arg_13C;
            arg_134 = r0 ^ 0xffffffff;
            [r1 release];
            if ((arg_134 & 0x1) != 0x0) {
                    _logToFile("enable\n", r1, r2, r3, STK-1);
                    r0 = *objc_msgSend;
                    arg_130 = r0;
                    r0 = ("mainBundle")(NSBundle, @selector(mainBundle));
                    r0 = [r0 retain];
                    r2 = *objc_msgSend;
                    arg_12C = r0;
                    arg_128 = @"reload";
                    arg_124 = r2;
                    r0 = [r0 URLForResource:arg_128 withExtension:@""];
                    r0 = [r0 retain];
                    r1 = *objc_msgSend;
                    arg_120 = r0;
                    arg_11C = r1;
                    r0 = loc_63a52(r0, @selector(path), arg_11C, r0);
                    r7 = r7;
                    r0 = [r0 retain];
                    arg_118 = r0;
                    objc_retainAutorelease(r0);
                    r1 = *objc_msgSend;
                    arg_114 = r1;
                    r0 = ("UTF8String")();
                    arg_1C0 = copyfile(r0, "/usr/libexec/reload", 0x0, 0xf);
                    [arg_118 release];
                    [arg_120 release];
                    [arg_12C release];
                    if (arg_1C0 != 0x0) {
                            arg_110 = arg_1C0;
                            arg_10C = *__error();
                            r0 = __error();
                            r0 = *r0;
                            r0 = strerror(r0);
                            arg_108 = r0;
                            r0 = _logToFile("Copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_110, arg_10C, arg_108, STK-1);
                    }
                    else {
                            asm{ uxthne     r1, r1 };
                            arg_1C0 = chmod("/usr/libexec/reload", 0x1ed);
                            if (arg_1C0 != 0x0) {
                                    arg_104 = arg_1C0;
                                    arg_100 = *__error();
                                    r0 = __error();
                                    r0 = *r0;
                                    r0 = strerror(r0);
                                    arg_FC = r0;
                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_104, arg_100, arg_FC, STK-1);
                            }
                            else {
                                    r0 = *objc_msgSend;
                                    arg_F8 = r0;
                                    r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F8);
                                    r7 = r7;
                                    r0 = [r0 retain];
                                    r2 = *objc_msgSend;
                                    arg_F4 = r0;
                                    arg_F0 = @"/Library/LaunchDaemons/0.reload.plist";
                                    r3 = arg_F0;
                                    arg_EC = r2;
                                    r2 = r3;
                                    COND = sign_extend_32(("fileExistsAtPath:")(r0, @selector(fileExistsAtPath:), r2, r3)) == 0x0;
                                    r0 = 0x0;
                                    asm{ it         ne };
                                    if (!COND) {
                                            r0 = 0x1;
                                    }
                                    r1 = arg_F4;
                                    arg_E8 = r0 ^ 0xffffffff;
                                    [r1 release];
                                    if ((arg_E8 & 0x1) != 0x0) {
                                            _logToFile("enable\n", r1, r2, r3, STK-1);
                                            r0 = *objc_msgSend;
                                            arg_E4 = r0;
                                            r0 = ("mainBundle")(NSBundle, @selector(mainBundle));
                                            r0 = [r0 retain];
                                            r2 = *objc_msgSend;
                                            arg_E0 = r0;
                                            arg_DC = @"0.reload";
                                            arg_D8 = r2;
                                            r0 = [r0 URLForResource:arg_DC withExtension:@"plist"];
                                            r0 = [r0 retain];
                                            r1 = *objc_msgSend;
                                            arg_D4 = r0;
                                            arg_D0 = r1;
                                            r0 = loc_63a52(r0, @selector(path), arg_D0, r0);
                                            r7 = r7;
                                            r0 = [r0 retain];
                                            arg_CC = r0;
                                            objc_retainAutorelease(r0);
                                            r1 = *objc_msgSend;
                                            arg_C8 = r1;
                                            r0 = ("UTF8String")();
                                            arg_1C0 = copyfile(r0, "//Library/LaunchDaemons/0.reload.plist", 0x0, 0xf);
                                            [arg_CC release];
                                            [arg_D4 release];
                                            [arg_E0 release];
                                            if (arg_1C0 != 0x0) {
                                                    arg_C4 = arg_1C0;
                                                    arg_C0 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_BC = r0;
                                                    r0 = _logToFile("Copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C4, arg_C0, arg_BC, STK-1);
                                            }
                                            else {
                                                    asm{ uxthne     r1, r1 };
                                                    arg_1C0 = chmod("/Library/LaunchDaemons/0.reload.plist", 0x180);
                                                    if (arg_1C0 != 0x0) {
                                                            arg_B8 = arg_1C0;
                                                            arg_B4 = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_B0 = r0;
                                                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_B8, arg_B4, arg_B0, STK-1);
                                                    }
                                                    else {
                                                            arg_AC = 0x0;
                                                            arg_1C0 = chown("/Library/LaunchDaemons/0.reload.plist", 0x0, arg_AC);
                                                            if (arg_1C0 != 0x0) {
                                                                    arg_A8 = arg_1C0;
                                                                    arg_A4 = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_A0 = r0;
                                                                    r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A8, arg_A4, arg_A0, STK-1);
                                                            }
                                                            else {
                                                                    asm{ uxth       r1, r1 };
                                                                    r0 = chmod("/private", 0x1ff);
                                                                    arg_9C = r0;
                                                                    asm{ uxth.w     r1, lr };
                                                                    r0 = chmod("/private/var", "/private/var");
                                                                    arg_98 = r0;
                                                                    asm{ uxth.w     r1, lr };
                                                                    r0 = chmod("/private/var/mobile", "/private/var/mobile");
                                                                    arg_94 = r0;
                                                                    asm{ uxth.w     r1, lr };
                                                                    r0 = chmod("/private/var/mobile/Library", "/private/var/mobile/Library");
                                                                    arg_90 = r0;
                                                                    asm{ uxth.w     r1, lr };
                                                                    arg_8C = chmod("/private/var/mobile/Library/Preferences", "/private/var/mobile/Library/Preferences");
                                                                    if (arg_1C0 != 0x0) {
                                                                            arg_88 = arg_1C0;
                                                                            arg_84 = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_80 = r0;
                                                                            r0 = _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_88, arg_84, arg_80, STK-1);
                                                                    }
                                                                    else {
                                                                            r0 = *objc_msgSend;
                                                                            arg_7C = r0;
                                                                            r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_7C);
                                                                            r2 = *objc_msgSend;
                                                                            arg_78 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                            arg_74 = r2;
                                                                            r0 = [r0 initWithContentsOfFile:arg_78];
                                                                            r2 = *objc_msgSend;
                                                                            arg_1A0 = r0;
                                                                            arg_70 = arg_1A0;
                                                                            arg_6C = 0x1;
                                                                            arg_68 = r2;
                                                                            r0 = [NSNumber numberWithBool:sign_extend_32(arg_6C)];
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_64 = r0;
                                                                            arg_60 = @"SBShowNonDefaultSystemApps";
                                                                            arg_5C = r2;
                                                                            [arg_70 setObject:r0 forKey:arg_60];
                                                                            [arg_64 release];
                                                                            r2 = *objc_msgSend;
                                                                            arg_58 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                            arg_54 = 0x1;
                                                                            arg_50 = r2;
                                                                            r0 = [arg_1A0 writeToFile:arg_58 atomically:sign_extend_32(arg_54)];
                                                                            r2 = *objc_msgSend;
                                                                            arg_4C = r0;
                                                                            arg_48 = @"/usr/bin/killall";
                                                                            arg_44 = r2;
                                                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_48, arg_48);
                                                                            r0 = [r0 retain];
                                                                            r1 = *objc_msgSend;
                                                                            arg_198 = @"-9";
                                                                            arg_19C = @"cfprefsd";
                                                                            arg_40 = r0;
                                                                            arg_3C = r1;
                                                                            r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), &arg_198, 0x2);
                                                                            r7 = r7;
                                                                            arg_38 = [r0 retain];
                                                                            arg_1C0 = _easyPosixSpawn(arg_40, arg_38);
                                                                            [arg_38 release];
                                                                            [arg_40 release];
                                                                            if (arg_1C0 != 0x0) {
                                                                                    arg_34 = arg_1C0;
                                                                                    arg_30 = *__error();
                                                                                    r0 = __error();
                                                                                    r0 = *r0;
                                                                                    r0 = strerror(r0);
                                                                                    arg_2C = r0;
                                                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_34, arg_30, arg_2C, STK-1);
                                                                            }
                                                                            r0 = *objc_msgSend;
                                                                            arg_28 = r0;
                                                                            r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_28);
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_190 = @"YLUProgressString";
                                                                            arg_194 = @"HDPProcessComplete";
                                                                            arg_24 = r0;
                                                                            arg_20 = 0x1;
                                                                            arg_1C = r2;
                                                                            var_0 = arg_20;
                                                                            r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_194, &arg_190);
                                                                            r0 = [r0 retain];
                                                                            r2 = *objc_msgSend;
                                                                            arg_18 = r0;
                                                                            arg_14 = @"YLUDidReceiveUpdateProgressNotification";
                                                                            arg_10 = r2;
                                                                            var_0 = arg_18;
                                                                            [arg_24 postNotificationName:arg_14 object:0x0 userInfo:STK-1];
                                                                            [arg_18 release];
                                                                            [arg_24 release];
                                                                            r0 = system("(su -c uicache mobile)&");
                                                                            arg_C = r0;
                                                                            r0 = system("(echo 'really jailbroken';for s in /etc/rc.d/*; do $s; done;sleep 1 && killall backboardd)&");
                                                                            arg_8 = r0;
                                                                            _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_1C4, arg_1C8, arg_1C8, STK-1);
                                                                            _write_primitive(arg_1C8, arg_1C4);
                                                                            r0 = sleep(0x2);
                                                                            arg_4 = r0;
                                                                            _logToFile("done\n", "done\n", arg_1C8, arg_1C8, STK-1);
                                                                            r0 = objc_storeStrong(&arg_1A0, 0x0);
                                                                    }
                                                            }
                                                    }
                                            }
                                    }
                                    else {
                                            asm{ uxth       r1, r1 };
                                            r0 = chmod("/private", 0x1ff);
                                            arg_9C = r0;
                                            asm{ uxth.w     r1, lr };
                                            r0 = chmod("/private/var", "/private/var");
                                            arg_98 = r0;
                                            asm{ uxth.w     r1, lr };
                                            r0 = chmod("/private/var/mobile", "/private/var/mobile");
                                            arg_94 = r0;
                                            asm{ uxth.w     r1, lr };
                                            r0 = chmod("/private/var/mobile/Library", "/private/var/mobile/Library");
                                            arg_90 = r0;
                                            asm{ uxth.w     r1, lr };
                                            arg_8C = chmod("/private/var/mobile/Library/Preferences", "/private/var/mobile/Library/Preferences");
                                            if (arg_1C0 != 0x0) {
                                                    arg_88 = arg_1C0;
                                                    arg_84 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_80 = r0;
                                                    r0 = _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_88, arg_84, arg_80, STK-1);
                                            }
                                            else {
                                                    r0 = *objc_msgSend;
                                                    arg_7C = r0;
                                                    r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_7C);
                                                    r2 = *objc_msgSend;
                                                    arg_78 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                    arg_74 = r2;
                                                    r0 = [r0 initWithContentsOfFile:arg_78];
                                                    r2 = *objc_msgSend;
                                                    arg_1A0 = r0;
                                                    arg_70 = arg_1A0;
                                                    arg_6C = 0x1;
                                                    arg_68 = r2;
                                                    r0 = [NSNumber numberWithBool:sign_extend_32(arg_6C)];
                                                    r0 = [r0 retain];
                                                    r2 = *objc_msgSend;
                                                    arg_64 = r0;
                                                    arg_60 = @"SBShowNonDefaultSystemApps";
                                                    arg_5C = r2;
                                                    [arg_70 setObject:r0 forKey:arg_60];
                                                    [arg_64 release];
                                                    r2 = *objc_msgSend;
                                                    arg_58 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                    arg_54 = 0x1;
                                                    arg_50 = r2;
                                                    r0 = [arg_1A0 writeToFile:arg_58 atomically:sign_extend_32(arg_54)];
                                                    r2 = *objc_msgSend;
                                                    arg_4C = r0;
                                                    arg_48 = @"/usr/bin/killall";
                                                    arg_44 = r2;
                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_48, arg_48);
                                                    r0 = [r0 retain];
                                                    r1 = *objc_msgSend;
                                                    arg_198 = @"-9";
                                                    arg_19C = @"cfprefsd";
                                                    arg_40 = r0;
                                                    arg_3C = r1;
                                                    r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), &arg_198, 0x2);
                                                    r7 = r7;
                                                    arg_38 = [r0 retain];
                                                    arg_1C0 = _easyPosixSpawn(arg_40, arg_38);
                                                    [arg_38 release];
                                                    [arg_40 release];
                                                    if (arg_1C0 != 0x0) {
                                                            arg_34 = arg_1C0;
                                                            arg_30 = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_2C = r0;
                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_34, arg_30, arg_2C, STK-1);
                                                    }
                                                    r0 = *objc_msgSend;
                                                    arg_28 = r0;
                                                    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_28);
                                                    r0 = [r0 retain];
                                                    r2 = *objc_msgSend;
                                                    arg_190 = @"YLUProgressString";
                                                    arg_194 = @"HDPProcessComplete";
                                                    arg_24 = r0;
                                                    arg_20 = 0x1;
                                                    arg_1C = r2;
                                                    var_0 = arg_20;
                                                    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_194, &arg_190);
                                                    r0 = [r0 retain];
                                                    r2 = *objc_msgSend;
                                                    arg_18 = r0;
                                                    arg_14 = @"YLUDidReceiveUpdateProgressNotification";
                                                    arg_10 = r2;
                                                    var_0 = arg_18;
                                                    [arg_24 postNotificationName:arg_14 object:0x0 userInfo:STK-1];
                                                    [arg_18 release];
                                                    [arg_24 release];
                                                    r0 = system("(su -c uicache mobile)&");
                                                    arg_C = r0;
                                                    r0 = system("(echo 'really jailbroken';for s in /etc/rc.d/*; do $s; done;sleep 1 && killall backboardd)&");
                                                    arg_8 = r0;
                                                    _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_1C4, arg_1C8, arg_1C8, STK-1);
                                                    _write_primitive(arg_1C8, arg_1C4);
                                                    r0 = sleep(0x2);
                                                    arg_4 = r0;
                                                    _logToFile("done\n", "done\n", arg_1C8, arg_1C8, STK-1);
                                                    r0 = objc_storeStrong(&arg_1A0, 0x0);
                                            }
                                    }
                            }
                    }
            }
            else {
                    asm{ uxth       r1, r1 };
                    arg_1C0 = chmod("/usr/libexec/reload", 0x1ed);
                    if (arg_1C0 != 0x0) {
                            arg_104 = arg_1C0;
                            arg_100 = *__error();
                            r0 = __error();
                            r0 = *r0;
                            r0 = strerror(r0);
                            arg_FC = r0;
                            r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_104, arg_100, arg_FC, STK-1);
                    }
                    else {
                            r0 = *objc_msgSend;
                            arg_F8 = r0;
                            r0 = _OBJC_CLASS_$_NSFileManager(NSFileManager, @selector(defaultManager), arg_F8);
                            r7 = r7;
                            r0 = [r0 retain];
                            r2 = *objc_msgSend;
                            arg_F4 = r0;
                            arg_F0 = @"/Library/LaunchDaemons/0.reload.plist";
                            r3 = arg_F0;
                            arg_EC = r2;
                            r2 = r3;
                            COND = sign_extend_32(("fileExistsAtPath:")(r0, @selector(fileExistsAtPath:), r2, r3)) == 0x0;
                            r0 = 0x0;
                            asm{ it         ne };
                            if (!COND) {
                                    r0 = 0x1;
                            }
                            r1 = arg_F4;
                            arg_E8 = r0 ^ 0xffffffff;
                            [r1 release];
                            if ((arg_E8 & 0x1) != 0x0) {
                                    _logToFile("enable\n", r1, r2, r3, STK-1);
                                    r0 = *objc_msgSend;
                                    arg_E4 = r0;
                                    r0 = ("mainBundle")(NSBundle, @selector(mainBundle));
                                    r0 = [r0 retain];
                                    r2 = *objc_msgSend;
                                    arg_E0 = r0;
                                    arg_DC = @"0.reload";
                                    arg_D8 = r2;
                                    r0 = [r0 URLForResource:arg_DC withExtension:@"plist"];
                                    r0 = [r0 retain];
                                    r1 = *objc_msgSend;
                                    arg_D4 = r0;
                                    arg_D0 = r1;
                                    r0 = loc_63a52(r0, @selector(path), arg_D0, r0);
                                    r7 = r7;
                                    r0 = [r0 retain];
                                    arg_CC = r0;
                                    objc_retainAutorelease(r0);
                                    r1 = *objc_msgSend;
                                    arg_C8 = r1;
                                    r0 = ("UTF8String")();
                                    arg_1C0 = copyfile(r0, "//Library/LaunchDaemons/0.reload.plist", 0x0, 0xf);
                                    [arg_CC release];
                                    [arg_D4 release];
                                    [arg_E0 release];
                                    if (arg_1C0 != 0x0) {
                                            arg_C4 = arg_1C0;
                                            arg_C0 = *__error();
                                            r0 = __error();
                                            r0 = *r0;
                                            r0 = strerror(r0);
                                            arg_BC = r0;
                                            r0 = _logToFile("Copyfile returned nonzero value: %d, errno: %d, strerror: %s\n", arg_C4, arg_C0, arg_BC, STK-1);
                                    }
                                    else {
                                            asm{ uxthne     r1, r1 };
                                            arg_1C0 = chmod("/Library/LaunchDaemons/0.reload.plist", 0x180);
                                            if (arg_1C0 != 0x0) {
                                                    arg_B8 = arg_1C0;
                                                    arg_B4 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_B0 = r0;
                                                    r0 = _logToFile("chmod returned nonzero value: %d, errno: %d, strerror: %s\n", arg_B8, arg_B4, arg_B0, STK-1);
                                            }
                                            else {
                                                    arg_AC = 0x0;
                                                    arg_1C0 = chown("/Library/LaunchDaemons/0.reload.plist", 0x0, arg_AC);
                                                    if (arg_1C0 != 0x0) {
                                                            arg_A8 = arg_1C0;
                                                            arg_A4 = *__error();
                                                            r0 = __error();
                                                            r0 = *r0;
                                                            r0 = strerror(r0);
                                                            arg_A0 = r0;
                                                            r0 = _logToFile("chown returned nonzero value: %d, errno: %d, strerror: %s\n", arg_A8, arg_A4, arg_A0, STK-1);
                                                    }
                                                    else {
                                                            asm{ uxth       r1, r1 };
                                                            r0 = chmod("/private", 0x1ff);
                                                            arg_9C = r0;
                                                            asm{ uxth.w     r1, lr };
                                                            r0 = chmod("/private/var", "/private/var");
                                                            arg_98 = r0;
                                                            asm{ uxth.w     r1, lr };
                                                            r0 = chmod("/private/var/mobile", "/private/var/mobile");
                                                            arg_94 = r0;
                                                            asm{ uxth.w     r1, lr };
                                                            r0 = chmod("/private/var/mobile/Library", "/private/var/mobile/Library");
                                                            arg_90 = r0;
                                                            asm{ uxth.w     r1, lr };
                                                            arg_8C = chmod("/private/var/mobile/Library/Preferences", "/private/var/mobile/Library/Preferences");
                                                            if (arg_1C0 != 0x0) {
                                                                    arg_88 = arg_1C0;
                                                                    arg_84 = *__error();
                                                                    r0 = __error();
                                                                    r0 = *r0;
                                                                    r0 = strerror(r0);
                                                                    arg_80 = r0;
                                                                    r0 = _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_88, arg_84, arg_80, STK-1);
                                                            }
                                                            else {
                                                                    r0 = *objc_msgSend;
                                                                    arg_7C = r0;
                                                                    r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_7C);
                                                                    r2 = *objc_msgSend;
                                                                    arg_78 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                    arg_74 = r2;
                                                                    r0 = [r0 initWithContentsOfFile:arg_78];
                                                                    r2 = *objc_msgSend;
                                                                    arg_1A0 = r0;
                                                                    arg_70 = arg_1A0;
                                                                    arg_6C = 0x1;
                                                                    arg_68 = r2;
                                                                    r0 = [NSNumber numberWithBool:sign_extend_32(arg_6C)];
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_64 = r0;
                                                                    arg_60 = @"SBShowNonDefaultSystemApps";
                                                                    arg_5C = r2;
                                                                    [arg_70 setObject:r0 forKey:arg_60];
                                                                    [arg_64 release];
                                                                    r2 = *objc_msgSend;
                                                                    arg_58 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                                                    arg_54 = 0x1;
                                                                    arg_50 = r2;
                                                                    r0 = [arg_1A0 writeToFile:arg_58 atomically:sign_extend_32(arg_54)];
                                                                    r2 = *objc_msgSend;
                                                                    arg_4C = r0;
                                                                    arg_48 = @"/usr/bin/killall";
                                                                    arg_44 = r2;
                                                                    r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_48, arg_48);
                                                                    r0 = [r0 retain];
                                                                    r1 = *objc_msgSend;
                                                                    arg_198 = @"-9";
                                                                    arg_19C = @"cfprefsd";
                                                                    arg_40 = r0;
                                                                    arg_3C = r1;
                                                                    r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), &arg_198, 0x2);
                                                                    r7 = r7;
                                                                    arg_38 = [r0 retain];
                                                                    arg_1C0 = _easyPosixSpawn(arg_40, arg_38);
                                                                    [arg_38 release];
                                                                    [arg_40 release];
                                                                    if (arg_1C0 != 0x0) {
                                                                            arg_34 = arg_1C0;
                                                                            arg_30 = *__error();
                                                                            r0 = __error();
                                                                            r0 = *r0;
                                                                            r0 = strerror(r0);
                                                                            arg_2C = r0;
                                                                            _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_34, arg_30, arg_2C, STK-1);
                                                                    }
                                                                    r0 = *objc_msgSend;
                                                                    arg_28 = r0;
                                                                    r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_28);
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_190 = @"YLUProgressString";
                                                                    arg_194 = @"HDPProcessComplete";
                                                                    arg_24 = r0;
                                                                    arg_20 = 0x1;
                                                                    arg_1C = r2;
                                                                    var_0 = arg_20;
                                                                    r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_194, &arg_190);
                                                                    r0 = [r0 retain];
                                                                    r2 = *objc_msgSend;
                                                                    arg_18 = r0;
                                                                    arg_14 = @"YLUDidReceiveUpdateProgressNotification";
                                                                    arg_10 = r2;
                                                                    var_0 = arg_18;
                                                                    [arg_24 postNotificationName:arg_14 object:0x0 userInfo:STK-1];
                                                                    [arg_18 release];
                                                                    [arg_24 release];
                                                                    r0 = system("(su -c uicache mobile)&");
                                                                    arg_C = r0;
                                                                    r0 = system("(echo 'really jailbroken';for s in /etc/rc.d/*; do $s; done;sleep 1 && killall backboardd)&");
                                                                    arg_8 = r0;
                                                                    _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_1C4, arg_1C8, arg_1C8, STK-1);
                                                                    _write_primitive(arg_1C8, arg_1C4);
                                                                    r0 = sleep(0x2);
                                                                    arg_4 = r0;
                                                                    _logToFile("done\n", "done\n", arg_1C8, arg_1C8, STK-1);
                                                                    r0 = objc_storeStrong(&arg_1A0, 0x0);
                                                            }
                                                    }
                                            }
                                    }
                            }
                            else {
                                    asm{ uxth       r1, r1 };
                                    r0 = chmod("/private", 0x1ff);
                                    arg_9C = r0;
                                    asm{ uxth.w     r1, lr };
                                    r0 = chmod("/private/var", "/private/var");
                                    arg_98 = r0;
                                    asm{ uxth.w     r1, lr };
                                    r0 = chmod("/private/var/mobile", "/private/var/mobile");
                                    arg_94 = r0;
                                    asm{ uxth.w     r1, lr };
                                    r0 = chmod("/private/var/mobile/Library", "/private/var/mobile/Library");
                                    arg_90 = r0;
                                    asm{ uxth.w     r1, lr };
                                    arg_8C = chmod("/private/var/mobile/Library/Preferences", "/private/var/mobile/Library/Preferences");
                                    if (arg_1C0 != 0x0) {
                                            arg_88 = arg_1C0;
                                            arg_84 = *__error();
                                            r0 = __error();
                                            r0 = *r0;
                                            r0 = strerror(r0);
                                            arg_80 = r0;
                                            r0 = _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_88, arg_84, arg_80, STK-1);
                                    }
                                    else {
                                            r0 = *objc_msgSend;
                                            arg_7C = r0;
                                            r0 = _OBJC_CLASS_$_NSMutableDictionary(NSMutableDictionary, @selector(alloc), arg_7C);
                                            r2 = *objc_msgSend;
                                            arg_78 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                            arg_74 = r2;
                                            r0 = [r0 initWithContentsOfFile:arg_78];
                                            r2 = *objc_msgSend;
                                            arg_1A0 = r0;
                                            arg_70 = arg_1A0;
                                            arg_6C = 0x1;
                                            arg_68 = r2;
                                            r0 = [NSNumber numberWithBool:sign_extend_32(arg_6C)];
                                            r0 = [r0 retain];
                                            r2 = *objc_msgSend;
                                            arg_64 = r0;
                                            arg_60 = @"SBShowNonDefaultSystemApps";
                                            arg_5C = r2;
                                            [arg_70 setObject:r0 forKey:arg_60];
                                            [arg_64 release];
                                            r2 = *objc_msgSend;
                                            arg_58 = @"/var/mobile/Library/Preferences/com.apple.springboard.plist";
                                            arg_54 = 0x1;
                                            arg_50 = r2;
                                            r0 = [arg_1A0 writeToFile:arg_58 atomically:sign_extend_32(arg_54)];
                                            r2 = *objc_msgSend;
                                            arg_4C = r0;
                                            arg_48 = @"/usr/bin/killall";
                                            arg_44 = r2;
                                            r0 = _OBJC_CLASS_$_NSURL(NSURL, @selector(fileURLWithPath:), arg_48, arg_48);
                                            r0 = [r0 retain];
                                            r1 = *objc_msgSend;
                                            arg_198 = @"-9";
                                            arg_19C = @"cfprefsd";
                                            arg_40 = r0;
                                            arg_3C = r1;
                                            r0 = ("arrayWithObjects:count:")(NSArray, @selector(arrayWithObjects:count:), &arg_198, 0x2);
                                            r7 = r7;
                                            arg_38 = [r0 retain];
                                            arg_1C0 = _easyPosixSpawn(arg_40, arg_38);
                                            [arg_38 release];
                                            [arg_40 release];
                                            if (arg_1C0 != 0x0) {
                                                    arg_34 = arg_1C0;
                                                    arg_30 = *__error();
                                                    r0 = __error();
                                                    r0 = *r0;
                                                    r0 = strerror(r0);
                                                    arg_2C = r0;
                                                    _logToFile("posix_spawn returned nonzero value: %d, errno: %d, strerror: %s\n", arg_34, arg_30, arg_2C, STK-1);
                                            }
                                            r0 = *objc_msgSend;
                                            arg_28 = r0;
                                            r0 = _OBJC_CLASS_$_NSNotificationCenter(NSNotificationCenter, @selector(defaultCenter), arg_28);
                                            r0 = [r0 retain];
                                            r2 = *objc_msgSend;
                                            arg_190 = @"YLUProgressString";
                                            arg_194 = @"HDPProcessComplete";
                                            arg_24 = r0;
                                            arg_20 = 0x1;
                                            arg_1C = r2;
                                            var_0 = arg_20;
                                            r0 = _OBJC_CLASS_$_NSDictionary(NSDictionary, @selector(dictionaryWithObjects:forKeys:count:), &arg_194, &arg_190);
                                            r0 = [r0 retain];
                                            r2 = *objc_msgSend;
                                            arg_18 = r0;
                                            arg_14 = @"YLUDidReceiveUpdateProgressNotification";
                                            arg_10 = r2;
                                            var_0 = arg_18;
                                            [arg_24 postNotificationName:arg_14 object:0x0 userInfo:STK-1];
                                            [arg_18 release];
                                            [arg_24 release];
                                            r0 = system("(su -c uicache mobile)&");
                                            arg_C = r0;
                                            r0 = system("(echo 'really jailbroken';for s in /etc/rc.d/*; do $s; done;sleep 1 && killall backboardd)&");
                                            arg_8 = r0;
                                            _logToFile("Wrill write 0x%08x to 0x%08x\n", arg_1C4, arg_1C8, arg_1C8, STK-1);
                                            _write_primitive(arg_1C8, arg_1C4);
                                            r0 = sleep(0x2);
                                            arg_4 = r0;
                                            _logToFile("done\n", "done\n", arg_1C8, arg_1C8, STK-1);
                                            r0 = objc_storeStrong(&arg_1A0, 0x0);
                                    }
                            }
                    }
            }
    }
    return r0;
}
